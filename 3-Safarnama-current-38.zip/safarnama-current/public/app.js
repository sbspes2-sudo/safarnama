/* Safarnama - front-end travel concept. All rates are dated examples from
   named sources, checked 30 Oct 2026 - not live quotes. No bookings happen here. */
(function () {
  'use strict';

  var MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

// Transport data per destination: typical scheduled durations from a reference hub city.
// Modes: flight/train/bus/drive. flight.city = arrival airport city for search links.
var TRANSPORT = {
  agra:      { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Agra', flight: { t: 'no Delhi-Agra flights; Agra airport has limited service (Bengaluru and Navi Mumbai routes, per IndiGo and Oct 2026 winter schedule reports)', city: 'Agra' }, train: { t: 'about 1 hr 50 min (fastest services about 1 hr 40 min)' }, bus: { t: 'about 3.5 hr', slug: 'agra' }, drive: { t: 'about 3.5 hr via Yamuna Expressway', city: 'Agra' } },
  jaipur:    { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Jaipur', flight: { t: 'about 1 hr', city: 'Jaipur' }, train: { t: 'about 5 hr (fastest services about 3 hr 40 min)' }, bus: { t: 'about 4.5 hr', slug: 'jaipur' }, drive: { t: 'about 5 hr via NH48', city: 'Jaipur' } },
  udaipur:   { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Udaipur', flight: { t: 'about 1 hr 20 min', city: 'Udaipur' }, train: { t: 'about 11.5 hr (one direct train daily)' }, bus: { t: 'about 12 hr', slug: 'udaipur' }, drive: { t: 'about 11 hr', city: 'Udaipur' } },
  amritsar:  { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Amritsar', flight: { t: 'about 1 hr 10 min', city: 'Amritsar' }, train: { t: 'about 6.5 hr' }, bus: { t: 'about 10 hr', slug: 'amritsar' }, drive: { t: 'about 8 hr', city: 'Amritsar' } },
  varanasi:  { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Varanasi', flight: { t: 'about 1 hr 30 min', city: 'Varanasi' }, train: { t: 'about 11 hr (fastest services about 8 hr)' }, bus: { t: 'about 12 hr', slug: 'varanasi' }, drive: { t: 'about 11 hr', city: 'Varanasi' } },
  leh:       { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Leh', flight: { t: 'about 1 hr 20 min', city: 'Leh' }, bus: { t: 'about 32 hr via Keylong - seasonal, roughly Jun to Sep', slug: 'leh' }, drive: { t: 'about 2 days via Manali - highway open roughly Jun to Sep only', city: 'Leh' } },
  manali:    { hub: 'New Delhi', src: 'https://www.redbus.in/bus-tickets/delhi-to-manali', flight: { t: 'about 1 hr 15 min to Bhuntar + 1.5 hr drive', city: 'Bhuntar' }, bus: { t: 'about 12 to 14 hr (overnight Volvo coaches)', slug: 'manali' }, drive: { t: 'about 11 hr', city: 'Manali' } },
  goa:       { hub: 'Mumbai', src: 'https://www.rome2rio.com/s/Mumbai/Goa-India', flight: { t: 'about 1 hr 10 min', city: 'Goa' }, train: { t: 'about 11 hr to Karmali' }, bus: { t: 'about 14 hr', slug: 'goa' }, drive: { t: 'about 8.5 hr', city: 'Goa' } },
  kerala:    { hub: 'Bengaluru', src: 'https://www.rome2rio.com/s/Bengaluru/Kochi', flight: { t: 'about 1 hr 5 min to Kochi', city: 'Kochi' }, train: { t: 'about 10 hr to Kochi' }, bus: { t: 'about 9.5 hr to Ernakulam (Kochi)', slug: 'ernakulam' }, drive: { t: 'about 8.5 hr to Kochi', city: 'Kochi' } },
  mumbai:    { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Mumbai', flight: { t: 'about 2 hr 10 min', city: 'Mumbai' }, train: { t: 'about 16 hr (Rajdhani)' }, bus: { t: 'about 24 hr', slug: 'mumbai' }, drive: { t: 'about 14.5 hr', city: 'Mumbai' } },
  darjeeling:{ hub: 'Kolkata', src: 'https://www.rome2rio.com/s/Kolkata/Darjeeling', flight: { t: 'about 1 hr 10 min to Bagdogra + 3 hr drive', city: 'Bagdogra' }, train: { t: 'about 11 hr overnight to New Jalpaiguri + 3 hr drive' }, bus: { t: 'about 16 hr via Siliguri', slug: 'siliguri' }, drive: { t: 'about 14 hr', city: 'Darjeeling' } },
  andaman:   { hub: 'Chennai', src: 'https://www.rome2rio.com/s/Chennai/Port-Blair', flight: { t: 'about 2 hr 5 min to Port Blair', city: 'Port Blair' }, ship: { t: 'about 60 hr by passenger ship, a few sailings a month' } },
  jaisalmer: { hub: 'Jodhpur', src: 'https://www.rome2rio.com/s/Jodhpur/Jaisalmer', flight: { t: 'limited direct Jodhpur-Jaisalmer flights - check availability', city: 'Jaisalmer' }, train: { t: 'about 5 hr 40 min (4 trains a day)' }, bus: { t: 'about 5 hr', slug: 'jaisalmer' }, drive: { t: 'about 4 hr', city: 'Jaisalmer' } },
  rishikesh: { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Rishikesh', flight: { t: 'about 1 hr to Dehradun + 45 min drive', city: 'Dehradun' }, train: { t: 'about 7 hr 20 min direct (2 trains a day)' }, bus: { t: 'about 5.5 hr', slug: 'rishikesh' }, drive: { t: 'about 4 hr', city: 'Rishikesh' } },
  hampi:     { hub: 'Bengaluru', src: 'https://www.rome2rio.com/s/Bengaluru/Hampi', flight: { t: 'about 1 hr to Vijaynagar (limited service) or Hubballi + drive', city: 'Hubballi' }, train: { t: 'about 8 hr to Hosapete + 30 min drive' }, bus: { t: 'about 7 hr (direct buses to Hampi)', slug: 'hospet' }, drive: { t: 'about 5 hr', city: 'Hampi' } },
  shillong:  { hub: 'Kolkata', src: 'https://www.rome2rio.com/s/Kolkata/Shillong', flight: { t: 'limited direct flights to Shillong (Umroi); more frequent to Guwahati + 3 hr drive', city: 'Guwahati' }, train: { t: 'about 18 to 20 hr to Guwahati + 3 hr drive' }, drive: { t: 'about 20 hr', city: 'Shillong' } }
,
  srinagar:  { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Srinagar', flight: { t: 'about 3 hr 30 min listed (incl. transfers)', city: 'Srinagar' }, train: { t: 'no direct train listed - about 14 hr 30 min with change' }, bus: { t: 'about 18 hr 50 min (direct buses listed)', slug: 'srinagar' }, drive: { t: 'about 10 hr 26 min', city: 'Srinagar' } },
  shimla:    { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Shimla', train: { t: 'no direct train listed - about 9 hr 55 min via Kalka' }, bus: { t: 'about 9 hr 50 min (direct buses listed)', slug: 'shimla' }, drive: { t: 'about 5 hr 10 min', city: 'Shimla' } },
  tirupati:  { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Tirupati', flight: { t: 'about 4 hr 20 min listed (incl. transfers)', city: 'Tirupati' }, train: { t: 'about 32 hr 25 min direct (listed)' }, bus: { t: 'no direct bus listed', slug: 'tirupati' }, drive: { t: 'about 27 hr 37 min', city: 'Tirupati' } },
  bodhgaya:  { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Bodh-Gay%C4%81', flight: { t: 'about 3 hr 9 min listed (incl. transfers)', city: 'Gaya' }, train: { t: 'about 11 hr 30 min listed (1 change)' }, bus: { t: 'about 19 hr 38 min listed (with changes)', slug: 'gaya' } },
  ajmer:     { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Ajmer', flight: { t: 'about 2 hr 36 min listed (fly + train)', city: 'Jaipur' }, train: { t: 'about 5 hr 40 min direct (listed)' }, bus: { t: 'about 8 hr 29 min direct (listed)', slug: 'ajmer' }, drive: { t: 'about 5 hr 42 min', city: 'Ajmer' } },
  haridwar:  { hub: 'New Delhi', src: 'https://www.rome2rio.com/s/New-Delhi/Haridwar', train: { t: 'about 4 hr 7 min direct (listed)' }, bus: { t: 'about 4 hr 20 min direct (listed)', slug: 'haridwar' }, drive: { t: 'about 3 hr 1 min', city: 'Haridwar' } }
};

Object.assign(TRANSPORT, {"delhi": {"hub": "Amritsar", "src": "https://www.rome2rio.com/s/Amritsar/New-Delhi", "train": {"t": "about 6 hr 7 min average listed"}, "flight": {"t": "duration not verified - check current options", "city": "New Delhi"}, "bus": {"t": "duration not verified - check current options", "slug": "delhi"}, "drive": {"t": "duration not verified - check current traffic", "city": "New Delhi"}}, "bengaluru": {"hub": "New Delhi", "src": "https://www.rome2rio.com/s/New-Delhi/Bengaluru", "train": {"t": "about 35 hr 2 min average listed"}, "flight": {"t": "duration not verified - check current options", "city": "Bengaluru"}, "bus": {"t": "duration not verified - check current options", "slug": "bangalore"}, "drive": {"t": "duration not verified - check current traffic", "city": "Bengaluru"}}, "kolkata": {"hub": "New Delhi", "src": "https://www.rome2rio.com/s/New-Delhi/Kolkata", "flight": {"t": "about 4 hr 23 min listed from DEL (incl. transfers)", "city": "Kolkata"}, "train": {"t": "about 17 hr 40 min listed to Sealdah"}, "bus": {"t": "about 26 hr 8 min listed", "slug": "kolkata"}, "drive": {"t": "about 17 hr 46 min listed, before breaks", "city": "Kolkata"}}, "puri": {"hub": "Kolkata", "src": "https://www.rome2rio.com/s/Kolkata/Puri", "flight": {"t": "about 6 hr 53 min listed, flight to Bhubaneswar + bus", "city": "Bhubaneswar"}, "train": {"t": "about 8 hr 10 min listed from Sealdah"}, "bus": {"t": "about 10 hr 5 min listed", "slug": "puri"}, "drive": {"t": "about 7 hr 6 min listed, before breaks", "city": "Puri"}}});

Object.assign(TRANSPORT, {"hyderabad": {"hub": "Bengaluru", "src": "https://www.rome2rio.com/s/Bengaluru/Hyderabad", "train": {"t": "about 11 hr 28 min listed"}, "bus": {"t": "about 8 hr 45 min listed", "slug": "hyderabad"}, "drive": {"t": "about 7 hr 58 min listed before breaks", "city": "Hyderabad"}, "flight": {"t": "journey duration not verified - check airport and onward transfer options", "city": "Hyderabad"}}, "chennai": {"hub": "Bengaluru", "src": "https://www.rome2rio.com/s/Bengaluru/Chennai", "train": {"t": "about 5 hr 25 min listed"}, "bus": {"t": "about 6 hr 50 min listed", "slug": "chennai"}, "drive": {"t": "about 4 hr 25 min listed before breaks", "city": "Chennai"}, "flight": {"t": "journey duration not verified - check airport and onward transfer options", "city": "Chennai"}}, "mysuru": {"hub": "Bengaluru", "src": "https://www.rome2rio.com/s/Bengaluru/Mysuru", "train": {"t": "about 3 hr listed"}, "bus": {"t": "about 2 hr 54 min listed", "slug": "mysuru"}, "drive": {"t": "about 1 hr 46 min listed before breaks", "city": "Mysuru"}, "flight": {"t": "journey duration not verified - check airport and onward transfer options", "city": "Mysuru"}}, "madurai": {"hub": "Chennai", "src": "https://www.rome2rio.com/s/Chennai/Madurai", "train": {"t": "about 7 hr 40 min listed"}, "bus": {"t": "about 7 hr 15 min listed", "slug": "madurai"}, "drive": {"t": "duration not verified - check current route and traffic", "city": "Madurai"}, "flight": {"t": "journey duration not verified - check airport and onward transfer options", "city": "Madurai"}}});

Object.assign(TRANSPORT, {"pune": {"hub": "Mumbai", "src": "https://www.rome2rio.com/s/Mumbai/Pune", "train": {"t": "about 3 hr 12 min listed"}, "bus": {"t": "about 3 hr 29 min listed", "slug": "pune"}, "drive": {"t": "duration not verified - check current route and traffic", "city": "Pune"}, "flight": {"t": "complete journey duration not verified - check airport and onward transfer", "city": "Pune"}}, "ahmedabad": {"hub": "Mumbai", "src": "https://www.rome2rio.com/s/Mumbai/Ahmedabad", "train": {"t": "about 5 hr 55 min listed"}, "bus": {"t": "about 11 hr 10 min listed", "slug": "ahmedabad"}, "drive": {"t": "duration not verified - check current route and traffic", "city": "Ahmedabad"}, "flight": {"t": "complete journey duration not verified - check airport and onward transfer", "city": "Ahmedabad"}}, "lucknow": {"hub": "New Delhi", "src": "https://www.rome2rio.com/s/New-Delhi/Lucknow", "train": {"t": "about 7 hr 25 min listed"}, "bus": {"t": "duration not verified - check current service", "slug": "lucknow"}, "drive": {"t": "duration not verified - check current route and traffic", "city": "Lucknow"}, "flight": {"t": "complete journey duration not verified - check airport and onward transfer", "city": "Lucknow"}}, "bhopal": {"hub": "New Delhi", "src": "https://www.rome2rio.com/s/New-Delhi/Bhopal", "train": {"t": "about 8 hr 12 min listed"}, "bus": {"t": "about 14 hr 19 min listed", "slug": "bhopal"}, "drive": {"t": "duration not verified - check current route and traffic", "city": "Bhopal"}, "flight": {"t": "complete journey duration not verified - check airport and onward transfer", "city": "Bhopal"}}});

Object.assign(TRANSPORT, {"indore": {"hub": "New Delhi", "src": "https://www.rome2rio.com/s/New-Delhi/Indore-Junction-Station", "train": {"t": "about 12 hr 15 min listed"}, "bus": {"t": "duration not verified - check current service", "slug": "indore"}, "drive": {"t": "duration not verified - check current route and traffic", "city": "Indore"}, "flight": {"t": "complete journey duration not verified - check airport and onward transfer", "city": "Indore"}}, "gwalior": {"hub": "New Delhi", "src": "https://www.rome2rio.com/Train/New-Delhi-Station/Gwalior", "train": {"t": "about 4 hr 31 min average listed"}, "bus": {"t": "duration not verified - check current service", "slug": "gwalior"}, "drive": {"t": "duration not verified - check current route and traffic", "city": "Gwalior"}, "flight": {"t": "complete journey duration not verified - check airport and onward transfer", "city": "Gwalior"}}, "orchha": {"hub": "New Delhi", "src": "https://www.mptourism.com/destination-orchha.php", "train": {"t": "duration not verified - travel via Jhansi, then road transfer"}, "bus": {"t": "duration not verified - check current service", "slug": "orchha"}, "drive": {"t": "duration not verified - check current route and traffic", "city": "Orchha"}, "flight": {"t": "complete journey duration not verified - check airport and onward transfer", "city": "Orchha"}}, "khajuraho": {"hub": "New Delhi", "src": "https://www.railyatri.in/time-table/22470", "train": {"t": "about 8 hr 20 min on train 22470 from Hazrat Nizamuddin; confirm running day"}, "bus": {"t": "duration not verified - check current service", "slug": "khajuraho"}, "drive": {"t": "duration not verified - check current route and traffic", "city": "Khajuraho"}, "flight": {"t": "complete journey duration not verified - check airport and onward transfer", "city": "Khajuraho"}}});

var TRANSPORT_ALT = {
  agra: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Agra', train: 'about 9 hr 40 min direct (4 trains a day)', bus: 'about 14.5 hr direct', drive: 'about 8 hr', flight: 'no Amritsar-Agra flights listed - fly to Delhi and continue by train' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Agra', train: 'about 6 to 9 hr', bus: 'about 10 hr 20 min direct (3 buses a day)', drive: 'about 6 hr', flight: 'fly to Delhi and continue by train, about 5.5 hr total' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Agra', flight: 'about 5 hr 11 min listed (incl. transfers)', train: 'about 18 hr 55 min direct (listed)', bus: 'no direct bus listed - about 23 hr 53 min with changes', drive: 'about 14 hr 56 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Agra', flight: 'about 5 hr 10 min listed (incl. transfers)', train: 'about 30 hr 55 min direct (listed)', bus: 'no direct bus listed - about 34 hr 57 min with changes', drive: 'about 27 hr 2 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Agra', flight: 'about 7 hr 8 min listed (incl. transfers)', train: 'about 19 hr 35 min direct (listed)', bus: 'no direct bus listed - about 24 hr 3 min with changes', drive: 'about 16 hr 41 min' },
  },
  jaipur: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Jaipur', bus: 'about 11 hr 40 min direct (2 buses a day)', train: 'about 17 hr direct (3 days a week)', drive: 'about 8 hr', flight: 'no direct flights listed - connect via Delhi' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Jaipur', flight: 'direct flights listed 3 times a day', bus: 'about 8 hr direct (every 4 hr)', train: 'about 10 hr 25 min direct (2 trains a day)', drive: 'about 6 hr' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Jaipur', flight: 'about 4 hr 31 min listed (incl. transfers)', train: 'about 16 hr 55 min direct (listed)', bus: 'no direct bus listed - about 22 hr 57 min with changes', drive: 'about 12 hr 56 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Jaipur', flight: 'about 6 hr 12 min listed (incl. transfers)', train: 'about 41 hr 33 min direct (listed)', bus: 'about 30 hr direct (listed)', drive: 'about 25 hr 28 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Jaipur', flight: 'no flight option listed' },
  },
  udaipur: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Udaipur', flight: 'connecting flights listed - check live times', bus: 'about 18 hr via Jodhpur', train: 'about 22 hr via Kota', drive: 'about 12 hr' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Udaipur', flight: 'connecting flights, fastest about 5 hr', drive: 'about 11.5 hr' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Udaipur', flight: 'about 3 hr 5 min listed (incl. transfers)', train: 'no direct train listed - about 15 hr 31 min (listed)', bus: 'no direct bus listed - about 16 hr 32 min with changes', drive: 'about 9 hr 25 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Udaipur', flight: 'about 4 hr 56 min listed (incl. transfers)', train: 'about 39 hr direct (listed)', bus: 'about 13 hr 5 min direct (listed)', drive: 'about 23 hr 15 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Udaipur', flight: 'about 6 hr 55 min listed (incl. transfers)', train: 'no direct train listed - about 34 hr 37 min (listed)', bus: 'no direct bus listed - about 27 hr 45 min with changes', drive: 'about 25 hr 21 min' },
  },
  varanasi: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Varanasi', train: 'about 22.5 hr direct (2 trains a day)', bus: 'about 22 hr via Lucknow', drive: 'about 14 hr', flight: 'connecting flights listed via Delhi - check live times' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Varanasi', flight: 'connecting flights listed about every 4 hr', train: 'about 16.5 hr direct (2 days a week)', drive: 'about 11 hr' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Varanasi', flight: 'about 3 hr 53 min listed (incl. transfers)', train: 'about 26 hr 46 min direct (listed)', bus: 'no direct bus listed - about 25 hr 57 min with changes', drive: 'about 18 hr 44 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Varanasi', flight: 'about 5 hr 9 min listed (incl. transfers)', train: 'about 46 hr 5 min direct (listed)', bus: 'about 34 hr 45 min direct (listed)', drive: 'about 25 hr 38 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Varanasi', flight: 'about 3 hr 28 min listed (incl. transfers)', train: 'about 11 hr direct (listed)', bus: 'about 13 hr 30 min direct (listed)', drive: 'about 10 hr 2 min' },
  },
  leh: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Leh', flight: 'connecting flights listed via Delhi - check live times' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Leh', flight: 'direct flights listed, fastest about 2.5 hr', drive: 'about 10 hr 40 min driving - most travellers break the journey' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Leh', flight: 'about 4 hr 24 min listed (incl. transfers)', train: 'about 44 hr 33 min (listed)', bus: 'no direct bus listed - about 2 days 22 hr with changes', drive: 'about 27 hr 49 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Leh', flight: 'about 7 hr 40 min listed (incl. transfers)', bus: 'about 7 hr 40 min listed', drive: 'about 40 hr 45 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Leh', flight: 'about 6 hr 39 min listed (incl. transfers)', train: 'about 46 hr 56 min with change (listed)', drive: 'about 31 hr 36 min' },
  },
  manali: {
    'Amritsar': { src: 'https://www.redbus.in/bus-tickets/amritsar-to-manali', bus: 'direct buses - 22 listed on redBus, check live durations' },
    'Chandigarh': { src: 'https://www.redbus.in/bus-tickets/chandigarh-to-manali', bus: 'direct buses - 252 listed on redBus, check live durations' },
    "Mumbai": {"src": "https://www.rome2rio.com/s/Mumbai/Man%C4%81li", "flight": "Himachal Pradesh route: complete journey time not verified - check flights to Bhuntar or Chandigarh plus road transfer", "train": "no train to Manali town - rail journey needs onward road transfer; duration not verified", "bus": "Himachal Pradesh route duration not verified - use current search", "drive": "Himachal Pradesh route duration not verified - allow for mountain roads and breaks"},
    "Bengaluru": {"src": "https://www.rome2rio.com/s/Bengaluru/Man%C4%81li", "flight": "Himachal Pradesh route: complete journey time not verified - check flights to Bhuntar or Chandigarh plus road transfer", "train": "no train to Manali town - rail journey needs onward road transfer; duration not verified", "bus": "Himachal Pradesh route duration not verified - use current search", "drive": "Himachal Pradesh route duration not verified - allow for mountain roads and breaks"},
    "Kolkata": {"src": "https://www.rome2rio.com/s/Kolkata/Man%C4%81li", "flight": "Himachal Pradesh route: complete journey time not verified - check flights to Bhuntar or Chandigarh plus road transfer", "train": "no train to Manali town - rail journey needs onward road transfer; duration not verified", "bus": "Himachal Pradesh route duration not verified - use current search", "drive": "Himachal Pradesh route duration not verified - allow for mountain roads and breaks"},
  },
  goa: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Goa-India', flight: 'connecting flights listed about every 3 hr', train: 'about 36 hr (weekly direct to Madgaon)', bus: 'about 41.5 hr with changes - flying is practical', drive: 'about 29 hr' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Goa-India', flight: 'connecting flights listed about every 4 hr', train: 'about 33 hr (2 days a week)', drive: 'about 25 hr' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Goa-India', flight: 'about 4 hr 19 min listed (incl. transfers)', train: 'no direct train listed - about 15 hr 26 min (listed)', bus: 'no direct bus listed - about 13 hr 10 min with changes', drive: 'about 8 hr 39 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Goa-India', flight: 'about 5 hr 13 min listed (incl. transfers)', train: 'no direct train listed - about 42 hr 57 min (listed)', bus: 'no direct bus listed - about 2 days 1 hr with changes', drive: 'about 29 hr 46 min' },
  },
  kerala: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Kochi', flight: 'connecting flights, fastest about 8.5 hr', train: 'about 2 days 3 hr (weekly)', drive: 'about 38 hr' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Kochi', flight: 'connecting flights listed about every 2 hr, fastest about 7 hr', bus: 'about 41 hr with changes', drive: 'about 36 hr' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Kochi', flight: 'about 3 hr 55 min listed (incl. transfers)', train: 'no direct train listed - about 24 hr 44 min (listed)', bus: 'no direct bus listed - about 30 hr 1 min with changes', drive: 'about 19 hr 3 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Kochi', flight: 'about 7 hr 25 min listed (incl. transfers)', bus: 'no direct bus listed - about 44 hr 49 min with changes', drive: 'about 32 hr 22 min' },
  },
  mumbai: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Mumbai', flight: 'connecting flights listed about every 3 hr', train: 'about 24 hr (weekly fast train) to 39 hr (daily)', bus: 'about 34 hr via Jodhpur', drive: 'about 20 hr' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Mumbai', flight: 'direct flights listed hourly', train: 'about 20.5 hr (4 days a week)', drive: 'about 17.5 hr' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Mumbai', flight: 'about 4 hr 48 min listed (incl. transfers)', train: 'about 22 hr 50 min direct (listed)', bus: 'about 17 hr 45 min direct (listed)', drive: 'about 13 hr 41 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Mumbai', flight: 'no flight option listed' },
  },
  darjeeling: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Darjeeling', flight: 'connecting flights listed to Bagdogra via Delhi - check live', bus: 'about 41 hr via Noida and Siliguri', drive: 'about 23.5 hr' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Darjeeling', flight: 'flight + taxi, fastest about 7 hr', drive: 'about 20.5 hr' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Darjeeling', flight: 'about 5 hr 18 min listed (incl. transfers)', train: 'about 45 hr 31 min (listed)', bus: 'no direct bus listed - about 2 days 8 hr with changes', drive: 'about 28 hr 50 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Darjeeling', flight: 'about 6 hr 24 min listed (incl. transfers)', train: 'about 46 hr 20 min (listed)', bus: 'no direct bus listed - about 2 days 4 hr with changes', drive: 'about 34 hr 32 min' },
  },
  andaman: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Port-Blair', flight: 'connecting flights, fastest about 10.5 hr' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Port-Blair', flight: 'connecting flights, fastest about 8.5 hr' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Port-Blair', flight: 'about 4 hr 45 min listed (incl. transfers)' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Port-Blair', flight: 'direct flights listed, about 4 hr average (28 weekly planes)' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Port-Blair', flight: 'about 3 hr 50 min listed (incl. transfers)' },
  },
  jaisalmer: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Jaisalmer', flight: 'connecting flights listed about every 4 hr', bus: 'about 18 hr via Jodhpur', train: 'about 19 hr via Jalandhar and Phalodi', drive: 'about 10.5 hr' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Jaisalmer', flight: 'connecting flights listed about every 4 hr; train + flight about 7 hr', train: 'about 17 hr via Ambala and Lalgarh', drive: 'about 11 hr' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Jaisalmer', flight: 'about 3 hr 16 min listed (incl. transfers)', train: 'no direct train listed - about 22 hr 43 min (listed)', bus: 'no direct bus listed - about 22 hr 51 min with changes', drive: 'about 15 hr 19 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Jaisalmer', flight: 'about 7 hr 12 min listed (incl. transfers)', train: 'no direct train listed - about 47 hr 14 min (listed)', bus: 'no direct bus listed - about 25 hr 5 min with changes', drive: 'about 28 hr 30 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Jaisalmer', flight: 'about 7 hr 6 min listed (incl. transfers)', train: 'no direct train listed - about 32 hr 15 min (listed)', bus: 'no direct bus listed - about 42 hr 20 min with changes', drive: 'about 28 hr 31 min' },
  },
  rishikesh: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Rishikesh', bus: 'about 10 hr 45 min direct (3 buses a day)', drive: 'about 6.5 hr', flight: 'connecting flights to Dehradun, about 6 hr total' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Rishikesh', bus: 'about 5 hr direct (hourly)', train: 'about 6 hr 15 min via Ambala', drive: 'about 3 hr 15 min' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Rishikesh', flight: 'about 3 hr 54 min listed (incl. transfers)', train: 'no direct train listed - about 27 hr 4 min (listed)', bus: 'no direct bus listed - about 28 hr 29 min with changes', drive: 'about 17 hr 54 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Rish%C4%ABkesh', flight: 'about 5 hr 34 min listed (incl. transfers)', train: 'no direct train listed - about 46 hr 31 min (listed)', bus: 'no direct bus listed - about 40 hr 20 min with changes', drive: 'about 30 hr 26 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Rishikesh', flight: 'about 4 hr 23 min listed (incl. transfers)', train: 'no direct train listed - about 24 hr 57 min (listed)', bus: 'no direct bus listed - about 29 hr 13 min with changes', drive: 'about 19 hr 50 min' },
  },
  hampi: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Hampi', flight: 'about 15 hr (flight to Hubballi + train)', train: 'about 44 hr with changes', bus: 'about 2 days with changes', drive: 'about 27.5 hr' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Hampi', flight: 'flight + train, fastest about 9 hr 40 min', drive: 'about 25.5 hr' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Hampi', flight: 'about 6 hr 26 min listed (incl. transfers)', train: 'no direct train listed - about 14 hr 48 min (listed)', bus: 'no direct bus listed - about 16 hr 23 min with changes', drive: 'about 9 hr 46 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Hampi', flight: 'about 10 hr 35 min listed (incl. transfers)', train: 'no direct train listed - about 32 hr 44 min (listed)', bus: 'no direct bus listed - about 38 hr 26 min with changes', drive: 'about 25 hr 44 min' },
  },
  shillong: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Shillong', flight: 'connecting flights listed to Guwahati via Delhi - check live', bus: 'about 44 hr with changes - flying is practical', drive: 'about 30 hr' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Shillong', flight: 'connecting flights, fastest about 9 hr', drive: 'about 27 hr' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Shillong', flight: 'about 7 hr 7 min listed (incl. transfers)', train: 'about 11 hr 22 min (listed)', bus: 'no direct bus listed - about 2 days 18 hr with changes', drive: 'about 33 hr 11 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Shillong', flight: 'about 8 hr 53 min listed (incl. transfers)', bus: 'no direct bus listed - about 2 days 15 hr with changes', drive: 'about 35 hr 47 min' },
  },
  srinagar: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Srinagar', flight: 'about 3 hr 52 min listed (incl. transfers)', train: 'no direct train listed - about 10 hr with change', bus: 'about 8 hr 55 min direct (listed)', drive: 'about 5 hr 57 min' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Srinagar', flight: 'about 3 hr 2 min listed (incl. transfers)', train: 'no direct train listed - about 12 hr 25 min with change', bus: 'about 13 hr direct (listed)', drive: 'about 7 hr 46 min' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Srinagar', flight: 'about 4 hr 42 min listed (incl. transfers)', train: 'no direct train listed - about 36 hr 18 min (listed)', bus: 'no direct bus listed - about 2 days 5 hr with changes', drive: 'about 25 hr 42 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Srinagar', flight: 'about 6 hr 33 min listed (incl. transfers)', train: 'no direct train listed - about 2 days 1 hr with changes', bus: 'no direct bus listed - about 2 days 3 hr with changes', drive: 'about 36 hr 46 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Srinagar', flight: 'about 7 hr 7 min listed (incl. transfers)', train: 'about 41 hr 50 min (listed)', bus: 'no direct bus listed - about 43 hr 51 min with changes', drive: 'about 28 hr 36 min' },
  },
  shimla: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Shimla', bus: 'no direct bus listed - about 7 hr 7 min with change', train: 'no direct train listed', drive: 'about 4 hr 50 min' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Shimla', bus: 'about 1 hr 58 min direct (listed)', drive: 'about 1 hr 42 min' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Shimla', flight: 'about 7 hr 18 min listed (incl. transfers)', train: 'about 26 hr 31 min (listed)', bus: 'no direct bus listed - about 33 hr 34 min with changes', drive: 'about 18 hr 56 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Shimla', flight: 'about 8 hr 59 min listed (incl. transfers)', train: 'about 45 hr with change (listed)', bus: 'no direct bus listed - about 32 hr 58 min with changes', drive: 'about 31 hr 28 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Shimla', flight: 'about 7 hr 53 min listed (incl. transfers)', train: 'about 27 hr 40 min (listed)', bus: 'no direct bus listed - about 32 hr 11 min with changes', drive: 'about 22 hr 32 min' },
  },
  tirupati: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Tirupati', flight: 'about 8 hr 42 min listed (incl. transfers)', train: 'no direct train listed - about 46 hr 30 min with change', bus: 'no direct bus listed', drive: 'about 32 hr 11 min' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Tirupati', flight: 'about 7 hr 2 min listed (incl. transfers)', train: 'no direct train listed - about 36 hr 47 min with change', bus: 'no direct bus listed', drive: 'about 30 hr 9 min' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Tirupati', flight: 'about 5 hr 47 min listed (incl. transfers)', train: 'no direct train listed - about 19 hr 33 min (listed)', bus: 'no direct bus listed - about 23 hr 55 min with changes', drive: 'about 15 hr 53 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Tirupati', flight: 'about 3 hr 48 min listed (incl. transfers)', train: 'about 7 hr 33 min direct (listed)', bus: 'about 4 hr 7 min direct (listed)', drive: 'about 3 hr 34 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Tirupati', flight: 'about 6 hr 31 min listed (incl. transfers)', train: 'about 25 hr 50 min direct (listed)', drive: 'about 23 hr 30 min' },
  },
  bodhgaya: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Bodh-Gay%C4%81', flight: 'about 7 hr 36 min listed (incl. transfers)', train: 'no direct train listed - about 22 hr 58 min with change', bus: 'no direct bus listed - about 27 hr 46 min with changes', drive: 'about 17 hr 29 min' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Bodh-Gay%C4%81', flight: 'about 5 hr 6 min listed (incl. transfers)', train: 'no direct train listed - about 15 hr 52 min with change', bus: 'no direct bus listed - about 22 hr 40 min with changes', drive: 'about 14 hr 33 min' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Bodh-Gay%C4%81', flight: 'about 6 hr 26 min listed (incl. transfers)', train: 'no direct train listed - about 27 hr 53 min (listed)', bus: 'no direct bus listed - about 33 hr 10 min with changes', drive: 'about 21 hr 50 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Bodh-Gay%C4%81', flight: 'about 7 hr 52 min listed (incl. transfers)', train: 'no direct train listed - about 40 hr 29 min with change (listed)', bus: 'no direct bus listed - about 45 hr 49 min with changes', drive: 'about 28 hr 3 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Gaya', flight: 'about 2 hr 55 min listed (incl. transfers)', train: 'about 6 hr 7 min direct (listed)', bus: 'about 10 hr 10 min direct (listed)', drive: 'about 7 hr 31 min' },
  },
  ajmer: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Ajmer', train: 'about 19 hr 35 min direct (listed)', bus: 'no direct bus listed - about 13 hr 53 min with change', drive: 'about 9 hr 32 min' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Ajmer', flight: 'about 5 hr 41 min listed (incl. transfers)', train: 'about 12 hr 45 min direct (listed)', bus: 'about 10 hr 10 min direct (listed)', drive: 'about 7 hr 49 min' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Ajmer', flight: 'about 6 hr 1 min listed (incl. transfers)', train: 'about 16 hr 25 min direct (listed)', bus: 'no direct bus listed - about 24 hr 26 min with changes', drive: 'about 13 hr 12 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Ajmer', flight: 'about 8 hr 34 min listed (incl. transfers)', train: 'about 40 hr 15 min direct (listed)', bus: 'no direct bus listed - about 31 hr 11 min with changes', drive: 'about 26 hr 1 min' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Ajmer', flight: 'about 8 hr 16 min listed (incl. transfers)', train: 'about 26 hr 45 min direct (listed)', bus: 'no direct bus listed - about 32 hr 30 min with changes', drive: 'about 22 hr 3 min' },
  },
  haridwar: {
    'Amritsar': { src: 'https://www.rome2rio.com/s/Amritsar/Haridwar', train: 'about 9 hr 45 min direct (listed)', bus: 'no direct bus listed - about 10 hr 27 min with change', drive: 'about 6 hr 24 min' },
    'Chandigarh': { src: 'https://www.rome2rio.com/s/Chandigarh/Haridwar', train: 'about 4 hr 37 min listed (with change)', bus: 'about 5 hr 20 min (listed)', drive: 'about 3 hr 19 min' },
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Haridwar', flight: 'about 4 hr 45 min listed (incl. transfers)', train: 'no direct train listed - about 32 hr 40 min (listed)', bus: 'no direct bus listed - about 27 hr 50 min with changes', drive: 'about 17 hr 28 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Haridwar', flight: 'about 6 hr 31 min listed (incl. transfers)', train: 'no direct train listed - about 42 hr 6 min (listed)', bus: 'no direct bus listed - about 30 hr 14 min with changes', drive: 'about 30 hr' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Haridwar', flight: 'about 5 hr 15 min listed (incl. transfers)', train: 'no direct train listed - about 24 hr 1 min (listed)', bus: 'no direct bus listed - about 29 hr 5 min with changes', drive: 'about 19 hr 27 min' },
  },
  amritsar: {
    'Mumbai': { src: 'https://www.rome2rio.com/s/Mumbai/Amritsar', flight: 'about 5 hr 45 min listed (incl. transfers)', train: 'about 40 hr 35 min direct (listed)', bus: 'no direct bus listed - about 37 hr 57 min with changes', drive: 'about 19 hr 47 min' },
    'Bengaluru': { src: 'https://www.rome2rio.com/s/Bengaluru/Amritsar', flight: 'about 7 hr 31 min listed (incl. transfers)', train: 'no direct train listed - about 44 hr 12 min with change (listed)', bus: 'no direct bus listed - about 34 hr 5 min with changes', drive: 'about 32 hr' },
    'Kolkata': { src: 'https://www.rome2rio.com/s/Kolkata/Amritsar', flight: 'about 6 hr 15 min listed (incl. transfers)', train: 'about 26 hr 40 min direct (listed)', bus: 'no direct bus listed - about 33 hr 2 min with changes', drive: 'about 23 hr 57 min' },
  },
};

var ORIGINS = ['New Delhi', 'Mumbai', 'Bengaluru', 'Kolkata', 'Amritsar', 'Chandigarh', 'Chennai', 'Hyderabad'];
var ORIGIN_BUS_SLUG = { 'New Delhi': 'delhi', 'Mumbai': 'mumbai', 'Bengaluru': 'bangalore', 'Kolkata': 'kolkata', 'Amritsar': 'amritsar', 'Chandigarh': 'chandigarh', 'Chennai': 'chennai', 'Hyderabad': 'hyderabad' };

  var tpCurrentDest = null;
  function renderTransport(d, origin) {
    var tp = TRANSPORT[d.id]; if (!tp) return '';
    var o = origin || tp.hub;
    if (o === d.name || (d.id === 'delhi' && o === 'New Delhi')) return '<p class="tp-note">You are starting in this destination. Use local transport for your day plan; no intercity journey is needed.</p>';
    var enc = encodeURIComponent;
    var alt = (typeof TRANSPORT_ALT !== 'undefined' && TRANSPORT_ALT[d.id] && TRANSPORT_ALT[d.id][o]) || null;
    function linkFor(mode) {
      if (mode === 'flight') return ['https://www.google.com/travel/flights?q=' + enc('flights from ' + o + ' to ' + tp.flight.city), 'Search flights'];
      if (mode === 'train') return ['https://www.irctc.co.in/nget/train-search', 'Check trains on IRCTC'];
      if (mode === 'bus') {
        if (o === tp.hub) return ['https://www.redbus.in/bus-tickets/' + (ORIGIN_BUS_SLUG[o] || 'delhi') + '-to-' + tp.bus.slug, 'Search buses on redBus'];
        if (alt && alt.src.indexOf('redbus.in/bus-tickets/') !== -1) return [alt.src, 'Search buses on redBus'];
        return ['https://www.redbus.in/', 'Search buses on redBus'];
      }
      if (mode === 'drive') return ['https://www.google.com/maps/dir/?api=1&origin=' + enc(o) + '&destination=' + enc(tp.drive.city), 'Route on Google Maps'];
      return ['', ''];
    }
    var MODES = [['flight', '\u2708', 'Flight'], ['train', '\u{1F686}', 'Train'], ['bus', '\u{1F68C}', 'Bus'], ['drive', '\u{1F697}', 'Drive'], ['ship', '\u{1F6A2}', 'Ship']];
    var sel = '<label class="tp-from">Search live options from: <select id="tpFrom">' + ORIGINS.map(function (c) { return '<option' + (c === o ? ' selected' : '') + '>' + c + '</option>'; }).join('') + '</select></label>';
    var rows = [];
    var isRef = (o === tp.hub);
    MODES.forEach(function (m) {
      var t = tp[m[0]]; if (!t) return;
      var time;
      if (isRef) time = t.t + (t.note ? ' - ' + t.note : '');
      else if (alt && alt[m[0]]) time = alt[m[0]];
      else time = 'not listed for ' + o + ' on our route sources - use the live links below';
      var lk = m[0] === 'ship' ? ['', ''] : linkFor(m[0]);
      rows.push('<div class="tp-row"><span class="tp-mode">' + m[1] + ' ' + m[2] + '</span><span class="tp-time">' + time + '</span>' +
        (lk[0] ? '<a class="tp-link" href="' + lk[0] + '" target="_blank" rel="noopener">' + lk[1] + ' &nearr;</a>' : '<span></span>') + '</div>');
    });
    var out = sel + '<div class="tp-rows">' + rows.join('') + '</div>';
    if (isRef) {
      out += '<p class="tp-note">Durations and frequencies shown are typical values listed by the route source for the ' + tp.hub + ' to ' + d.name + ' route - they vary by service and season and are not live timings. <a href="' + tp.src + '" target="_blank" rel="noopener">Route source &nearr;</a></p>';
    } else if (alt) {
      out += '<p class="tp-note">Durations and frequencies shown are typical values listed by the route source for the ' + o + ' to ' + d.name + ' route - they vary by service and season and are not live timings. <a href="' + alt.src + '" target="_blank" rel="noopener">Route source &nearr;</a></p>' +
        '<p class="tp-ref-head">Reference route: ' + tp.hub + ' to ' + d.name + ' - typical times</p><ul class="tp-ref-list">' +
        MODES.filter(function (m) { return tp[m[0]]; }).map(function (m) {
          return '<li><b>' + m[2] + '</b> - ' + tp[m[0]].t + (tp[m[0]].note ? ' - ' + tp[m[0]].note : '') + '</li>';
        }).join('') + '</ul>';
    } else {
      out += '<p class="tp-ref-head">Reference route: ' + tp.hub + ' to ' + d.name + ' - typical times</p><ul class="tp-ref-list">' +
        MODES.filter(function (m) { return tp[m[0]]; }).map(function (m) {
          return '<li><b>' + m[2] + '</b> - ' + tp[m[0]].t + (tp[m[0]].note ? ' - ' + tp[m[0]].note : '') + '</li>';
        }).join('') + '</ul>' +
        '<p class="tp-note">Times above are typical scheduled durations for the ' + tp.hub + ' reference route only, not for ' + o + ' - the links above search live options from ' + o + '. <a href="' + tp.src + '" target="_blank" rel="noopener">Route source &nearr;</a></p>';
    }
    return out;
  }

  var DESTINATIONS = [
    {
      id: 'agra', name: 'Agra', state: 'Uttar Pradesh', region: 'north',
      vibes: ['heritage', 'culture'],
      blurb: 'Home of the Taj Mahal - marble at sunrise, Mughal forts, and a city built around wonder.',
      photo: 'photos/agra.jpg', alt: 'The Taj Mahal in Agra',
      best: 'Oct - Mar', months: [9, 10, 11, 0, 1, 2],
      festival: { name: 'Taj Mahotsav', when: '18 - 27 Feb every year', note: 'Ten days of crafts, food, dance and music at Shilpgram, by the Taj (incredibleindia.gov.in).' },
      ideal: '2 days',
      getting: [
        { text: 'Gatimaan Express, New Delhi to Agra - about 100 min', fare: 'check current fare', source: 'IRCTC', url: 'https://www.irctc.co.in' },
        { text: 'Yamuna Expressway from Delhi by road', fare: 'about 3.5 hrs drive' }
      ],
      places: ['Taj Mahal at sunrise', 'Agra Fort', 'Mehtab Bagh across the Yamuna', 'Fatehpur Sikri day trip'],
      food: [{ n: "Petha", diet: 'vegan', note: "translucent candied ash gourd - the sweet everyone carries home" }, { n: "Bedai with aloo sabzi", diet: 'veg', note: "the city's own spicy breakfast, gone by noon" }, { n: "Jalebi", diet: 'veg', note: "syrup-crisp spirals, eaten hot off the karahi" }, { n: "Mughlai chicken", diet: 'nonveg', note: "rich gravy cooking from the Taj-era kitchens" }],
      eats: [{ n: "The Salt Cafe", r: "4.6 (11.7k)", url: "https://www.google.com/maps/search/?api=1&query=The+Salt+Cafe%2C+AGRA&query_place_id=ChIJFRKBVjRxdDkRg_GPt2_UvCU", note: "multi-cuisine rooftop near the Taj", ta: "4.8" }, { n: "Shripati Dwarkadhish Restaurant", r: "4.7 (5.2k)", url: "https://www.google.com/maps/search/?api=1&query=Shripati+Dwarkadhish+Restaurant&query_place_id=ChIJOQgsEABxdDkRyhsluQYmq18", note: "busy pure-veg favourite in Rakabganj" }, { n: "Savi Veg & Vegan Restaurant", r: "4.8 (21)", url: "https://www.google.com/maps/search/?api=1&query=Savi+Veg+%26+Vegan+Restaurant&query_place_id=ChIJ0d5fWgBxdDkRJco3jlBt_x4", note: "small all veg-and-vegan spot in Tajganj" }],
      stays: [{ n: "Hotel Sunrise", r: "4.8 (345)", url: "https://www.google.com/maps/search/?api=1&query=Hotel+Sunrise&query_place_id=ChIJjUZ7aTJxdDkRNRAfoUfgikE", note: "budget stay on the Taj East Gate road" }, { n: "The Taj Homes", r: "4.7 (139)", url: "https://www.google.com/maps/search/?api=1&query=The+Taj+Homes&query_place_id=ChIJjWlsJzJxdDkR7NV3lUzU0Bs", note: "homestay-style rooms near Shilpgram" }],
      shops: [{ n: "Sadar Bazar", note: "leather goods, shoes and late-night chaat" }, { n: "Kinari Bazar", note: "old-city lanes of trim, bangles and marble inlay" }, { n: "Subhash Emporium", note: "long-running marble-inlay workshop" }]
    },
    {
      id: 'jaipur', name: 'Jaipur', state: 'Rajasthan', region: 'north',
      vibes: ['heritage', 'culture'],
      blurb: 'The Pink City - hilltop forts, palace facades, bazaars of gems and block prints.',
      photo: 'photos/jaipur.jpg', alt: 'Amber Fort, Jaipur',
      best: 'Oct - Mar', months: [9, 10, 11, 0, 1, 2],
      festival: { name: 'Jaipur Literature Festival', when: 'January', note: 'Five days of authors and ideas at Diggi Palace, billed as the world\'s largest free literary festival.' },
      ideal: '3 days',
      getting: [
        { text: 'Vande Bharat, Delhi to Jaipur', fare: '3 hrs 37 min', source: 'DNA India' },
        { text: 'By road from Delhi via NH48', fare: 'about 5 hrs drive' }
      ],
      places: ['Amber Fort', 'Hawa Mahal', 'City Palace and Jantar Mantar', 'Nahargarh Fort at sunset'],
      food: [{ n: "Dal bati churma", diet: 'veg', note: "the Rajasthani signature: baked baati, dal, sweet churma" }, { n: "Pyaaz kachori", diet: 'vegan', note: "flaky onion-stuffed kachori, usually dairy-free" }, { n: "Laal maas", diet: 'nonveg', note: "fiery mutton curry from the Rajput kitchens" }, { n: "Ghewar", diet: 'veg', note: "honeycomb-disc sweet soaked in saffron syrup" }],
      eats: [{ n: "Handi Restaurant", r: "4.1 (13.3k)", url: "https://www.google.com/maps/search/?api=1&query=Handi+restaurant+jaipur&query_place_id=ChIJERP0VLG2bTkRrVzfUlilTMg", note: "MI Road institution for laal maas and handi meat", ta: "3.9" }, { n: "Govindam Retreat", r: "4.4 (9.6k)", url: "https://www.google.com/maps/search/?api=1&query=Govindam+Retreat&query_place_id=ChIJhd3BQEmxbTkRklY1_w4_Qfk", note: "sprawling pure-veg Rajasthani thali hall" }, { n: "Ratnika - A Vegetarian Restaurant", r: "4.7 (661)", url: "https://www.google.com/maps/search/?api=1&query=Ratnika+-+A+Vegetarian+Restaurant&query_place_id=ChIJzxpcTUK3bTkR_0uU7Jv-uFI", note: "vegetarian dining on MI Road" }],
      stays: [{ n: "Moustache Jaipur", r: "4.5 (4.3k)", url: "https://www.google.com/maps/search/?api=1&query=Moustache+Jaipur&query_place_id=ChIJ7cSGfPizbTkR1-KDSgp4T5o", note: "backpacker hostel with a rooftop, near Sindhi Camp" }, { n: "Jaipur View", r: "4.5 (287)", url: "https://www.google.com/maps/search/?api=1&query=Jaipur+View&query_place_id=ChIJjbdFcVGxbTkRHpVdJUKRIYs", note: "old-city guest house by Gangori Bazar" }],
      shops: [{ n: "Johari Bazaar", note: "gems, kundan and meenakari jewellery" }, { n: "Bapu Bazaar", note: "bandhani textiles, mojris and home linen" }, { n: "Kishanpole Bazaar", note: "blue pottery and carved wooden craft" }]
    },
    {
      id: 'udaipur', name: 'Udaipur', state: 'Rajasthan', region: 'west',
      vibes: ['heritage', 'culture'],
      blurb: 'Lakes, white palaces and rooftop dinners - Rajasthan at its most romantic.',
      photo: 'photos/udaipur.jpg', alt: 'City Palace of Udaipur',
      credit: 'Photo: Hirumon, Wikimedia Commons',
      best: 'Sep - Mar', months: [8, 9, 10, 11, 0, 1, 2],
      festival: { name: 'Mewar Festival (Gangaur)', when: 'Mar - Apr', note: 'Processions, song and decorated boats welcoming spring on Lake Pichola.' },
      ideal: '3 days',
      getting: [
        { text: 'Flight, New Delhi to Udaipur', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+from+New+Delhi+to+Udaipur' },
        { text: 'Flight, Mumbai to Udaipur', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+from+Mumbai+to+Udaipur' }
      ],
      places: ['City Palace', 'Lake Pichola boat ride', 'Jag Mandir island', 'Saheliyon ki Bari'],
      food: [{ n: "Dal baati churma", diet: 'veg', note: "the Mewari thali centrepiece, ghee and all" }, { n: "Gatte ki sabzi", diet: 'veg', note: "gram-flour dumplings in a yoghurt curry" }, { n: "Laal maas", diet: 'nonveg', note: "the fiery Mewari mutton" }, { n: "Kachori", diet: 'vegan', note: "hot dal or onion kachori - the old-city breakfast" }],
      eats: [{ n: "Millets Of Mewar Restaurant", r: "4.6 (5k)", url: "https://www.google.com/maps/search/?api=1&query=Millets+Of+Mewar+Restaurant&query_place_id=ChIJi-GSMmblZzkRJNSiZxMnteA", note: "light millet-based menu, vegan-friendly picks", ta: "4.3" }, { n: "1559 AD", r: "4.4 (6.4k)", url: "https://www.google.com/maps/search/?api=1&query=1559+AD&query_place_id=ChIJ-x0mOmvlZzkRXl9E1mRpniE", note: "Rajasthani and continental near Fateh Sagar" }, { n: "Yummy Yoga rooftop restaurant", r: "4.7 (4.7k)", url: "https://www.google.com/maps/search/?api=1&query=Yummy+Yoga+rooftop+restaurant&query_place_id=ChIJl8WCzWflZzkRayIoutinHJI", note: "rooftop plates near Hanuman Ghat" }],
      stays: [{ n: "City & Palace View Guest House", r: "4.9 (556)", url: "https://www.google.com/maps/search/?api=1&query=City+%26+Palace+view+guest+house&query_place_id=ChIJwbSR31nlZzkRtflIfShtH-g", note: "old-city guest house named for its palace view" }, { n: "Lake Face Guest House", r: "4.6 (113)", url: "https://www.google.com/maps/search/?api=1&query=Lake+Face+guest+house&query_place_id=ChIJ_6--pGjlZzkRRd2Yn1zOc3A", note: "simple rooms by Chand Pol, near the lakefront" }],
      shops: [{ n: "Hathi Pol Bazaar", note: "miniature paintings, mojris and handicrafts" }, { n: "Bada Bazaar", note: "bandhej fabrics, silver and camel-leather goods" }, { n: "Jagdish Chowk lanes", note: "souvenir and art stalls by the temple steps" }]
    },
    {
      id: 'amritsar', name: 'Amritsar', state: 'Punjab', region: 'north',
      vibes: ['culture', 'heritage', 'spiritual'],
      blurb: 'The Golden Temple shimmering at dusk, langar for all, and the beating retreat at Wagah.',
      photo: 'photos/amritsar.jpg', alt: 'The Golden Temple in Amritsar',
      best: 'Oct - Mar', months: [9, 10, 11, 0, 1, 2],
      festival: { name: 'Baisakhi', when: '13 - 14 Apr', note: 'Punjab\'s harvest festival - the Golden Temple glows, the city dances.' },
      ideal: '2 days',
      getting: [
        { text: 'Vande Bharat, Delhi to Amritsar Jn', fare: 'daily service', source: 'erail.in' },
        { text: 'By road from Delhi via NH44', fare: 'about 8 hrs drive' }
      ],
      places: ['Golden Temple at dawn and dusk', 'Jallianwala Bagh', 'Wagah border ceremony', 'Partition Museum'],
      food: [{ n: "Amritsari kulcha", diet: 'veg', note: "crisp tandoor kulcha stuffed with potato or paneer" }, { n: "Pindi chole", diet: 'vegan', note: "dark tea-steeped chickpeas, cooked without onion or garlic" }, { n: "Amritsari fish", diet: 'nonveg', note: "gram-flour battered fish, fried crisp" }, { n: "Lassi", diet: 'veg', note: "thick curd lassi under a slab of malai" }],
      eats: [{ n: "Kesar Da Dhaba", r: "4.0 (27.6k)", url: "https://www.google.com/maps/search/?api=1&query=Kesar+Da+Dhaba&query_place_id=ChIJH5Qnd6p8GTkRFk76a4hv3vw", note: "the old-city dhaba famous for slow-cooked dal makhani", ta: "4.1" }, { n: "Bhai Kulwant Singh Kulchian Wale", r: "4.3 (6.3k)", url: "https://www.google.com/maps/search/?api=1&query=Bhai+Kulwant+Singh+Kulchian+Wale&query_place_id=ChIJjR_ayq18GTkRx_OlWBLEsPU", note: "the kulcha name near the Golden Temple" }, { n: "Haveli", r: "4.5 (27.2k)", url: "https://www.google.com/maps/search/?api=1&query=Haveli&query_place_id=ChIJxfJd04LWGzkRGmYiv7nHFgc", note: "Punjabi village-theme thali stop on GT Road" }],
      stays: [{ n: "4N Home Stay", r: "4.8 (781)", url: "https://www.google.com/maps/search/?api=1&query=4N+Home+Stay+%28Golden+Temple+View%29&query_place_id=ChIJm0qzh9N9GTkRYk3Sab5XnPo", note: "guest house named for its Golden Temple view" }, { n: "Guru Kirpa Guest House", r: "4.4 (773)", url: "https://www.google.com/maps/search/?api=1&query=Guru+Kirpa+Guest+House&query_place_id=ChIJy40qHKZ8GTkRGZrDw6p8P6k", note: "budget rooms in Katra Ahluwalia" }],
      shops: [{ n: "Hall Bazaar", note: "phulkari dupattas and Punjabi juttis" }, { n: "Katra Jaimal Singh", note: "wedding wear and fabric lanes" }, { n: "Guru Bazaar", note: "silver jewellery in the old city" }]
    },
    {
      id: 'varanasi', name: 'Varanasi', state: 'Uttar Pradesh', region: 'north',
      vibes: ['culture', 'heritage', 'spiritual'],
      blurb: 'One of the world\'s oldest living cities - ghats, aarti flames and dawn boats on the Ganga.',
      photo: 'photos/varanasi.jpg', alt: 'Ghats of Varanasi on the Ganga',
      best: 'Nov - Feb', months: [10, 11, 0, 1],
      festival: { name: 'Dev Deepawali', when: 'Nov, 15 days after Diwali', note: 'A million lamps line every ghat - Varanasi\'s most photographed night.' },
      ideal: '2 - 3 days',
      getting: [
        { text: 'Flight, New Delhi to Varanasi', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+from+New+Delhi+to+Varanasi' },
        { text: 'Vande Bharat, Delhi to Varanasi', fare: 'day train', source: 'vBooking' }
      ],
      places: ['Ganga aarti at Dashashwamedh Ghat', 'Sunrise boat ride past the ghats', 'Kashi Vishwanath corridor', 'Sarnath, where Buddha first taught'],
      food: [{ n: "Baati chokha", diet: 'veg', note: "baked wheat balls with smoky mashed vegetables" }, { n: "Kachori sabzi", diet: 'vegan', note: "the gali breakfast of crisp kachori and potato curry" }, { n: "Tamatar chaat", diet: 'vegan', note: "the city's own spicy tomato chaat" }, { n: "Malaiyo", diet: 'veg', note: "winter-only saffron milk foam - Varanasi is proudly vegetarian" }],
      eats: [{ n: "Desi Mandapam Baati Chokha", r: "4.9 (16.2k)", url: "https://www.google.com/maps/search/?api=1&query=Desi+Mandapam+Baati+Chokha+Restaurant&query_place_id=ChIJ_5KbAkkxjjkR60YNSPGJK00", note: "the baati-chokha specialist near Durgakund" }, { n: "Baati Chokha Restaurant", r: "4.2 (17.5k)", url: "https://www.google.com/maps/search/?api=1&query=Baati+Chokha+Restaurant&query_place_id=ChIJsVGD7QoujjkR0wdXqrKYMRw", note: "the original Teliyabag baati-chokha house", ta: "4.2" }, { n: "Vegano", r: "4.8 (43)", url: "https://www.google.com/maps/search/?api=1&query=Vegano&query_place_id=ChIJTdITOoYtjjkRooAGVK9DvUw", note: "tiny vegan cafe in Sigra" }],
      stays: [{ n: "Family Guest House", r: "4.3 (1.2k)", url: "https://www.google.com/maps/search/?api=1&query=Family+Guest+House&query_place_id=ChIJ53K-N-IxjjkRIGKYvyK-vsc", note: "long-running budget stay on Dashashwamedh Ghat road" }, { n: "River View Guest House", r: "4.5 (322)", url: "https://www.google.com/maps/search/?api=1&query=River+View+Guest+House+%7C+Hotel+in+Varanasi+%7C+Guest+house+in+Varanasi&query_place_id=ChIJP0CMQGYxjjkRE7lRvoME5KE", note: "ghat-side guest house, named for the river view" }],
      shops: [{ n: "Vishwanath Gali", note: "Banarasi silk sarees and brocade" }, { n: "Thatheri Bazar", note: "hand-beaten brass and copper ware" }, { n: "Godowlia Market", note: "the everything market on the temple approach" }]
    },
    {
      id: 'leh', name: 'Leh & Ladakh', state: 'Ladakh', region: 'north',
      vibes: ['mountains', 'adventure'],
      blurb: 'High desert passes, turquoise lakes and monasteries above the clouds.',
      photo: 'photos/ladakh.jpg', alt: 'Mountains of Ladakh',
      best: 'May - Sep', months: [4, 5, 6, 7, 8],
      festival: { name: 'Hemis Tsechu', when: 'Jun - Jul', note: 'Masked cham dances at Hemis Monastery, Ladakh\'s grandest monastic festival (incredibleindia.gov.in).' },
      ideal: '5 - 7 days',
      getting: [
        { text: 'Flight, New Delhi to Leh - one-way economy, 28 Nov 2026', fare: 'from $77.60', source: 'Duffel live quote, 30 Oct' },
        { text: 'Flight, Mumbai to Leh', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+from+Mumbai+to+Leh' }
      ],
      places: ['Pangong Lake', 'Nubra Valley and the dunes at Hunder', 'Shanti Stupa at sunset', 'Hemis and Thiksey monasteries'],
      food: [{ n: "Momos", diet: 'both', note: "steamed dumplings, veg or meat, with fiery chilli achar" }, { n: "Thukpa", diet: 'both', note: "hand-pulled noodle soup for cold evenings" }, { n: "Skyu", diet: 'veg', note: "Ladakhi thumb-pressed pasta stewed with vegetables" }, { n: "Butter tea (gur gur chai)", diet: 'veg', note: "salty churned tea with yak butter" }],
      eats: [{ n: "Tsas by Dolkhar", r: "4.7 (1k)", url: "https://www.google.com/maps/search/?api=1&query=Tsas+by+Dolkhar&query_place_id=ChIJuR5Awpnr_TgR6eI5R5089Ho", note: "Ladakhi slow-food kitchen on Lower Tukcha road", ta: "4.8" }, { n: "Ladakhi Organic Food Restaurant", r: "4.7 (219)", url: "https://www.google.com/maps/search/?api=1&query=Ladakhi+Organic+Food+Restaurant+100%25+veg&query_place_id=ChIJmTG3-Szr_TgRYGRnqTixL_c", note: "100% veg Ladakhi home-style cooking" }, { n: "Khanaval by Rover's Den", r: "4.7 (417)", url: "https://www.google.com/maps/search/?api=1&query=Khanaval+by+Rover%27s+Den&query_place_id=ChIJWzhtGEXr_TgRgKqiRDbpgYo", note: "local kitchen in the main market" }],
      stays: [{ n: "Rabyang Guest House", r: "4.9 (82)", url: "https://www.google.com/maps/search/?api=1&query=Rabyang+Guest+House&query_place_id=ChIJueZLrMbr_TgRAoqQlJZCbA8", note: "family guest house on Changspa road" }, { n: "Zaltak Guest House & Hostel", r: "4.4 (325)", url: "https://www.google.com/maps/search/?api=1&query=Zaltak+Guest+House+And+Hostel&query_place_id=ChIJvUWI2Dvr_TgRwQw-q__tnBA", note: "budget beds on Upper Tukcha road" }],
      shops: [{ n: "Leh Main Bazaar", note: "pedestrian lanes of apricots, woollens and prayer flags" }, { n: "Tibetan Market (Moti Market)", note: "refugee-market stalls for handicrafts" }, { n: "Pashmina shops, Main Bazaar", note: "ask for genuine Changthang weave" }]
    },
    {
      id: 'manali', name: 'Manali', state: 'Himachal Pradesh', region: 'north',
      vibes: ['mountains', 'adventure'],
      blurb: 'Cedar forests, snow points and café-lined old town lanes in the Kullu valley.',
      photo: 'photos/manali.jpg', alt: 'Mountains near Manali',
      credit: 'Photo: Shameer Thajudeen, Wikimedia Commons',
      best: 'Oct - Jun', months: [9, 10, 11, 0, 1, 2, 3, 4, 5],
      festival: { name: 'International Kullu Dussehra', when: 'October each year', note: 'A week of deities, drums and fairs in nearby Kullu; the 2026 edition ran 21 - 27 Oct (hpkullu.nic.in).' },
      ideal: '3 - 4 days',
      getting: [
        { text: 'Flight, New Delhi to Kullu (Bhuntar, 50 km away)', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+from+New+Delhi+to+Kullu' },
        { text: 'Overnight Volvo bus from Delhi', fare: 'about 12 - 14 hrs' }
      ],
      places: ['Solang Valley', 'Hidimba Devi Temple', 'Old Manali lanes and cafes', 'Rohtang Pass (permit needed)'],
      food: [{ n: "Siddu", diet: 'veg', note: "steamed wheat bun with walnut-poppy filling, eaten with ghee" }, { n: "Himachali dham", diet: 'veg', note: "the festive platter: madra, rice and meetha" }, { n: "River trout", diet: 'nonveg', note: "grilled or curried trout from the Beas" }, { n: "Chana chaat", diet: 'vegan', note: "street-side spiced chickpeas with lemon" }],
      eats: [{ n: "Cafe 1986", r: "4.6 (12.8k)", url: "https://www.google.com/maps/search/?api=1&query=Cafe+1986&query_place_id=ChIJaznY7syJBDkRIuRAhuFlpxE", note: "busy cafe above Mall Road", ta: "4.2" }, { n: "Southern Souls Cafe", r: "4.9 (2.2k)", url: "https://www.google.com/maps/search/?api=1&query=Southern+Souls+%C2%AE+Cafe+%28Pure+Vegetarian%29&query_place_id=ChIJi9z5bAOHBDkRoUwzlPOmJtQ", note: "pure vegetarian cafe near Hadimba road" }, { n: "Madras Cafe", r: "4.7 (2.5k)", url: "https://www.google.com/maps/search/?api=1&query=Madras+Cafe&query_place_id=ChIJrbYaCJeHBDkRghWoKm0Qj2Q", note: "South Indian tiffin on Log Huts road" }],
      stays: [{ n: "La Heim Hostels Manali", r: "4.9 (193)", url: "https://www.google.com/maps/search/?api=1&query=La+Heim+Hostels+Manali&query_place_id=ChIJsR_RmwqHBDkRGQRUcnjHfbI", note: "Old Manali hostel near Goshal road" }, { n: "Gautam Cottage Manali", r: "4.7 (351)", url: "https://www.google.com/maps/search/?api=1&query=Gautam+Cottage+Manali&query_place_id=ChIJSRv6AsCJBDkRREv8cjNv0Ww", note: "family cottage stay in Aleo" }],
      shops: [{ n: "Mall Road", note: "shawls, woollens and Kullu caps" }, { n: "Tibetan Market", note: "sweaters, silver and prayer wheels" }, { n: "Old Manali market lane", note: "cafes, handicrafts and hemp goods" }]
    },
    {
      id: 'goa', name: 'Goa', state: 'Goa', region: 'west',
      vibes: ['beaches', 'culture'],
      blurb: 'Portuguese lanes, palm-backed beaches and long golden evenings on the Arabian Sea.',
      photo: 'photos/goa.jpg', alt: 'A beach in Goa',
      best: 'Nov - Feb', months: [10, 11, 0, 1],
      festival: { name: 'Goa Carnival', when: 'February', note: 'Four days of parades and music before Lent, a Portuguese-era legacy.' },
      ideal: '4 - 5 days',
      getting: [
        { text: 'Flight, New Delhi to Goa - one-way economy, 28 Nov 2026', fare: 'from $115.80', source: 'Duffel live quote, 30 Oct' },
        { text: 'Flight, Mumbai to Goa', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+from+Mumbai+to+Goa' }
      ],
      places: ['Palolem and the southern beaches', 'Fontainhas, the Latin quarter', 'Fort Aguada', 'Old Goa churches'],
      food: [{ n: "Goan fish curry rice", diet: 'nonveg', note: "coconut-tamarind curry - the daily plate" }, { n: "Chicken cafreal", diet: 'nonveg', note: "green-masala fry from the Portuguese-era kitchen" }, { n: "Sol kadhi", diet: 'vegan', note: "pink kokum-and-coconut cooler" }, { n: "Bebinca", diet: 'veg', note: "the layered coconut-milk queen of Goan desserts" }],
      eats: [{ n: "The Fisherman's Wharf Panjim", r: "4.7 (29.4k)", url: "https://www.google.com/maps/search/?api=1&query=The+Fisherman%27s+Wharf+Panjim&query_place_id=ChIJ50Z0QY3AvzsRhLg2PTRva9I", note: "Goan seafood house on 18th June Road", ta: "4.9" }, { n: "Kokni Kanteen", r: "4.2 (12.2k)", url: "https://www.google.com/maps/search/?api=1&query=Kokni+Kanteen+Panaji&query_place_id=ChIJtyc9_I7AvzsRdhrr8_k-fL4", note: "serving its legendary fish thali since 1972" }, { n: "Greenr Cafe", r: "4.7 (492)", url: "https://www.google.com/maps/search/?api=1&query=Greenr+Cafe%2C+Panjim&query_place_id=ChIJ46m9edLBvzsR7xa6AB8GMno", note: "plant-forward cafe in Fontainhas" }],
      stays: [{ n: "Palm Air by Goa Signature Stays", r: "4.5 (2.2k)", url: "https://www.google.com/maps/search/?api=1&query=Palm+Air+by+Goa+Signature+Stays&query_place_id=ChIJbVXlz-vAvzsRnrLggQtFWPE", note: "aparthotel floors near Miramar beach" }, { n: "Hotel Balaji Inn Panjim", r: "4.6 (69)", url: "https://www.google.com/maps/search/?api=1&query=Hotel+Balaji+Inn+Panjim&query_place_id=ChIJ3Y-sAK7BvzsRVxRHSIp0Wk0", note: "simple rooms off 18th June Road" }],
      shops: [{ n: "Anjuna Flea Market", note: "the Wednesday bazaar of clothes, jewellery and curios" }, { n: "Panjim Municipal Market", note: "cashews, spices, chorizo and bebinca" }, { n: "Mapusa Friday Market", note: "the locals' produce and pottery bazaar" }]
    },
    {
      id: 'kerala', name: 'Kerala', state: 'Kerala', region: 'south',
      vibes: ['beaches', 'culture'],
      blurb: 'Backwater houseboats, tea-green hills and some of India\'s gentlest coastlines.',
      photo: 'photos/kerala.jpg', alt: 'Backwaters of Kerala',
      best: 'Sep - Mar', months: [8, 9, 10, 11, 0, 1, 2],
      festival: { name: 'Onam', when: 'Aug - Sep, ten days', note: 'Flower carpets, snake-boat races and the grand Onasadya feast (keralatourism.org).' },
      ideal: '5 - 7 days',
      getting: [
        { text: 'Flight, New Delhi to Kochi - one-way economy, 28 Nov 2026', fare: 'from $148.40', source: 'Duffel live quote, 30 Oct' },
        { text: 'Flight, Mumbai to Kochi', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+from+Mumbai+to+Kochi' }
      ],
      places: ['Alleppey houseboat night', 'Fort Kochi\'s Chinese fishing nets', 'Munnar tea estates', 'Kumarakom bird sanctuary'],
      food: [{ n: "Appam with stew", diet: 'both', note: "lacy rice hoppers with a veg or chicken stew" }, { n: "Karimeen pollichathu", diet: 'nonveg', note: "pearl-spot fish grilled in a banana leaf" }, { n: "Sadhya", diet: 'veg', note: "the banana-leaf feast of many little curries" }, { n: "Puttu and kadala", diet: 'vegan', note: "steamed rice cylinders with black-chickpea curry" }],
      eats: [{ n: "Fort House Restaurant", r: "4.7 (421)", url: "https://www.google.com/maps/search/?api=1&query=Fort+House+Restaurant&query_place_id=ChIJ-SI39UdtCDsRol8jBNyY-uA", note: "Kerala kitchen on Calvathy road", ta: "4.3" }, { n: "Fort Paragon by Calicut Paragon", r: "4.5 (3.2k)", url: "https://www.google.com/maps/search/?api=1&query=Fort+Paragon+Restaurant+by+Calicut+Paragon&query_place_id=ChIJN0lto-ZtCDsRLw4k7bwKxWA", note: "the Malabar biryani and seafood name" }, { n: "Coriander Vegetarian Restaurant", r: "4.7 (710)", url: "https://www.google.com/maps/search/?api=1&query=Coriander+Vegetarian+Restaurant&query_place_id=ChIJr1E7kpVtCDsRl5VXmmKz4NM", note: "all-veg stop on Napier Street" }],
      stays: [{ n: "The Hosteller Fort Kochi, Ocean Edge", r: "4.7 (1.3k)", url: "https://www.google.com/maps/search/?api=1&query=The+Hosteller+Fort+Kochi%2C+Ocean+Edge&query_place_id=ChIJL2ubhOttCDsRWVU5PE_iYGY", note: "dorms and private rooms by Tower Road" }, { n: "Fort Bridge View Homestay", r: "4.3 (209)", url: "https://www.google.com/maps/search/?api=1&query=Fort+Bridge+View+Homestay&query_place_id=ChIJuT3RGjRtCDsRKvrdMM4UIvk", note: "homestay on Princess Street" }],
      shops: [{ n: "Jew Town, Mattancherry", note: "antiques and spice stalls" }, { n: "Princess Street", note: "cottage shops and cafes in heritage facades" }, { n: "Broadway, Ernakulam", note: "the locals' everything market" }]
    },
    {
      id: 'mumbai', name: 'Mumbai', state: 'Maharashtra', region: 'west',
      vibes: ['city', 'culture'],
      blurb: 'The maximum city - art deco sea fronts, street food, studios and impossible energy.',
      photo: 'photos/mumbai.jpg', alt: 'Gateway of India and the Taj Palace, Mumbai',
      credit: 'Photo: Mahesh I., Wikimedia Commons',
      best: 'Nov - Feb', months: [10, 11, 0, 1],
      festival: { name: 'Ganesh Chaturthi', when: 'Aug - Sep', note: 'Ten days of idols, drums and seaside immersions - Mumbai at full volume.' },
      ideal: '2 - 3 days',
      getting: [
        { text: 'India\'s busiest hub', fare: 'direct flights from every major city' },
        { text: 'Trains from Delhi, Goa, the south and the north', fare: 'all classes daily' }
      ],
      places: ['Gateway of India and Colaba', 'Marine Drive after dark', 'Elephanta Caves', 'Bandra\'s street art and cafes'],
      food: [{ n: "Vada pav", diet: 'veg', note: "the city's burger: batata vada in pav with chutneys" }, { n: "Bhel puri", diet: 'vegan', note: "puffed-rice chaat tossed at the beach carts" }, { n: "Pav bhaji", diet: 'veg', note: "butter-mashed vegetables with toasted pav" }, { n: "Seekh kebab rolls", diet: 'nonveg', note: "late-night grills off Colaba's coal skewers" }],
      eats: [{ n: "Leopold Cafe", r: "4.2 (33.1k)", url: "https://www.google.com/maps/search/?api=1&query=Leopold+Cafe&query_place_id=ChIJqSNr-8DR5zsRosXwmBExzRw", note: "the Colaba landmark running since the 1870s", ta: "3.9" }, { n: "Burma Burma Restaurant & Tea Room", r: "4.5 (4.8k)", url: "https://www.google.com/maps/search/?api=1&query=Burma+Burma+Restaurant+%26+Tea+Room&query_place_id=ChIJs9B0FMPR5zsRUzOnTNrApMY", note: "vegetarian Burmese tea-room, vegan-friendly" }, { n: "Bayview Cafe", r: "4.2 (3.7k)", url: "https://www.google.com/maps/search/?api=1&query=Bayview+Cafe&query_place_id=ChIJc1cDbb_R5zsRaO0QnDd1ohQ", note: "Colaba cafe named for the bay it faces" }],
      stays: [{ n: "Apollo Guest House", r: "4.8 (223)", url: "https://www.google.com/maps/search/?api=1&query=Apollo+Guest+House+%E2%80%93+Colaba+Causeway&query_place_id=ChIJj230jXTR5zsRqvWumXJLdg0", note: "budget rooms on Colaba Causeway" }, { n: "Evelyn Guest House", r: "4.3 (470)", url: "https://www.google.com/maps/search/?api=1&query=Evelyn+Guest+House&query_place_id=ChIJXxEkoMDR5zsRUSGp11FK5xA", note: "old-school guest house on Henry Road" }],
      shops: [{ n: "Colaba Causeway", note: "street stalls of jewellery, bags and curios" }, { n: "Crawford Market", note: "heritage halls of fruit, spice and dry fruit" }, { n: "Chor Bazaar", note: "the vintage and antique lanes" }]
    },
    {
      id: 'darjeeling', name: 'Darjeeling', state: 'West Bengal', region: 'east',
      vibes: ['mountains', 'culture'],
      blurb: 'Tea gardens, toy trains and Kanchenjunga filling the morning sky.',
      photo: 'photos/darjeeling.jpg', alt: 'Tea garden in Darjeeling',
      credit: 'Photo: Sourabh Biswas, Wikimedia Commons',
      best: 'Mar - May, Oct - Dec', months: [2, 3, 4, 9, 10, 11],
      festival: { name: 'Darjeeling Carnival', when: 'November', note: 'Ten days of music, food and tea ceremonies started by local youth (Wikipedia).' },
      ideal: '3 - 4 days',
      getting: [
        { text: 'Flight, New Delhi to Bagdogra (about 70 km away)', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+from+New+Delhi+to+Bagdogra' },
        { text: 'Toy train, New Jalpaiguri to Darjeeling', fare: 'heritage ride' }
      ],
      places: ['Tiger Hill sunrise over Kanchenjunga', 'Darjeeling Himalayan Railway', 'Happy Valley tea estate', 'Batasia Loop'],
      food: [{ n: "Momos", diet: 'both', note: "steamed or fried, with tomato-chilli achar" }, { n: "Thukpa", diet: 'both', note: "the noodle soup of the hills" }, { n: "Shabalay", diet: 'nonveg', note: "crisp fried meat pies, Tibetan-style" }, { n: "Aloo dum", diet: 'vegan', note: "hill potatoes in a spicy gravy" }],
      eats: [{ n: "Kunga Restaurant", r: "4.2 (4.2k)", url: "https://www.google.com/maps/search/?api=1&query=Kunga+Restaurant&query_place_id=ChIJR1GHUZIu5DkRyHjG7gkxQRU", note: "the Gandhi Road Tibetan favourite", ta: "4.4" }, { n: "Glenary's", r: "4.3 (22k)", url: "https://www.google.com/maps/search/?api=1&query=Glenary%27s%E2%80%94+Bakery%2C+Resturant+%26+Pub&query_place_id=ChIJt2_v6Oou5DkRDJ4yqWaK5MQ", note: "colonial-era bakery and cafe on Nehru Road" }, { n: "Grains Pure Veg by Udaan Nirvana", r: "4.9 (1.1k)", url: "https://www.google.com/maps/search/?api=1&query=Grains+Pure+Veg+by+Udaan+Nirvana%2C+Darjeeling&query_place_id=ChIJFy_mW5Mv5DkRqk9_zS5S_ug", note: "pure-veg kitchen below Chowrasta" }],
      stays: [{ n: "Darjeeling Hillside Inn", r: "4.8 (306)", url: "https://www.google.com/maps/search/?api=1&query=Darjeeling+Hillside+Inn&query_place_id=ChIJIzt32jIv5DkRnU4naGtbhos", note: "budget inn on Hill Cart road" }, { n: "Mountain View Homestay", r: "4.7 (104)", url: "https://www.google.com/maps/search/?api=1&query=Mountain+View+Homestay+Darjeeling&query_place_id=ChIJBWZ4G9Av5DkRBY7Qm2oEWVk", note: "homestay near Chauk Bazaar" }],
      shops: [{ n: "Chowk Bazaar", note: "the locals' lower-town market" }, { n: "Mall Market (Bhutia Market)", note: "stalls below the Mall for woollens and curios" }, { n: "Tea shops at Chowrasta", note: "first flush and muscatel to carry home" }]
    },
    {
      id: 'andaman', name: 'Andaman Islands', state: 'Andaman & Nicobar', region: 'islands',
      vibes: ['beaches', 'adventure'],
      blurb: 'Glass-clear water, coral reefs and Radhanagar, often called Asia\'s best beach.',
      photo: 'photos/andaman.jpg', alt: 'Radhanagar Beach, Havelock Island',
      credit: 'Photo: Vyacheslav Argenberg, Wikimedia Commons',
      best: 'Oct - May', months: [9, 10, 11, 0, 1, 2, 3, 4],
      festival: { name: 'Island Tourism Festival', when: '10 days from 5 Jan', note: 'Music, food stalls and island culture at Port Blair (andamantourism.gov.in).' },
      ideal: '5 - 6 days',
      getting: [
        { text: 'Flight, New Delhi to Port Blair - one-way economy, 28 Nov 2026', fare: 'from $187.50', source: 'Duffel live quote, 30 Oct' },
        { text: 'Flight, Mumbai to Port Blair', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+from+Mumbai+to+Port+Blair' }
      ],
      places: ['Radhanagar Beach, Havelock', 'Cellular Jail light-and-sound show', 'Snorkelling at Elephant Beach', 'Neil Island\'s natural bridge'],
      food: [{ n: "Andaman fish curry", diet: 'nonveg', note: "the day's catch in a coconut-milk curry" }, { n: "Grilled lobster", diet: 'nonveg', note: "beach-shack grills with local herbs" }, { n: "Prawn pakora", diet: 'nonveg', note: "street-fried prawn fritters" }, { n: "Veg and vegan plates", diet: 'veg', note: "islands lean seafood-heavy; the pure-veg kitchens below cover veg and vegan" }],
      eats: [{ n: "Ruchi Restaurant", r: "4.8 (4.6k)", url: "https://www.google.com/maps/search/?api=1&query=Ruchi+Restaurant&query_place_id=ChIJOaD3c_qViDARpXCCaO5eaUQ", note: "Phoenix Bay multi-cuisine local favourite", ta: "4.4" }, { n: "Sea Food Delights Rooftop Seaview", r: "4.5 (3.7k)", url: "https://www.google.com/maps/search/?api=1&query=Sea+Food+Delights+Rooftop+Seaview+Restaurant&query_place_id=ChIJlaeb6qOViDARa2ZxWK43IV0", note: "rooftop seafood over Phoenix Bay" }, { n: "Icy Spicy - Pure Veg", r: "4.2 (3.5k)", url: "https://www.google.com/maps/search/?api=1&query=Icy+Spicy+-+Pure+Veg&query_place_id=ChIJFb28CKWViDARXQ4DjT9RD8U", note: "the pure-veg institution at Junglighat" }],
      stays: [{ n: "Sea Pearl Homestay", r: "4.7 (756)", url: "https://www.google.com/maps/search/?api=1&query=Sea+Pearl+Homestay&query_place_id=ChIJSb9LwV6ViDARCyl_Z3DMjsI", note: "homestay by Phoenix Bay, Marine Hill" }, { n: "VEDIC HOMES, Port Blair", r: "4.8 (278)", url: "https://www.google.com/maps/search/?api=1&query=VEDIC+HOMES%2C+PORT+BLAIR&query_place_id=ChIJZ2O5UeKViDARqq_SDBAEmSw", note: "homestay at South Point, near the shore" }],
      shops: [{ n: "Sagarika Emporium", note: "government fixed-price crafts: shell, cane and spices" }, { n: "Aberdeen Bazaar", note: "the main bazaar for souvenirs and daily needs" }, { n: "Junglighat jetty stalls", note: "shell and coconut-shell craft" }]
    },
    {
      id: 'jaisalmer', name: 'Jaisalmer', state: 'Rajasthan', region: 'west',
      vibes: ['heritage', 'culture', 'adventure'],
      blurb: 'A living sandstone fort in the Thar - havelis, camel safaris and dunes that glow at sunset.',
      photo: 'photos/jaisalmer.jpg', alt: 'Jaisalmer Fort rising above the old city',
      credit: 'Photo: Wikimedia Commons',
      best: 'Oct - Mar', months: [9, 10, 11, 0, 1, 2],
      festival: { name: 'Desert Festival', when: 'Jan - Feb, dates vary', note: 'Three days of folk music, camel races and turban-tying at the Sam dunes (Rajasthan tourism calendar).' },
      ideal: '3 days',
      getting: [
        { text: 'Overnight train from Delhi or Jaipur to Jaisalmer', fare: 'check current fare', source: 'IRCTC', url: 'https://www.irctc.co.in' },
        { text: 'Seasonal flights to Jaisalmer from Delhi and Jaipur', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+from+Delhi+to+Jaisalmer' }
      ],
      places: ['Jaisalmer Fort and its Jain temples', 'Patwon-ki-Haveli carvings', 'Sam sand dunes at sunset', 'Gadisar Lake at dawn'],
      food: [{ n: "Ker sangri", diet: 'vegan', note: "desert beans and berries cooked dry - the Thar's own vegetable" }, { n: "Gatte ki sabzi", diet: 'veg', note: "gram-flour dumplings in yoghurt curry" }, { n: "Laal maas", diet: 'nonveg', note: "fiery red mutton curry from the Rajput kitchens" }, { n: "Ghotua laddu", diet: 'veg', note: "crushed boondi sweet from old-city halwais" }],
      eats: [{ n: "The Trio Restaurant", r: "3.9 (TA)", url: "https://www.google.com/maps/search/?api=1&query=The+Trio+Restaurant+Jaisalmer", note: "rooftop multi-cuisine near the fort" }, { n: "Free Tibet Restaurant", url: "https://www.google.com/maps/search/?api=1&query=Free+Tibet+Restaurant+Jaisalmer", note: "small Tibetan kitchen by the fort gate" }, { n: "Desert Boy's Dhani", url: "https://www.google.com/maps/search/?api=1&query=Desert+Boy+Dhani+Jaisalmer", note: "garden restaurant with Rajasthani thali" }],
      stays: [{ n: "Moustache Jaisalmer", url: "https://www.google.com/maps/search/?api=1&query=Moustache+Jaisalmer", note: "backpacker hostel with fort views" }, { n: "Mud Mirror Guest House", url: "https://www.google.com/maps/search/?api=1&query=Mud+Mirror+Guest+House+Jaisalmer", note: "family-run guest house in the old city" }],
      shops: [{ n: "Manak Chowk", note: "textiles, leather and silver around the old square" }, { n: "Sadar Bazar", note: "everyday bazaar below the fort" }, { n: "Pansari Bazar", note: "spices and desert-town staples" }]
    },
    {
      id: 'rishikesh', name: 'Rishikesh', state: 'Uttarakhand', region: 'north',
      vibes: ['adventure', 'mountains', 'culture', 'spiritual'],
      blurb: 'Ganga aarti at dusk, white-water rafting by day, and cafes strung along the Tapovan hills.',
      photo: 'photos/rishikesh.jpg', alt: 'Ganga aarti lamps on the river at Rishikesh',
      credit: 'Photo: Wikimedia Commons',
      best: 'Oct - Mar; rafting Sep - Jun', months: [8, 9, 10, 11, 0, 1, 2, 3, 4, 5],
      festival: { name: 'International Yoga Festival', when: 'first week of March', note: 'A week of yoga classes and talks at Parmarth Niketan on the Ganga.' },
      ideal: '3 days',
      getting: [
        { text: 'Train or bus Delhi to Haridwar, then 45 min by road', fare: 'check current fare', source: 'IRCTC', url: 'https://www.irctc.co.in' },
        { text: 'Fly to Dehradun (Jolly Grant), about 35 min away', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+to+Dehradun' }
      ],
      places: ['Ganga aarti at Triveni Ghat', 'Beatles Ashram graffiti halls', 'Laxman Jhula and Ram Jhula bridges', 'White-water rafting from Shivpuri'],
      food: [{ n: "Aloo puri", diet: 'veg', note: "the ghat-side breakfast plate" }, { n: "Garhwali dal-bhat", diet: 'veg', note: "pahadi lentils and rice, simple and filling" }, { n: "Momos", diet: 'nonveg', note: "steamed dumplings around Laxman Jhula - veg versions everywhere" }, { n: "Jalebi", diet: 'veg', note: "hot spirals near Triveni Ghat" }],
      eats: [{ n: "The Sitting Elephant", r: "4.6", url: "https://www.google.com/maps/search/?api=1&query=The+Sitting+Elephant+Rishikesh", note: "rooftop cafe above the Ganga" }, { n: "The Paradise Cafe & Juice Bar", r: "4.7", url: "https://www.google.com/maps/search/?api=1&query=The+Paradise+Cafe+Juice+Bar+Rishikesh", note: "garden cafe in Tapovan" }, { n: "Chai Bazi", r: "4.6", url: "https://www.google.com/maps/search/?api=1&query=Chai+Bazi+Rishikesh", note: "tiny tea-and-snacks stop" }],
      stays: [{ n: "Zostel Rishikesh (Tapovan)", r: "9.0 (booking)", url: "https://www.google.com/maps/search/?api=1&query=Zostel+Rishikesh+Tapovan", note: "social backpacker hostel in Tapovan" }, { n: "Bunk Stay Rishikesh", url: "https://www.google.com/maps/search/?api=1&query=Bunk+Stay+Rishikesh", note: "hostel with Ganga-view rooftop" }],
      shops: [{ n: "Laxman Jhula market", note: "rudraksha, yoga gear and Tibetan trinkets" }, { n: "Tapovan lanes", note: "cafe strip with bookshops and handicrafts" }, { n: "Triveni Ghat market", note: "puja flowers, brass lamps and sweets" }]
    },
    {
      id: 'hampi', name: 'Hampi', state: 'Karnataka', region: 'south',
      vibes: ['heritage', 'culture'],
      blurb: 'A boulder-strewn ruined empire - stone chariots, temple towers and coracles on the Tungabhadra.',
      photo: 'photos/hampi.jpg', alt: 'Virupaksha Temple towers over Hampi',
      credit: 'Photo: Wikimedia Commons',
      best: 'Oct - Feb', months: [9, 10, 11, 0, 1],
      festival: { name: 'Hampi Utsav', when: 'usually Jan - Feb, dates vary', note: 'Music, dance and drama among the ruins (Karnataka tourism).' },
      ideal: '3 days',
      getting: [
        { text: 'Overnight train or bus from Bengaluru to Hospet, then 30 min', fare: 'check current fare', source: 'IRCTC', url: 'https://www.irctc.co.in' },
        { text: 'Fly to Hubballi, about 3.5 hrs by road', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+to+Hubballi' }
      ],
      places: ['Vittala Temple and the stone chariot', 'Virupaksha Temple at dawn', 'Matanga Hill sunset', 'Coracle ride on the Tungabhadra'],
      food: [{ n: "Benne dosa", diet: 'veg', note: "butter-crisp dosa, the Karnataka classic" }, { n: "Ragi mudde with sambar", diet: 'veg', note: "finger-millet balls, farm food of the region" }, { n: "South Indian thali", diet: 'veg', note: "banana-leaf meals near the bazaar" }, { n: "Grilled chicken at river cafes", diet: 'nonveg', note: "simple grills on the Hippie Island side" }],
      eats: [{ n: "Mango Tree Restaurant", url: "https://www.google.com/maps/search/?api=1&query=Mango+Tree+Restaurant+Hampi", note: "riverside garden restaurant, a Hampi classic" }, { n: "Laughing Buddha", r: "3.9 (TA)", url: "https://www.google.com/maps/search/?api=1&query=Laughing+Buddha+Hampi", note: "traveller cafe on the river side" }, { n: "Suresh Restaurant", url: "https://www.google.com/maps/search/?api=1&query=Suresh+Restaurant+Hampi", note: "old-town South Indian meals" }],
      stays: [{ n: "Mowgli Guest House", url: "https://www.google.com/maps/search/?api=1&query=Mowgli+Guest+House+Hampi", note: "riverside cottages on the island side" }, { n: "Gopi Guest House", url: "https://www.google.com/maps/search/?api=1&query=Gopi+Guest+House+Hampi", note: "family guest house near the bazaar" }],
      shops: [{ n: "Hampi Bazaar", note: "stone crafts and trinkets along the old street" }, { n: "Hospet market", note: "everyday bazaar town 30 min away" }, { n: "Riverside stalls", note: "hippie-side clothes and jewellery" }]
    },
    {
      id: 'shillong', name: 'Shillong', state: 'Meghalaya', region: 'east',
      vibes: ['mountains', 'culture', 'adventure'],
      blurb: "Pine-ridge capital of the Khasi hills - waterfalls, cafe culture and Asia's wettest forests nearby.",
      photo: 'photos/shillong.jpg', alt: 'Elephant Falls tumbling through green near Shillong',
      credit: 'Photo: Wikimedia Commons',
      best: 'Sep - May', months: [8, 9, 10, 11, 0, 1, 2, 3, 4],
      festival: { name: 'Cherry Blossom Festival', when: 'November (two days)', note: 'Music, food and culture under blooming cherry trees (Meghalaya tourism).' },
      ideal: '3 - 4 days',
      getting: [
        { text: 'Fly to Shillong (Umroi) or Guwahati, then about 3 hrs by road', fare: 'check live fares', source: 'Google Flights', url: 'https://www.google.com/travel/flights?q=flights+to+Shillong' },
        { text: 'Shared taxis run Guwahati to Shillong all day', fare: 'about 3 hrs drive' }
      ],
      places: ['Elephant Falls', 'Shillong Peak viewpoint', 'Umiam Lake', 'Laitlum Canyon at sunset'],
      food: [{ n: "Jadoh", diet: 'nonveg', note: "Khasi rice cooked with pork - the everyday plate" }, { n: "Dohneiiong", diet: 'nonveg', note: "pork in black-sesame gravy" }, { n: "Tungrymbai", diet: 'veg', note: "fermented-soybean curry, an acquired local favourite" }, { n: "Pukhlein", diet: 'veg', note: "sweet fried rice pancake with chai" }],
      eats: [{ n: "Trattoria", r: "4.1 (907)", url: "https://www.google.com/maps/search/?api=1&query=Trattoria+Shillong", note: "Khasi home-style meals at Police Bazar" }, { n: "Dylan's Cafe", url: "https://www.google.com/maps/search/?api=1&query=Dylan%27s+Cafe+Shillong", note: "cafe with live-music roots" }, { n: "City Hut Family Dhaba", url: "https://www.google.com/maps/search/?api=1&query=City+Hut+Family+Dhaba+Shillong", note: "busy multi-cuisine dhaba" }],
      stays: [{ n: "Shillong Mountain Stays", url: "https://www.google.com/maps/search/?api=1&query=Shillong+Mountain+Stays", note: "colonial-style stay with local food" }, { n: "Guest houses around Police Bazar", url: "https://www.google.com/maps/search/?api=1&query=guest+house+Police+Bazar+Shillong", note: "walkable budget cluster in the centre" }],
      shops: [{ n: "Police Bazar", note: "the main market - woollens, bamboo craft and cafes" }, { n: "Bara Bazar (Iewduh)", note: "one of the oldest markets in the Northeast" }, { n: "Laitumkhrah lanes", note: "boutiques and bakeries" }]
    },
    {
      id: "srinagar", name: "Srinagar", state: "Jammu & Kashmir", region: "north",
      vibes: ["mountains"],
      blurb: "Dal Lake shikaras and houseboats, Mughal gardens, and the first snows of the Himalaya.",
      photo: "https://thumb.wikimedia.org/wikipedia/commons/thumb/4/41/Dal_Lake_Srinagar.jpg/960px-Dal_Lake_Srinagar.jpg", alt: "Shikaras on Dal Lake, Srinagar",
      credit: "Photo: Wikimedia Commons",
      best: "Apr - Oct", months: [3, 4, 5, 6, 7, 8, 9],
      festival: { name: "Tulip Festival", when: "late Mar - Apr", note: "Asia's largest tulip garden blooms at the foot of the Zabarwan hills." },
      ideal: "3 days",
      getting: [{ text: "Flight, New Delhi to Srinagar", fare: "about 3 hr 30 min listed (incl. transfers)", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Srinagar" }, { text: "Direct bus, Delhi (Kashmere Gate ISBT) to Srinagar", fare: "about 18 hr 50 min listed", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Srinagar" }],
      places: ["Dal Lake shikara ride and houseboats", "Nishat and Shalimar Mughal gardens", "Shankaracharya Temple hill", "Hazratbal Shrine on the lake"],
      food: [{ n: "Rogan josh", diet: "nonveg", note: "the Kashmiri slow-braised lamb classic" }, { n: "Gushtaba", diet: "nonveg", note: "velvety mutton meatballs in yoghurt gravy - the wazwan finale" }, { n: "Nadru yakhni", diet: "veg", note: "lotus stem in a mild yoghurt curry" }, { n: "Kahwa", diet: "veg", note: "saffron-green tea with almonds, poured from a samovar" }],
      eats: [{ n: "Shahi Pakwaan Restaurant", r: "4.7", url: "https://www.google.com/maps/search/?api=1&query=Shahi+Pakwaan+Restaurant+Srinagar", note: "top-rated local pick for wazwan plates" }, { n: "Kareema Restaurant", r: "4.0", url: "https://www.google.com/maps/search/?api=1&query=Kareema+Restaurant+Srinagar", note: "busy old-city favourite for Kashmiri dishes" }, { n: "Dawat E Wazwan", url: "https://www.google.com/maps/search/?api=1&query=Dawat+E+Wazwan+Srinagar", note: "wazwan-style dining in Srinagar" }],
      stays: [{ n: "New Alzira Royal Heritage Houseboats", url: "https://www.google.com/maps/search/?api=1&query=New+Alzira+Royal+Heritage+Houseboats+Srinagar", note: "heritage houseboats on Dal Lake" }, { n: "Guest houses around Boulevard Road", url: "https://www.google.com/maps/search/?api=1&query=guest+house+Boulevard+Road+Srinagar", note: "walkable lakeside budget cluster" }],
      shops: [{ n: "Lal Chowk", note: "saffron, dry fruits and Kashmiri woollens" }, { n: "Polo View Market", note: "papier-mache, walnut wood and pashmina lanes" }, { n: "Floating vegetable market, Dal Lake", note: "dawn shikara market - go early" }]
    },
    {
      id: "shimla", name: "Shimla", state: "Himachal Pradesh", region: "north",
      vibes: ["mountains"],
      blurb: "The old summer capital - Ridge walks, colonial facades and deodar air.",
      photo: "https://upload.wikimedia.org/wikipedia/commons/2/2c/The_Ridge_Shimla.jpg", alt: "The Ridge, Shimla",
      credit: "Photo: Wikimedia Commons",
      best: "Mar - Jun", months: [2, 3, 4, 5],
      festival: { name: "Summer Festival", when: "June", note: "Music, food stalls and flower shows on the Ridge." },
      ideal: "2 days",
      getting: [{ text: "Direct bus, Delhi (ISBT Kashmere Gate) to Shimla", fare: "about 9 hr 50 min listed", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Shimla" }, { text: "By road from Delhi", fare: "about 5 hr 10 min drive listed", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Shimla" }],
      places: ["The Ridge and Christ Church", "Mall Road stroll", "Jakhu Temple hill", "Kalka-Shimla toy train ride"],
      food: [{ n: "Siddu", diet: "veg", note: "steamed stuffed bun with ghee - the Himachali classic" }, { n: "Chana madra", diet: "veg", note: "chickpeas in a yoghurt-cardamom gravy" }, { n: "Babru", diet: "vegan", note: "crisp black-gram stuffed pooris" }, { n: "Chicken anardana", diet: "nonveg", note: "pomegranate-seed chicken, a pahari favourite" }],
      eats: [{ n: "Sangram Ji Ka Dhaba", url: "https://www.google.com/maps/search/?api=1&query=Sangram+Ji+Ka+Dhaba+Shimla", note: "local dhaba favourite near Mall Road" }, { n: "Indian Coffee House", url: "https://www.google.com/maps/search/?api=1&query=Indian+Coffee+House+Mall+Road+Shimla", note: "old-school Mall Road institution" }, { n: "Cafe Simla Times", url: "https://www.google.com/maps/search/?api=1&query=Cafe+Simla+Times+Shimla", note: "busy cafe by the Ridge" }],
      stays: [{ n: "Clarkes Hotel", r: "4.5", url: "https://www.google.com/maps/search/?api=1&query=Clarkes+Hotel+Shimla", note: "heritage hotel just off the Ridge" }, { n: "Hotel Willow Banks", url: "https://www.google.com/maps/search/?api=1&query=Hotel+Willow+Banks+Shimla", note: "boutique stay on Mall Road" }],
      shops: [{ n: "Lakkar Bazaar", note: "wooden crafts, walking sticks and toys" }, { n: "Mall Road", note: "shawls, caps and bookshops" }, { n: "Himachal Emporium", note: "state-handloom woollens and caps" }]
    },
    {
      id: "tirupati", name: "Tirupati", state: "Andhra Pradesh", region: "south",
      vibes: ["spiritual"],
      blurb: "The Tirumala hills and the Sri Venkateswara Temple - one of the most visited shrines on earth.",
      photo: "https://thumb.wikimedia.org/wikipedia/commons/thumb/4/4e/Tirumala_090615.jpg/960px-Tirumala_090615.jpg", alt: "Tirumala Venkateswara Temple",
      credit: "Photo: Wikimedia Commons",
      best: "Nov - Feb", months: [10, 11, 0, 1],
      festival: { name: "Brahmotsavam", when: "Sep - Oct", note: "Nine days of processions around the Tirumala temple." },
      ideal: "2 days",
      getting: [{ text: "Flight, New Delhi to Tirupati", fare: "about 4 hr 20 min listed (incl. transfers)", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Tirupati" }, { text: "Direct train, New Delhi to Tirupati", fare: "about 32 hr 25 min listed", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Tirupati" }],
      places: ["Sri Venkateswara Temple darshan, Tirumala", "Srivari Mettu footpath climb", "Kapila Theertham waterfall temple", "Sri Padmavathi Ammavari Temple, Tiruchanur"],
      food: [{ n: "Tirupati laddu", diet: "veg", note: "the temple's famous prasadam" }, { n: "Pulihora", diet: "vegan", note: "tamarind rice, the Andhra travel staple" }, { n: "Pongal", diet: "veg", note: "ghee-rich rice and dal breakfast" }, { n: "Andhra meals", diet: "veg", note: "unlimited banana-leaf thali, spicy podis and all" }],
      eats: [{ n: "Minerva Coffee Shop", url: "https://www.google.com/maps/search/?api=1&query=Minerva+Coffee+Shop+Tirupati", note: "long-running veg dining in Tirupati town" }, { n: "Bhimas Deluxe Hotel", url: "https://www.google.com/maps/search/?api=1&query=Bhimas+Deluxe+Hotel+Tirupati", note: "the classic Andhra-meals name near the temple bus stand" }],
      stays: [{ n: "TTD Srinivasam guest house", url: "https://www.google.com/maps/search/?api=1&query=TTD+Srinivasam+Guest+House+Tirupati", note: "temple-run pilgrim rooms near the bus station" }, { n: "Hotels around Tiruchanur Road", url: "https://www.google.com/maps/search/?api=1&query=hotel+Tiruchanur+Road+Tirupati", note: "budget and mid-range cluster on the temple road" }],
      shops: [{ n: "Bazaars around the temple streets", note: "prasadam, pictures and puja items" }, { n: "Lepakshi Emporium", note: "state-handicraft store - toys, Kalamkari and brass" }]
    },
    {
      id: "bodhgaya", name: "Bodh Gaya", state: "Bihar", region: "east",
      vibes: ["spiritual"],
      blurb: "The Bodhi Tree where the Buddha attained enlightenment, ringed by monasteries of many nations.",
      photo: "https://thumb.wikimedia.org/wikipedia/commons/thumb/3/37/Mahabodhi_Temple.jpg/960px-Mahabodhi_Temple.jpg", alt: "Mahabodhi Temple, Bodh Gaya",
      credit: "Photo: Wikimedia Commons",
      best: "Oct - Mar", months: [9, 10, 11, 0, 1, 2],
      festival: { name: "Buddha Purnima", when: "Apr - May full moon", note: "The Buddha's birth, enlightenment and passing, marked at the Mahabodhi Temple." },
      ideal: "2 days",
      getting: [{ text: "Flight, New Delhi to Gaya", fare: "about 3 hr 9 min listed (incl. transfers)", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Bodh-Gay%C4%81" }, { text: "Train, New Delhi to Gaya", fare: "about 11 hr 30 min listed (1 change)", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Bodh-Gay%C4%81" }],
      places: ["Mahabodhi Temple and the Bodhi Tree", "The 25 m Great Buddha Statue", "Thai, Japanese and Bhutanese monasteries", "Dungeshwari (Mahakala) caves"],
      food: [{ n: "Litti chokha", diet: "veg", note: "roasted wheat balls with smoky mashed vegetables - Bihar's signature" }, { n: "Sattu paratha", diet: "veg", note: "griddle bread stuffed with spiced roasted-gram flour" }, { n: "Khaja", diet: "veg", note: "flaky layered sweet from nearby Silao" }, { n: "Tibetan momos", diet: "nonveg", note: "steamed dumplings around the monastery lanes - veg versions everywhere" }],
      eats: [{ n: "Carrot Cake & Coffee", url: "https://www.google.com/maps/search/?api=1&query=Carrot+Cake+%26+Coffee+Bodh+Gaya", note: "relaxed cafe pick near the temple" }, { n: "Be Happy Cafe", url: "https://www.google.com/maps/search/?api=1&query=Be+Happy+Cafe+Bodh+Gaya", note: "traveller favourite for simple veg plates" }],
      stays: [{ n: "Jyoti Guest House", r: "4.8", url: "https://www.google.com/maps/search/?api=1&query=Jyoti+Guest+House+Bodh+Gaya", note: "top-rated family guest house" }, { n: "Nilam Guest House", url: "https://www.google.com/maps/search/?api=1&query=Nilam+Guest+House+Bodh+Gaya", note: "simple pilgrim stay near the Mahabodhi" }],
      shops: [{ n: "Monastery handicraft stalls", note: "prayer flags, beads and singing bowls" }, { n: "Tibetan Refugee Market", note: "winter market of woollens and crafts" }, { n: "Main market by the Mahabodhi", note: "souvenirs and temple offerings" }]
    },
    {
      id: "ajmer", name: "Ajmer", state: "Rajasthan", region: "west",
      vibes: ["spiritual", "heritage"],
      blurb: "The Ajmer Sharif Dargah's qawwali nights, Ana Sagar's lakeside calm, and Taragarh above it all.",
      photo: "https://upload.wikimedia.org/wikipedia/commons/2/25/Ajmer_Sharif_Dargah.jpg", alt: "Ajmer Sharif Dargah",
      credit: "Photo: Wikimedia Commons",
      best: "Oct - Mar", months: [9, 10, 11, 0, 1, 2],
      festival: { name: "Urs of Khwaja Garib Nawaz", when: "dates move with the Islamic calendar (Rajab)", note: "Six days of qawwali and devotion at the dargah." },
      ideal: "2 days",
      getting: [{ text: "Direct train, New Delhi to Ajmer", fare: "about 5 hr 40 min listed", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Ajmer" }, { text: "Direct bus, Delhi to Ajmer", fare: "about 8 hr 29 min listed", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Ajmer" }],
      places: ["Ajmer Sharif Dargah", "Ana Sagar Lake promenade", "Adhai Din Ka Jhonpra", "Taragarh Fort at sunset"],
      food: [{ n: "Kachori", diet: "vegan", note: "Ajmer's crisp breakfast kachori with kadhi" }, { n: "Sohan halwa", diet: "veg", note: "dense ghee-and-dry-fruit sweet, the city's gift-box staple" }, { n: "Kebabs near the dargah", diet: "nonveg", note: "skewers and tikkas in the lanes around Dargah Bazaar" }, { n: "Malpua", diet: "veg", note: "syrup-soaked griddle cakes" }],
      eats: [{ n: "Mango Curry", r: "4.9", url: "https://www.google.com/maps/search/?api=1&query=Mango+Curry+Ajmer", note: "top-rated veg dining in Ajmer" }, { n: "Mango Masala Restaurant", url: "https://www.google.com/maps/search/?api=1&query=Mango+Masala+Restaurant+Ajmer", note: "popular family restaurant in town" }],
      stays: [{ n: "Hotel Premier Choice", r: "4.9", url: "https://www.google.com/maps/search/?api=1&query=Hotel+Premier+Choice+Ajmer", note: "top-rated budget stay near the dargah side" }, { n: "Hotel Rich Comfort", url: "https://www.google.com/maps/search/?api=1&query=Hotel+Rich+Comfort+Ajmer", note: "simple central stay" }],
      shops: [{ n: "Dargah Bazaar", note: "chadars, attar and sweets on the shrine approach" }, { n: "Nalla Bazaar", note: "old-city lanes of bangles and fabric" }, { n: "Naya Bazaar", note: "everyday market for brassware and snacks" }]
    },
    {
      id: "haridwar", name: "Haridwar", state: "Uttarakhand", region: "north",
      vibes: ["spiritual"],
      blurb: "Lamps on the Ganga at Har Ki Pauri - the evening aarti every pilgrim plans around.",
      photo: "https://upload.wikimedia.org/wikipedia/commons/f/f8/Evening_Aarti_at_Har-ki-Pauri%2C_Haridwar.jpg", alt: "Evening Ganga aarti at Har Ki Pauri, Haridwar",
      credit: "Photo: Wikimedia Commons",
      best: "Sep - Apr", months: [8, 9, 10, 11, 0, 1, 2, 3],
      festival: { name: "Kanwar Mela", when: "Jul - Aug (Shravan)", note: "Saffron-clad pilgrims carry Ganga water home - the city fills up." },
      ideal: "2 days",
      getting: [{ text: "Direct train, New Delhi to Haridwar Jn", fare: "about 4 hr 7 min listed", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Haridwar" }, { text: "Direct bus, Delhi (Kashmiri Gate) to Haridwar", fare: "about 4 hr 20 min listed", source: "rome2rio", url: "https://www.rome2rio.com/s/New-Delhi/Haridwar" }],
      places: ["Ganga aarti at Har Ki Pauri", "Holy dip at Brahmakund", "Mansa Devi and Chandi Devi ropeways", "Old bazaars around the ghat"],
      food: [{ n: "Aloo puri", diet: "vegan", note: "the ghat-side breakfast plate" }, { n: "Kachori sabzi", diet: "vegan", note: "crisp kachori with spicy potato curry" }, { n: "Jalebi", diet: "veg", note: "hot syrupy spirals off the karahi" }, { n: "Chole bhature", diet: "veg", note: "the hearty pilgrims' favourite" }],
      eats: [{ n: "Govindam Restaurant", url: "https://www.google.com/maps/search/?api=1&query=Govindam+Restaurant+Haridwar", note: "pure-veg dining near the ghat" }, { n: "Chotiwala", url: "https://www.google.com/maps/search/?api=1&query=Chotiwala+Haridwar", note: "the famous old-name thali house" }],
      stays: [{ n: "Bhagirathi By Atishay", url: "https://www.google.com/maps/search/?api=1&query=Bhagirathi+By+Atishay+Haridwar", note: "4-star stay a short ride from Har Ki Pauri" }, { n: "Haveli Hari Ganga", url: "https://www.google.com/maps/search/?api=1&query=Haveli+Hari+Ganga+Haridwar", note: "heritage haveli-style stay by the river" }],
      shops: [{ n: "Bara Bazaar", note: "religious goods, brass and sweets" }, { n: "Moti Bazaar", note: "bangles, beads and puja items" }, { n: "Jwalapur market", note: "local snack and sweet shops" }]
    },
    {"id": "delhi", "name": "Delhi", "state": "Delhi", "region": "north", "vibes": ["heritage", "city", "spiritual"], "blurb": "Mughal monuments, Old Delhi food lanes and sacred spaces across faiths. Winter air quality can be poor; check local advisories before outdoor plans.", "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/India_Gate_in_New_Delhi_03-2016.jpg/500px-India_Gate_in_New_Delhi_03-2016.jpg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=thumbnail&_=20160512234622", "alt": "India Gate in New Delhi", "credit": "A.Savin / Wikimedia Commons / Free Art License", "best": "Oct - Mar", "months": [9, 10, 11, 0, 1, 2], "festival": {"name": "Republic Day", "when": "26 January", "note": "The capital hosts the national parade; tickets and security restrictions apply."}, "ideal": "3 days", "getting": [{"text": "Train, Amritsar to New Delhi", "fare": "about 6 hr 7 min average listed; check your service", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/Amritsar/New-Delhi"}], "places": ["Red Fort and Chandni Chowk", "Humayun's Tomb and Qutub Minar", "India Gate and Lodhi Garden", "Gurudwara Bangla Sahib, Jama Masjid and Lotus Temple; check each site's entry rules"], "food": [{"n": "Chole bhature", "diet": "veg", "note": "Chickpea curry with fried bread; ask about dairy."}, {"n": "Butter chicken", "diet": "nonveg", "note": "Chicken in a butter-and-tomato gravy."}, {"n": "Parathas and chaat", "diet": "veg", "note": "Old Delhi staples; toppings and cooking fat vary."}], "eats": [{"n": "Saravana Bhavan", "r": "4.4 (28,923)", "url": "https://www.google.com/maps/search/?api=1&query=Saravana+Bhavan&query_place_id=ChIJyQoFpTX9DDkRP9GfG1Ia9p8", "note": "Vegetarian South Indian restaurant on Janpath. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Karim Hotel", "r": "3.7 (21,494)", "url": "https://www.google.com/maps/search/?api=1&query=Karim+Hotel&query_place_id=ChIJyy_Vxxj9DDkRPXF11X7EfT0", "note": "Old Delhi Mughlai institution near Jama Masjid; mixed recent rating, choose for heritage rather than a high-score claim. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "Bloomrooms", "r": "4.6 (6,326)", "url": "https://www.google.com/maps/search/?api=1&query=Bloomrooms&query_place_id=ChIJ6_MV9z_9DDkR0ku5AN1six8", "note": "Near New Delhi railway station; practical base, no scenic-view guarantee. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Dilli Haat", "note": "Regional crafts and food stalls; check admission."}, {"n": "Chandni Chowk and Khari Baoli", "note": "Textiles, spices and busy old-city lanes."}, {"n": "Sarojini Nagar", "note": "Clothes market; inspect quality and bargain where appropriate."}]},
    {"id": "bengaluru", "name": "Bengaluru", "state": "Karnataka", "region": "south", "vibes": ["city", "heritage"], "blurb": "Garden walks, Karnataka breakfasts and old neighbourhoods around a busy modern city. Allow extra time for cross-city traffic.", "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Vidhana_Soudha_Bangalore.jpg/960px-Vidhana_Soudha_Bangalore.jpg?20191208170049", "alt": "Vidhana Soudha in Bengaluru", "credit": "Wise Droid / Wikimedia Commons / CC BY-SA 4.0", "best": "Oct - Feb", "months": [9, 10, 11, 0, 1], "festival": {"name": "Lalbagh flower shows", "when": "around Jan and Aug; confirm dates", "note": "The botanical garden hosts seasonal flower displays."}, "ideal": "3 days", "getting": [{"text": "Train, New Delhi to Bengaluru", "fare": "about 35 hr 2 min average listed; varies by service", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/New-Delhi/Bengaluru"}], "places": ["Lalbagh Botanical Garden", "Cubbon Park and Vidhana Soudha exterior", "Bull Temple and Basavanagudi", "National Gallery of Modern Art"], "food": [{"n": "Masala dose", "diet": "veg", "note": "Crisp rice-and-lentil crepe with potato filling; often cooked with ghee."}, {"n": "Idli-vade and filter coffee", "diet": "veg", "note": "Breakfast favourite; coffee usually contains milk."}, {"n": "Ragi mudde", "diet": "veg", "note": "Finger-millet balls; choose the accompanying curry to suit your diet."}], "eats": [{"n": "MTR", "r": "4.3 (39,995)", "url": "https://www.google.com/maps/search/?api=1&query=MTR&query_place_id=ChIJaaWjpN0VrjsRAsmfiafDlN4", "note": "Lalbagh-area Karnataka breakfast and meals. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Vidyarthi Bhavan", "r": "4.2 (58,849)", "url": "https://www.google.com/maps/search/?api=1&query=Vidyarthi+Bhavan&query_place_id=ChIJNdCK6PIVrjsR3I4feeftf-0", "note": "Gandhi Bazaar masala dose stop; expect queues. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "Zostel Bangalore (Indiranagar)", "r": "4.6 (2,448)", "url": "https://www.google.com/maps/search/?api=1&query=Zostel+Bangalore+%28Indiranagar%29&query_place_id=ChIJxygthiEVrjsRiWL7RyvUeZQ", "note": "Indiranagar hostel; compare dorm and private-room terms, not a guaranteed view stay. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Gandhi Bazaar", "note": "Flowers, produce and traditional shops."}, {"n": "Commercial Street and Chickpet", "note": "Clothing, textiles and busy shopping lanes."}]},
    {"id": "kolkata", "name": "Kolkata", "state": "West Bengal", "region": "east", "vibes": ["city", "heritage", "spiritual"], "blurb": "Hooghly riverfronts, grand museums, book lanes and Bengali kitchens. Durga Puja brings major crowds and road changes.", "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Victoria-Memorial-Kolkata-India.jpg/960px-Victoria-Memorial-Kolkata-India.jpg?_=20170605162052", "alt": "Victoria Memorial in Kolkata", "credit": "Joel Godwin / Wikimedia Commons / CC BY-SA 4.0", "best": "Oct - Feb", "months": [9, 10, 11, 0, 1], "festival": {"name": "Durga Puja", "when": "Sep - Oct; dates vary", "note": "Pandal visits and neighbourhood celebrations; plan for crowds."}, "ideal": "3 days", "getting": [{"text": "Train, New Delhi to Sealdah", "fare": "about 17 hr 40 min listed; service-specific", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/New-Delhi/Kolkata"}], "places": ["Victoria Memorial and the Maidan", "Howrah Bridge and Hooghly riverfront", "College Street bookshops and Indian Museum", "Dakshineswar Kali Temple and Parasnath Jain Temple; check entry rules"], "food": [{"n": "Kolkata biryani", "diet": "nonveg", "note": "Rice with meat and the city's signature potato."}, {"n": "Mishti doi and sweets", "diet": "veg", "note": "Sweetened yoghurt and milk-based Bengali sweets."}, {"n": "Kosha mangsho", "diet": "nonveg", "note": "Slow-cooked Bengali mutton curry."}], "eats": [{"n": "Indian Coffee House", "r": "4.1 (41,968)", "url": "https://www.google.com/maps/search/?api=1&query=Indian+Coffee+House&query_place_id=ChIJ3-ggXk12AjoRXEpZDw8zZNw", "note": "College Street institution; go for atmosphere as well as coffee. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Bhojohori Manna", "r": "3.8 (1,888)", "url": "https://www.google.com/maps/search/?api=1&query=Bhojohori+Manna&query_place_id=ChIJtxRjxTZ3AjoRJBui5PMbFbw", "note": "Bengali meals in the Hazra area; mixed recent rating, read recent reviews. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "OYO 5811 Seacom Inn YMCA Esplanade", "r": "3.8 (682)", "url": "https://www.google.com/maps/search/?api=1&query=OYO+5811+Seacom+Inn+YMCA+Esplanade&query_place_id=ChIJWSGx2Ah3AjoRvsIBBnoJvoE", "note": "Central Chowringhee location; check recent room reviews and current rates. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "College Street", "note": "Bookshops and second-hand books."}, {"n": "New Market", "note": "Clothing, gifts and food shops."}, {"n": "Park Street", "note": "Bookshops, cafes and seasonal Christmas lights."}]},
    {"id": "puri", "name": "Puri", "state": "Odisha", "region": "east", "vibes": ["spiritual", "beaches", "heritage"], "blurb": "Jagannath traditions, Bay of Bengal beaches and Odia craft. The temple administration allows only Hindus inside; other visitors can enjoy the city, beach and public festival routes.", "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2d/Puri_Jagannath_Temple_Entrance.jpg/960px-Puri_Jagannath_Temple_Entrance.jpg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=thumbnail&_=20191001105446", "alt": "Entrance to Jagannath Temple in Puri", "credit": "Government of Odisha / Wikimedia Commons / CC BY 4.0", "best": "Oct - Feb", "months": [9, 10, 11, 0, 1], "festival": {"name": "Rath Yatra", "when": "Jun - Jul; lunar dates vary", "note": "Public chariot festival; expect very large crowds and follow official safety guidance."}, "ideal": "3 days", "getting": [{"text": "Train, Kolkata (Sealdah) to Puri", "fare": "about 8 hr 10 min listed", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/Kolkata/Puri"}, {"text": "Jagannath Temple visitor rules", "fare": "Hindu-only interior entry; phones and cameras prohibited inside", "source": "Temple administration", "url": "https://www.shreejagannatha.in/faqs/"}], "places": ["Jagannath Temple: Hindu-only interior entry; check official darshan restrictions", "Puri beach and seafront; follow lifeguard flags", "Raghurajpur craft village near Puri", "Konark Sun Temple: plan as a separate excursion"], "food": [{"n": "Chhena poda", "diet": "veg", "note": "Baked cottage-cheese sweet."}, {"n": "Machha besara", "diet": "nonveg", "note": "Fish in mustard gravy."}, {"n": "Chingudi tarkari", "diet": "nonveg", "note": "Odia prawn curry."}, {"n": "Mahaprasad", "diet": "veg", "note": "Temple rice, dal and vegetable offerings; temple access rules apply."}], "eats": [{"n": "Wildgrass Restaurant", "r": "3.9 (5,980)", "url": "https://www.google.com/maps/search/?api=1&query=Wildgrass+Restaurant&query_place_id=ChIJsR3BwB7EGToR3Y83VNhzqO0", "note": "VIP Road restaurant for Odia meals and seafood; check recent reviews. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Dalma", "r": "3.5 (3,054)", "url": "https://www.google.com/maps/search/?api=1&query=Dalma&query_place_id=ChIJKazhHqHGGToR8Xdlvms7Ink", "note": "Odia meals on VIP Road; mixed recent rating, compare current reviews before choosing. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "Panthanivas Puri", "r": "4.1 (3,223)", "url": "https://www.google.com/maps/search/?api=1&query=Panthanivas+Puri&query_place_id=ChIJEePsaRnEGToRzLeFoZvug_o", "note": "OTDC lodging on Chakra Tirtha Road; verify current room condition and any sea-facing room category before booking. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Raghurajpur craft village", "note": "Pattachitra paintings and palm-leaf art; ask artisans about materials."}, {"n": "Puri market lanes", "note": "Textiles, woodwork and devotional souvenirs."}]},
    {"id": "hyderabad", "name": "Hyderabad", "state": "Telangana", "region": "south", "vibes": ["city", "heritage", "spiritual"], "blurb": "Charminar bazaars, Deccan palaces and biryani kitchens. Sacred spaces span faiths; check each site's visitor rules and allow for city traffic.", "alt": "Aerial view of Charminar and Hyderabad old city", "credit": "Saikanthkrishna4220 / Wikimedia Commons / CC BY-SA 4.0", "best": "Oct - Feb", "months": [9, 10, 11, 0, 1], "festival": {"name": "Bonalu", "when": "Jul - Aug; lunar dates vary", "note": "Telangana goddess festival; processions can change traffic and access."}, "ideal": "3 days", "places": ["Charminar and Laad Bazaar", "Golconda Fort and Qutb Shahi Tombs", "Salar Jung Museum and Chowmahalla Palace", "Hussain Sagar, Birla Mandir and Mecca Masjid; check entry rules"], "food": [{"n": "Hyderabadi biryani", "diet": "nonveg", "note": "Spiced rice with meat; vegetarian versions are separate dishes."}, {"n": "Haleem", "diet": "nonveg", "note": "Slow-cooked meat, wheat and lentils; often seasonal around Ramadan."}, {"n": "Irani chai and biscuits", "diet": "veg", "note": "Milky tea with bakery snacks; biscuits may contain eggs."}], "eats": [{"n": "Cafe Bahar", "r": "4.2 (50,940)", "url": "https://www.google.com/maps/search/?api=1&query=Cafe+Bahar&query_place_id=ChIJXwoQ3d6ZyzsRt9dtZ7q3HQE", "note": "Himayatnagar biryani stop; check the current menu. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Nimrah Cafe & Bakery", "r": "4.0 (1,682)", "url": "https://www.google.com/maps/search/?api=1&query=Nimrah+Cafe+%26+Bakery&query_place_id=ChIJ1Z7b5_mXyzsR_6g6Az9fWjk", "note": "Cafe and bakery by Charminar for tea and snacks. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "FabHotel Arastu Plaza", "r": "4.0 (2,209)", "url": "https://www.google.com/maps/search/?api=1&query=FabHotel+Arastu+Plaza&query_place_id=ChIJn3Z4yXqXyzsRriwoMkLfsYg", "note": "Nampally lodging option; compare recent room reviews and current rates, not a guaranteed scenic stay. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Laad Bazaar", "note": "Bangles, textiles and old-city market lanes."}, {"n": "Pearl shops", "note": "Ask for written material and quality details; do not assume every item is a natural pearl."}], "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Charminar_Aerial_View.jpg/960px-Charminar_Aerial_View.jpg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=thumbnail&_=20221112175103", "getting": [{"text": "Train, Bengaluru to Hyderabad", "fare": "about 11 hr 28 min listed; varies by service", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/Bengaluru/Hyderabad"}]},
    {"id": "chennai", "name": "Chennai", "state": "Tamil Nadu", "region": "south", "vibes": ["city", "heritage", "beaches", "spiritual"], "blurb": "Mylapore temple lanes, Carnatic music and a long Bay of Bengal seafront. November and December can bring heavy northeast-monsoon rain; check weather alerts.", "alt": "Kapaleeshwarar Temple and tank in Mylapore Chennai", "credit": "G V Balasubramanian / Wikimedia Commons / CC BY-SA 2.0", "best": "Nov - Feb", "months": [10, 11, 0, 1], "festival": {"name": "Margazhi music season", "when": "Dec - Jan; programmes vary", "note": "Carnatic music and classical dance across city sabhas; check individual programmes."}, "ideal": "3 days", "places": ["Kapaleeshwarar Temple and Mylapore; confirm current entry and dress rules", "Marina Beach promenade; do not assume the sea is safe for swimming", "Fort St George and Government Museum", "San Thome Basilica and the coastal neighbourhoods"], "food": [{"n": "Idli, sambar and dosa", "diet": "veg", "note": "Rice-and-lentil breakfast staples; ask about ghee and dairy."}, {"n": "Filter coffee", "diet": "veg", "note": "Usually prepared with milk."}, {"n": "Chettinad chicken", "diet": "nonveg", "note": "Peppery, spice-rich chicken curry; preparation varies."}], "eats": [{"n": "Ratna Cafe", "r": "4.0 (17,166)", "url": "https://www.google.com/maps/search/?api=1&query=Ratna+Cafe&query_place_id=ChIJh3v2BCFmUjoRf9LUqZWAxeQ", "note": "Triplicane cafe known for South Indian breakfasts. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Mylai Karpagambal Mess", "r": "3.5 (4,195)", "url": "https://www.google.com/maps/search/?api=1&query=Mylai+Karpagambal+Mess&query_place_id=ChIJxbd9eNRnUjoRKw13cKcOleU", "note": "Mylapore vegetarian meals stop; mixed recent rating, read current reviews. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "YWCA International Guest House Chennai", "r": "4.3 (1,467)", "url": "https://www.google.com/maps/search/?api=1&query=YWCA+International+Guest+House+Chennai&query_place_id=ChIJ5yHJnwdmUjoRph6aQPOr-9M", "note": "Guest-house option in Periamet; confirm guest eligibility, room type and current booking terms directly. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "T Nagar", "note": "Silk saris, textiles and jewellery shops; busy at festival times."}, {"n": "Mylapore market lanes", "note": "Flowers, traditional goods and small shops around the temple."}], "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/MylaporeKapaleeshwararTemple.jpg/960px-MylaporeKapaleeshwararTemple.jpg?20070704093228", "getting": [{"text": "Train, Bengaluru to Chennai", "fare": "about 5 hr 25 min listed; varies by service", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/Bengaluru/Chennai"}]},
    {"id": "mysuru", "name": "Mysuru", "state": "Karnataka", "region": "south", "vibes": ["heritage", "city", "spiritual"], "blurb": "Royal palaces, flower markets and Mysore Pak at a slower pace than Bengaluru. Dasara draws major crowds; confirm event and palace-access arrangements.", "alt": "Mysuru Palace with visitors in the courtyard", "credit": "Nandanjayant / Wikimedia Commons / CC BY-SA 4.0", "best": "Oct - Mar", "months": [9, 10, 11, 0, 1, 2], "festival": {"name": "Mysuru Dasara", "when": "Sep - Oct; lunar dates vary", "note": "Ten-day state festival with palace events and processions; confirm the year's schedule."}, "ideal": "3 days", "places": ["Mysuru Palace; check opening and illumination schedule", "Chamundi Hill and Chamundeshwari Temple; check visitor rules", "Devaraja Market and city heritage streets", "Jaganmohan Palace Art Gallery and Karanji Lake"], "food": [{"n": "Mysore Pak", "diet": "veg", "note": "Gram-flour sweet made with generous ghee."}, {"n": "Mylari-style dosa", "diet": "veg", "note": "Soft dosa; ask about butter or ghee."}, {"n": "Karnataka meals", "diet": "veg", "note": "Rice, sambar and vegetable sides; dairy often appears."}], "eats": [{"n": "Hotel Original Vinayaka Mylari", "r": "4.1 (18,174)", "url": "https://www.google.com/maps/search/?api=1&query=Hotel+Original+Vinayaka+Mylari&query_place_id=ChIJRYfP3z1wrzsRyuve8YrgQMQ", "note": "Nazarbad breakfast institution; check the exact branch. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Guru Sweet Mart", "r": "4.1 (15,321)", "url": "https://www.google.com/maps/search/?api=1&query=Guru+Sweet+Mart&query_place_id=ChIJqSF1iQ1wrzsRuaudNJ3D9hE", "note": "Devaraja Market sweet shop for Mysore Pak. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "Hotel Roopa", "r": "3.9 (5,331)", "url": "https://www.google.com/maps/search/?api=1&query=Hotel+Roopa&query_place_id=ChIJYwvcHRRwrzsRuWLvbn9tgpE", "note": "Central hotel option; check recent rooms and rates, especially during Dasara. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Devaraja Market", "note": "Flowers, incense, spices and everyday market shopping."}, {"n": "Silk and sandalwood outlets", "note": "Look for material labels and bills; compare licensed or established sellers."}], "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e2/Mysore_palace%2C_karnataka.jpg/960px-Mysore_palace%2C_karnataka.jpg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=thumbnail&_=20220907105001", "getting": [{"text": "Train, Bengaluru to Mysuru", "fare": "about 3 hr listed; varies by service", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/Bengaluru/Mysuru"}]},
    {"id": "madurai", "name": "Madurai", "state": "Tamil Nadu", "region": "south", "vibes": ["heritage", "city", "spiritual"], "blurb": "Temple towers, Nayak architecture and lively Tamil food streets. Temple entry is restricted and rules can change; confirm eligibility and dress requirements with the administration before visiting.", "alt": "Historic Madurai skyline with Meenakshi Temple towers, photographed in 2006", "credit": "Bernard Gagnon / Wikimedia Commons / CC BY-SA 3.0; photo from 2006", "best": "Oct - Mar", "months": [9, 10, 11, 0, 1, 2], "festival": {"name": "Chithirai Festival", "when": "Apr - May; lunar dates vary", "note": "Meenakshi-Sundareswarar celebrations and processions; very large crowds and heat."}, "ideal": "2 - 3 days", "places": ["Meenakshi Amman Temple: entry restrictions apply; check official rules, conservative dress and prohibited items", "Thirumalai Nayak Palace", "Gandhi Memorial Museum", "Temple-area streets and markets; separate public areas from restricted temple access"], "food": [{"n": "Jigarthanda", "diet": "veg", "note": "Cold milk-based drink; check ingredients and hygiene."}, {"n": "Kari dosa", "diet": "nonveg", "note": "Dosa topped with meat, often mutton, and egg."}, {"n": "Kothu parotta", "diet": "both", "note": "Chopped flatbread; choose vegetable, egg or meat version explicitly."}], "eats": [{"n": "Murugan Idli Shop", "r": "4.0 (8,695)", "url": "https://www.google.com/maps/search/?api=1&query=Murugan+Idli+Shop&query_place_id=ChIJgxzQcYHFADsRHmPKRdkw-J8", "note": "West Masi Street branch for idli and South Indian meals. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Madurai Famous Jigarthanda LLP - Since 1977", "r": "4.5 (10,781)", "url": "https://www.google.com/maps/search/?api=1&query=Madurai+Famous+Jigarthanda+LLP+-+Since+1977&query_place_id=ChIJt0XsKp7FADsRrA-f-s4XpGw", "note": "Kamarajar Salai/Vilakkuthoon location for the milk-based drink. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "Hotel Sabarees Residency", "r": "3.8 (904)", "url": "https://www.google.com/maps/search/?api=1&query=Hotel+Sabarees+Residency&query_place_id=ChIJV0SKLoTFADsRbQSRzl2p2Z4", "note": "Temple-area lodging; mixed rating, check recent room reviews and current terms. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Temple-area markets", "note": "Textiles, devotional goods and local crafts; access may change with temple works."}, {"n": "Sungudi sari shops", "note": "Traditional tie-dyed cotton saris; ask about weave, fabric and dye."}], "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Madurai%2C_India.jpg/960px-Madurai%2C_India.jpg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=thumbnail&_=20090521165822", "getting": [{"text": "Train, Chennai to Madurai", "fare": "about 7 hr 40 min listed; varies by service", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/Chennai/Madurai"}, {"text": "Temple administration", "fare": "Confirm current entry eligibility and dress rules before visiting", "source": "HRCE", "url": "https://maduraimeenakshi.hrce.tn.gov.in/"}]},
    {"id": "pune", "name": "Pune", "state": "Maharashtra", "region": "west", "vibes": ["city", "heritage", "spiritual"], "blurb": "Maratha-era landmarks, Maharashtrian snacks and lively neighbourhoods. Keep hill-fort excursions separate from the city day; monsoon paths can be slippery.", "alt": "Shaniwar Wada entrance in Pune", "credit": "Janvi306 / Wikimedia Commons / CC BY-SA 4.0", "best": "Oct - Feb", "months": [9, 10, 11, 0, 1], "festival": {"name": "Ganesh Festival", "when": "Aug - Sep; lunar dates vary", "note": "Public Ganesh celebrations and processions; expect crowds and traffic diversions."}, "ideal": "3 days", "places": ["Shaniwar Wada", "Aga Khan Palace and its freedom-movement history", "Pataleshwar Cave Temple; check visitor and worship rules", "Sinhagad Fort: separate hill excursion; check weather and access"], "food": [{"n": "Misal pav", "diet": "veg", "note": "Spiced sprout curry with bread; heat and toppings vary."}, {"n": "Pithla bhakri", "diet": "veg", "note": "Gram-flour preparation with millet flatbread."}, {"n": "Puran poli", "diet": "veg", "note": "Sweet lentil-filled flatbread; often served with ghee."}], "eats": [{"n": "Vaishali Restaurant", "r": "4.3 (18,753)", "url": "https://www.google.com/maps/search/?api=1&query=Vaishali+Restaurant&query_place_id=ChIJdx_8LQ-_wjsRIGCB4HCQVpE", "note": "FC Road vegetarian restaurant; check the current menu. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Bedekar Misal", "r": "3.8 (11,584)", "url": "https://www.google.com/maps/search/?api=1&query=Bedekar+Misal&query_place_id=ChIJyaFFIHHAwjsR8EPkdCKUoSM", "note": "Narayan Peth misal stop; mixed rating, check recent reviews. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "Hotel and Restaurant Shreyas", "r": "4.2 (6,626)", "url": "https://www.google.com/maps/search/?api=1&query=Hotel+and+Restaurant+Shreyas&query_place_id=ChIJRU_gxwXBwjsR1VEwfLjetKs", "note": "Deccan Gymkhana hotel option; compare current room types and rates. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Laxmi Road and Tulsi Baug", "note": "Saris, jewellery, household goods and busy traditional markets."}, {"n": "Camp and Koregaon Park", "note": "Boutiques, bakeries and contemporary shops; compare prices."}], "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/Shaniwar_Wada%2C_Pune%2C_Mumbai%2C_India.jpg/960px-Shaniwar_Wada%2C_Pune%2C_Mumbai%2C_India.jpg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=thumbnail&_=20170602193634", "getting": [{"text": "Train, Mumbai to Pune", "fare": "about 3 hr 12 min listed; varies by service", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/Mumbai/Pune"}]},
    {"id": "ahmedabad", "name": "Ahmedabad", "state": "Gujarat", "region": "west", "vibes": ["city", "heritage", "spiritual"], "blurb": "Old-city pols, carved mosques, Gandhi history and Gujarati thalis. Summers can be intensely hot; plan heritage walks in cooler hours and respect active places of worship.", "alt": "Sabarmati Ashram building in Ahmedabad, photographed in 2005", "credit": "S.K. Desai (L1CENSET0K1LL) / Wikimedia Commons / Public domain; photo from 2005", "best": "Oct - Mar", "months": [9, 10, 11, 0, 1, 2], "festival": {"name": "Uttarayan kite celebrations", "when": "January, around Makar Sankranti; confirm event dates", "note": "Rooftop kite flying and city events; avoid unsafe rooftops and sharp kite string."}, "ideal": "3 days", "places": ["Sabarmati Ashram", "Old-city pols and heritage lanes", "Sidi Saiyyed Mosque and Jama Masjid; check visitor rules", "Kankaria Lake; Adalaj Stepwell is a separate excursion"], "food": [{"n": "Gujarati thali", "diet": "veg", "note": "A platter of vegetables, dal, breads and sweets; dairy is common."}, {"n": "Undhiyu", "diet": "veg", "note": "Mixed vegetable dish, especially associated with winter."}, {"n": "Dhokla and thepla", "diet": "veg", "note": "Steamed savoury cakes and fenugreek flatbread; confirm accompaniments."}], "eats": [{"n": "Chandravilas restaurant", "r": "4.2 (2,692)", "url": "https://www.google.com/maps/search/?api=1&query=Chandravilas+restaurant&query_place_id=ChIJV4EkrC-FXjkRawIXYYdD93w", "note": "Old-city Gujarati food institution on Gandhi Road. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Agashiye", "r": "4.6 (6,297)", "url": "https://www.google.com/maps/search/?api=1&query=Agashiye&query_place_id=ChIJq6qqOjeEXjkRlgtTCAitmYg", "note": "House of MG thali restaurant; not a budget-price claim, check current menu and charges. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "French Haveli", "r": "4.4 (410)", "url": "https://www.google.com/maps/search/?api=1&query=French+Haveli&query_place_id=ChIJOZAP3kqEXjkRJgDcZIQL-AM", "note": "Old-city heritage lodging option; rates and room facilities vary, not a confirmed budget tariff. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Law Garden market", "note": "Embroidered textiles, accessories and handicrafts."}, {"n": "Lal Darwaja and old-city shops", "note": "Traditional textiles and everyday markets; ask about fabric and workmanship."}], "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Sabarmati_Ashram.jpg/960px-Sabarmati_Ashram.jpg?20060425112600", "getting": [{"text": "Train, Mumbai to Ahmedabad", "fare": "about 5 hr 55 min listed; varies by service", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/Mumbai/Ahmedabad"}]},
    {"id": "lucknow", "name": "Lucknow", "state": "Uttar Pradesh", "region": "north", "vibes": ["city", "heritage", "culture", "spiritual"], "blurb": "Awadhi architecture, kebabs and chikankari markets along the Gomti. Active religious sites have their own visitor rules; winter fog can affect transport.", "alt": "Rumi Darwaza gateway in Lucknow", "credit": "Aryanmathurphotography / Wikimedia Commons / CC BY-SA 4.0", "best": "Oct - Mar", "months": [9, 10, 11, 0, 1, 2], "festival": {"name": "Lucknow Mahotsav", "when": "Traditionally Nov - Dec; check whether and when it runs", "note": "Awadhi arts, crafts and cuisine festival; do not assume a current-year schedule."}, "ideal": "3 days", "places": ["Bara Imambara and its labyrinth; check ticket and guide arrangements", "Chota Imambara and Rumi Darwaza", "The Residency and city heritage sites", "Chowk markets and Gomti-side public spaces"], "food": [{"n": "Galouti kebabs", "diet": "nonveg", "note": "Soft minced-meat kebabs; confirm the meat used before ordering."}, {"n": "Awadhi biryani", "diet": "nonveg", "note": "Aromatic meat-and-rice preparation; vegetarian versions are separate."}, {"n": "Chaat and lassi", "diet": "veg", "note": "Street snacks and a yoghurt-based drink; check toppings and hygiene."}], "eats": [{"n": "Tunday Kababi, Aminabad", "r": "4.2 (53,326)", "url": "https://www.google.com/maps/search/?api=1&query=Tunday+Kababi%2C+Aminabad&query_place_id=ChIJEfzCO7r9mzkRHFoXu7K_eCw", "note": "Aminabad branch for Awadhi meat dishes; ask which meat each item contains. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Shree Lassi & Sons", "r": "4.1 (3,333)", "url": "https://www.google.com/maps/search/?api=1&query=Shree+Lassi+%26+Sons&query_place_id=ChIJf5VSk7b9mzkRmQB38mPl_uk", "note": "Chowk lassi and snack shop; dairy-based drinks. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "Hotel Deep Palace", "r": "3.8 (2,005)", "url": "https://www.google.com/maps/search/?api=1&query=Hotel+Deep+Palace&query_place_id=ChIJYZYYI1X8mzkRoVstuPA1nBs", "note": "Husainganj hotel option; mixed rating, inspect recent room reviews and rates. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Chowk", "note": "Chikankari, zardozi embroidery and traditional crafts; ask handwork versus machinework."}, {"n": "Aminabad and Hazratganj", "note": "Traditional market lanes and central-city shopping."}], "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Rumi_Darwaja_%28Rumi_Gate%29.jpg/960px-Rumi_Darwaja_%28Rumi_Gate%29.jpg?20180922033202", "getting": [{"text": "Train, New Delhi to Lucknow", "fare": "about 7 hr 25 min listed; varies by service", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/New-Delhi/Lucknow"}]},
    {"id": "bhopal", "name": "Bhopal", "state": "Madhya Pradesh", "region": "central", "vibes": ["city", "heritage", "culture", "spiritual"], "blurb": "Lakefront walks, museums and the architectural legacy of Bhopal's Begums. Sanchi and Bhimbetka are separate excursions, not city-centre sights.", "alt": "Moti Masjid courtyard in Bhopal, photographed in 2012", "credit": "Arian Zwegers / Wikimedia Commons / CC BY 2.0; photo from 2012", "best": "Oct - Mar", "months": [9, 10, 11, 0, 1, 2], "festival": {"name": "Lokrang", "when": "Late January, usually from 26 January; confirm programme", "note": "Tribal and folk arts, performances and crafts; check the current venue and dates."}, "ideal": "3 days", "places": ["Upper Lake (Bhojtal) and lakefront; use licensed boating services", "Madhya Pradesh Tribal Museum and Museum of Mankind", "Taj-ul-Masjid and Moti Masjid; check worship and visitor rules", "Sanchi and Bhimbetka: plan separate out-of-city visits"], "food": [{"n": "Poha and jalebi", "diet": "veg", "note": "Flattened-rice breakfast with syrupy sweets; toppings vary."}, {"n": "Dal bafla", "diet": "veg", "note": "Wheat dumplings with lentils, often served with ghee."}, {"n": "Achari gosht and seekh kebabs", "diet": "nonveg", "note": "Meat preparations; confirm the meat and ingredients."}], "eats": [{"n": "Manohar Dairy", "r": "4.3 (16,473)", "url": "https://www.google.com/maps/search/?api=1&query=Manohar+Dairy&query_place_id=ChIJD2972iRofDkRVukUwu6PXqg", "note": "Hamidia Road sweets and vegetarian-snacks option. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Jameel Hotel", "r": "3.8 (857)", "url": "https://www.google.com/maps/search/?api=1&query=Jameel+Hotel&query_place_id=ChIJQRmo0CFofDkRfmcQBaxNbbw", "note": "Ibrahimpura branch for local meat dishes; mixed rating, check recent reviews. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "MPT Palash Residency", "r": "4.4 (2,079)", "url": "https://www.google.com/maps/search/?api=1&query=MPT+Palash+Residency&query_place_id=ChIJwxg3mNNDfDkRZinrLpqnZRk", "note": "MP Tourism hotel in TT Nagar; compare current rates, not a confirmed budget tariff. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Chowk Bazaar", "note": "Traditional textiles, jewellery and local crafts."}, {"n": "Museum craft outlets", "note": "Regional crafts when outlets are open; confirm provenance and prices."}], "photo": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Bhopal%2C_Moti_Masjid_%289840931024%29.jpg/960px-Bhopal%2C_Moti_Masjid_%289840931024%29.jpg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=thumbnail&_=20160308200935", "getting": [{"text": "Train, New Delhi to Bhopal", "fare": "about 8 hr 12 min listed; varies by service", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/New-Delhi/Bhopal"}]},
    {"id": "indore", "name": "Indore", "state": "Madhya Pradesh", "region": "central", "vibes": ["city", "heritage", "culture", "spiritual"], "blurb": "Holkar palaces, Jain glasswork and food-market evenings in the Malwa region. Sarafa is busy after dark; check hygiene and keep hot summer sightseeing to cooler hours.", "alt": "Rajwada Palace in Indore, photographed in 2013", "credit": "Bernard Gagnon / Wikimedia Commons / CC BY-SA 3.0; photo from 2013", "best": "Oct - Mar", "months": [9, 10, 11, 0, 1, 2], "festival": {"name": "Rangpanchami", "when": "Around Holi in February - March; lunar dates vary", "note": "Colour celebrations and the Gair procession; expect crowds and road diversions."}, "ideal": "3 days", "places": ["Rajwada Palace and the old-city lanes", "Lal Bagh Palace", "Kanch Mandir and Khajrana Ganesh Temple; check worship and visitor rules", "Sarafa Bazaar after dark and Chhappan Dukan for food browsing"], "food": [{"n": "Bhutte ka kees", "diet": "veg", "note": "Grated-corn preparation; milk and ghee are common, confirm ingredients."}, {"n": "Dahi bada", "diet": "veg", "note": "Lentil dumplings in yoghurt with chutneys and spices."}, {"n": "Garadu", "diet": "veg", "note": "Spiced fried yam, especially associated with winter evenings."}], "eats": [{"n": "Joshi Dahi Bada House", "r": "4.4 (5,000)", "url": "https://www.google.com/maps/search/?api=1&query=Joshi+Dahi+Bada+House&query_place_id=ChIJoc7euaD9YjkRG06_9U13XQs", "note": "Bada Sarafa dahi-bada stop; confirm serving hours. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Vijay Chaat House (Chappan Dukan)", "r": "4.3 (1,892)", "url": "https://www.google.com/maps/search/?api=1&query=Vijay+Chaat+House+%28Chappan+Dukan%29&query_place_id=ChIJJ8Ud8Dj9YjkRLW7eesbQXOo", "note": "Chhappan Dukan branch for chaat and snacks. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "Hotel Shreemaya", "r": "4.5 (7,115)", "url": "https://www.google.com/maps/search/?api=1&query=Hotel+Shreemaya&query_place_id=ChIJzc8Tlxb9YjkRmX-dBV4WjkY", "note": "RNT Marg hotel option; compare room types and current rates, not a budget-tariff claim. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Sarafa Bazaar", "note": "Jewellery shops by day; compare purity, bills and workmanship."}, {"n": "MT Cloth Market and Mrignayani", "note": "Textiles and regional handlooms; ask about fabric and provenance."}], "photo": "https://thumb.wikimedia.org/wikipedia/commons/thumb/5/52/Rajwada_Palace%2C_Indore.jpg/960px-Rajwada_Palace%2C_Indore.jpg", "getting": [{"text": "Train, New Delhi region to Indore", "fare": "about 12 hr 15 min listed; varies by service", "source": "Rome2rio", "url": "https://www.rome2rio.com/s/New-Delhi/Indore-Junction-Station"}]},
    {"id": "gwalior", "name": "Gwalior", "state": "Madhya Pradesh", "region": "central", "vibes": ["heritage", "culture", "city", "spiritual"], "blurb": "A hilltop fort, carved Jain figures and a deep Hindustani classical-music tradition. Fort paths and stairs need comfortable shoes; avoid the midday summer heat.", "alt": "Front view of Gwalior Fort", "credit": "Anuppyr007 / Wikimedia Commons / CC BY-SA 4.0", "best": "Oct - Mar", "months": [9, 10, 11, 0, 1, 2], "festival": {"name": "Tansen Sangeet Samaroh", "when": "December; MP Tourism lists 14 - 19 Dec 2026", "note": "Classical music at Tansen Samadhi Sthal; recheck the current programme before travelling."}, "ideal": "2 - 3 days", "places": ["Gwalior Fort and Man Mandir Palace", "Gujari Mahal Archaeological Museum; check opening days", "Jai Vilas Palace museum; check visitor access", "Tansen and Mohammed Ghaus tombs; fort-area Jain carvings and temples"], "food": [{"n": "Bedai", "diet": "veg", "note": "Lentil-filled fried bread, commonly eaten with vegetable curry."}, {"n": "Gajak", "diet": "veg", "note": "Sesame-and-jaggery sweet; nuts and ingredients vary."}, {"n": "Motichoor laddu", "diet": "veg", "note": "Small gram-flour pearls made into sweets; ghee is common."}], "eats": [{"n": "Bahadura Sweets", "r": "4.5 (1,996)", "url": "https://www.google.com/maps/search/?api=1&query=Bahadura+Sweets&query_place_id=ChIJEyTku8zFdjkRN6fghkMbkKs", "note": "Lohiya Bazaar sweets shop associated with laddus. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "S.S. Kachori Wala", "r": "4.0 (2,181)", "url": "https://www.google.com/maps/search/?api=1&query=S.S.+Kachori+Wala&query_place_id=ChIJawgMoczFdjkRI9QcRiaeyu8", "note": "Naya Bazar kachori and snack stop. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "MPT Tansen Residency, Gwalior", "r": "4.2 (2,916)", "url": "https://www.google.com/maps/search/?api=1&query=MPT+Tansen+Residency%2C+Gwalior&query_place_id=ChIJD9PlcKfGdjkROvA2Q6TSdek", "note": "MP Tourism hotel on Gandhi Road; compare current rates and recent room reviews. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Maharaj Bada and Topi Bazaar", "note": "Textiles, accessories and traditional market shopping."}, {"n": "Sarafa Bazaar and regional craft shops", "note": "Jewellery, handicrafts and Batto Bai dolls; confirm provenance."}], "photo": "https://upload.wikimedia.org/wikipedia/commons/1/15/Gwalior_Fort_front.jpg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original", "getting": [{"text": "Train, New Delhi region to Gwalior", "fare": "about 4 hr 31 min average listed; varies by service", "source": "Rome2rio", "url": "https://www.rome2rio.com/Train/New-Delhi-Station/Gwalior"}]},
    {"id": "orchha", "name": "Orchha", "state": "Madhya Pradesh", "region": "central", "vibes": ["heritage", "culture", "spiritual"], "blurb": "Bundela palaces, active temples and riverside cenotaphs beside the Betwa. Keep a slower pace and treat river activities as weather-dependent, not guaranteed daily services.", "alt": "Cenotaphs on the bank of the Betwa River in Orchha", "credit": "Rajiv Kumar Solanki / Wikimedia Commons / CC BY-SA 4.0", "best": "Oct - Mar", "months": [9, 10, 11, 0, 1, 2], "festival": {"name": "Ram Navami", "when": "March - April; lunar dates vary", "note": "Celebrations at the active Ram Raja Temple; check local arrangements and crowd controls."}, "ideal": "2 days", "places": ["Orchha Fort complex: Jahangir Mahal and Raja Mahal", "Ram Raja Temple; check worship, dress and photography rules", "Chaturbhuj Temple and Lakshmi Narayan Temple", "Royal chhatris and Betwa riverside; avoid unsafe water access"], "food": [{"n": "Dal bafla", "diet": "veg", "note": "Wheat dumplings with lentils, often served with ghee."}, {"n": "Poha and jalebi", "diet": "veg", "note": "Flattened-rice breakfast and syrupy sweets; toppings vary."}, {"n": "Kachori", "diet": "veg", "note": "Fried filled snack; ask about the filling and accompaniments."}], "eats": [{"n": "Ramraja Restaurant & Caf\u00e9", "r": "4.0 (291)", "url": "https://www.google.com/maps/search/?api=1&query=Ramraja+Restaurant+%26+Caf%C3%A9&query_place_id=ChIJHTduwpF4dzkR-hfqBuVXjqA", "note": "Palace Road cafe and restaurant; check the current menu. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Indiana Restaurant", "r": "4.8 (1,189)", "url": "https://www.google.com/maps/search/?api=1&query=Indiana+Restaurant&query_place_id=ChIJxzvCGb15dzkRo2V2v6al9tE", "note": "Main-road restaurant near the bus stand; check menu and recent reviews. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "MPT Betwa Retreat, Orchha", "r": "4.3 (1,909)", "url": "https://www.google.com/maps/search/?api=1&query=MPT+Betwa+Retreat%2C+Orchha&query_place_id=ChIJv2jbqZZ4dzkRdf72u4qDfmM", "note": "MP Tourism lodging near the Betwa; room types and views vary, check before booking. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Ram Raja Temple market", "note": "Small shops for souvenirs and devotional items."}, {"n": "Fort-area handicraft shops", "note": "Local and regional crafts; compare workmanship and prices."}], "photo": "https://thumb.wikimedia.org/wikipedia/commons/thumb/3/32/Chhatris-Cenotaphs_on_the_bank_of_Betwa_River%2COrcha%2C_Madhya_Pradesh.jpg/960px-Chhatris-Cenotaphs_on_the_bank_of_Betwa_River%2COrcha%2C_Madhya_Pradesh.jpg", "getting": [{"text": "Train, New Delhi region to Orchha via Jhansi and onward road transfer", "fare": "duration not verified - travel via Jhansi, then road transfer; varies by service", "source": "MP Tourism", "url": "https://www.mptourism.com/destination-orchha.php"}]},
    {"id": "khajuraho", "name": "Khajuraho", "state": "Madhya Pradesh", "region": "central", "vibes": ["heritage", "culture", "spiritual"], "blurb": "Hindu and Jain temple groups with detailed Chandela-era sculpture, including erotic carvings. Allow time beyond the western group; Panna and Raneh Falls are separate excursions.", "alt": "A temple at Khajuraho, photographed in 2000", "credit": "Paul Mannix / Wikimedia Commons / CC BY 2.0; photo from 2000", "best": "Oct - Mar", "months": [9, 10, 11, 0, 1, 2], "festival": {"name": "Khajuraho Dance Festival", "when": "February; confirm the current-year programme", "note": "Indian classical dance near the temple setting. Official pages contain conflicting year labels, so no future dates are guaranteed here."}, "ideal": "2 - 3 days", "places": ["Western temple group: Kandariya Mahadeva and Lakshmana temples", "Eastern Jain temples, including Parsvanath", "Southern group: Duladeo and Chaturbhuj temples", "Archaeological museum; check current opening and ticket arrangements"], "food": [{"n": "Jalebi", "diet": "veg", "note": "Syrupy fried sweet, one of the regional snacks found here."}, {"n": "Moong dal halwa", "diet": "veg", "note": "Rich lentil-based sweet; commonly made with ghee and milk."}, {"n": "Sabudana khichdi", "diet": "veg", "note": "Tapioca-pearl dish; peanuts and ghee may be used, confirm the recipe."}], "eats": [{"n": "Raja Cafe Restaurant , Khajuraho", "r": "4.1 (1,720)", "url": "https://www.google.com/maps/search/?api=1&query=Raja+Cafe+Restaurant+%2C+Khajuraho&query_place_id=ChIJCc7HZQHmgjkR50BZ2zRDX9E", "note": "Opposite the western temple group; mixed menu, confirm ingredients. Ratings checked 2 Nov 2026; prices and availability not checked."}, {"n": "Badri Seth Marwari Bhoj", "r": "4.4 (3,889)", "url": "https://www.google.com/maps/search/?api=1&query=Badri+Seth+Marwari+Bhoj&query_place_id=ChIJoyHr6wDmgjkR0boMokZtuhY", "note": "Sevagram vegetarian-meal option; ask about current thali choices. Ratings checked 2 Nov 2026; prices and availability not checked."}], "stays": [{"n": "MPT PAYAL", "r": "4.2 (793)", "url": "https://www.google.com/maps/search/?api=1&query=MPT+PAYAL&query_place_id=ChIJlzY05gTmgjkRiPDeehuaGKA", "note": "MP Tourism lodging near the western temple area; compare live rates and room facilities. Ratings checked 2 Nov 2026; prices and availability not checked."}], "shops": [{"n": "Town handicraft shops", "note": "Stone, brass and iron sculpture souvenirs; choose replicas, never antiquities."}, {"n": "Jain Temple Road shops", "note": "Handicrafts and ornaments; compare material, workmanship and bills."}], "photo": "https://thumb.wikimedia.org/wikipedia/commons/thumb/c/ce/Temple_at_Khajuraho%2C_Madhya_Pradesh%2C_India.jpg/960px-Temple_at_Khajuraho%2C_Madhya_Pradesh%2C_India.jpg", "getting": [{"text": "Train, New Delhi region to Khajuraho", "fare": "about 8 hr 20 min on train 22470 from Hazrat Nizamuddin; confirm running day; varies by service", "source": "RailYatri", "url": "https://www.railyatri.in/time-table/22470"}]}
  ];

  // Live quotes pulled from Duffel on 30 Oct 2026: one-way economy, 28 Nov 2026.
  var FARES = [
    { route: 'New Delhi to Goa', fare: 'from $115.80' },
    { route: 'New Delhi to Leh', fare: 'from $77.60' },
    { route: 'New Delhi to Kochi (for Kerala)', fare: 'from $148.40' },
    { route: 'New Delhi to Port Blair (for Andaman)', fare: 'from $187.50' }
  ];


  var REGIONS = [['all', 'All India'], ['north', 'North'], ['west', 'West'], ['south', 'South'], ['east', 'East'], ['central', 'Central'], ['islands', 'Islands']];
  var VIBES = [['all', 'Every mood'], ['mountains', 'Mountains'], ['beaches', 'Beaches'], ['heritage', 'Heritage'], ['culture', 'Culture'], ['city', 'City'], ['adventure', 'Adventure'], ['spiritual', 'Religious']];

  var state = { region: 'all', vibe: 'all', months: [], query: '' };
  var $ = function (s) { return document.querySelector(s); };
  // In the hosted preview, bundled asset URLs are provided for the relative
  // photo paths; standalone, the photos/ folder next to index.html is used.
  var PHOTO_URLS = window.__SAFARNAMA_PHOTOS__ || {};
  function photoUrl(p) { return PHOTO_URLS[p] || p; }

  // All 28 states + 8 UTs: recurring season and festival guidance (festival
  // timing mostly follows the lunar calendar; confirm exact dates per year).
  var STATES = [
    ['Andhra Pradesh', 'Nov - Feb', 'Sankranti', 'January', 'https://utsav.gov.in/view-event/sankranti-festival-1'],
    ['Arunachal Pradesh', 'Oct - Apr', 'Ziro Festival of Music', 'September', 'https://zirofestival.com'],
    ['Assam', 'Oct - Apr', 'Bohag Bihu', 'April', 'https://assamtourism.gov.in/april.php'],
    ['Bihar', 'Oct - Mar', 'Chhath Puja', 'Oct - Nov', 'https://www.incredibleindia.gov.in/en/festivals-and-events/chhath-puja'],
    ['Chhattisgarh', 'Oct - Mar', 'Bastar Dussehra', 'Sep - Oct', 'https://www.incredibleindia.gov.in/en/festivals-and-events/chhattisgarh/bastar-dussehra'],
    ['Goa', 'Nov - Feb', 'Goa Carnival', 'February', 'https://www.incredibleindia.gov.in/en/festivals-and-events/goa/carnaval'],
    ['Gujarat', 'Nov - Feb', 'Rann Utsav', 'Nov - Feb', 'https://www.rannutsavgujarat.in/'],
    ['Haryana', 'Oct - Mar', 'Surajkund Crafts Mela', 'February', 'https://haryanatourism.gov.in/fair-and-festivals/surajkund-international-craft-mela/'],
    ['Himachal Pradesh', 'Oct - Jun', 'Kullu Dussehra', 'October', 'https://hpkullu.nic.in/whats-new/fairs-festivals/'],
    ['Jharkhand', 'Oct - Mar', 'Sarhul', 'Mar - Apr', 'https://tourism.jharkhand.gov.in/festivals'],
    ['Karnataka', 'Oct - Feb', 'Mysuru Dasara', 'Sep - Oct', 'https://mysurudasara.org/about'],
    ['Kerala', 'Sep - Mar', 'Onam', 'Aug - Sep', 'https://www.keralatourism.org/onam-festival'],
    ['Madhya Pradesh', 'Oct - Mar', 'Khajuraho Dance Festival', 'February', 'https://www.mptourism.com/khajuraho-dance-festival.htm'],
    ['Maharashtra', 'Nov - Feb', 'Ganesh Chaturthi', 'Aug - Sep', 'https://www.incredibleindia.gov.in/en/maharashtra/mumbai/experiencing-the-essence-of-ganesh-chaturthi'],
    ['Manipur', 'Oct - Mar', 'Sangai Festival', '21 - 30 Nov', 'https://www.utsav.gov.in/view-event/manipur-sangai-festival-2025'],
    ['Meghalaya', 'Oct - May', 'Wangala', 'November', 'https://www.meghalaya.gov.in/wangala'],
    ['Mizoram', 'Oct - Mar', 'Chapchar Kut', 'March', 'https://aizawl.nic.in/festival/chapchar-kut-festival/'],
    ['Nagaland', 'Oct - May', 'Hornbill Festival', '1 - 10 Dec', 'https://tourism.nagaland.gov.in/events/hornbill-festival/'],
    ['Odisha', 'Oct - Feb', 'Konark Festival', 'December', 'https://odishatourism.gov.in/en/konark-festival'],
    ['Punjab', 'Oct - Mar', 'Baisakhi', '13 - 14 Apr', 'https://punjabtourism.punjab.gov.in/baisakhi.php'],
    ['Rajasthan', 'Oct - Mar', 'Pushkar Camel Fair', 'Oct - Nov', 'https://www.incredibleindia.gov.in/en/festivals-and-events/pushkar-camel-fair'],
    ['Sikkim', 'Mar - Jun, Oct - Dec', 'Saga Dawa', 'May - Jun', 'http://sikkimtourism.gov.in/Public/ExperienceSikkim/FairsAndFestivalDetails/FF20A077?type=Festival'],
    ['Tamil Nadu', 'Nov - Feb', 'Pongal', 'January', 'https://en.wikipedia.org/wiki/Pongal_(festival)'],
    ['Telangana', 'Nov - Feb', 'Bathukamma', 'Sep - Oct', 'https://www.incredibleindia.gov.in/en/festivals-and-events/telangana/bathukamma'],
    ['Tripura', 'Oct - Mar', 'Durga Puja', 'October', 'https://ich.unesco.org/en/RL/durga-puja-in-kolkata-00703'],
    ['Uttar Pradesh', 'Oct - Mar', 'Taj Mahotsav, Agra', '18 - 27 Feb', 'https://www.incredibleindia.gov.in/en/festivals-and-events/taj-mahotsav'],
    ['Uttarakhand', 'Mar - Jun, Sep - Nov', 'Char Dham yatra season', 'May - Oct', 'https://www.triptochardham.in/which-month-is-best-for-char-dham-yatra'],
    ['West Bengal', 'Oct - Feb', 'Durga Puja', 'October', 'https://ich.unesco.org/en/RL/durga-puja-in-kolkata-00703']
  ];
  var UTS = [
    ['Andaman & Nicobar', 'Oct - May', 'Island Tourism Festival', 'from 5 Jan', 'https://andamantourism.gov.in/festivel.php?id=MFVHNzg2T3NpTkpvbFJod0tOYTNOS3k0UWdnN1RHaXJIRitNKzFEenN6Yz0='],
    ['Chandigarh', 'Oct - Mar', 'Rose Festival', 'February', 'https://chandigarhtourism.gov.in/pages/event/52'],
    ['Dadra & Nagar Haveli and Daman & Diu', 'Nov - Feb', 'Nariyal Poornima', 'August', 'https://dded.gov.in/detail.php?id=27'],
    ['Delhi', 'Oct - Mar', 'Diwali season', 'Oct - Nov', 'https://delhitourism.gov.in/dt/festivals/diwali.html'],
    ['Jammu & Kashmir', 'Mar - Oct', 'Tulip Festival, Srinagar', 'April', 'https://srinagar.nic.in/tourist-place/tulip-garden/'],
    ['Ladakh', 'May - Sep', 'Hemis Tsechu', 'Jun - Jul', 'https://www.incredibleindia.gov.in/en/festivals-and-events/ladakh/hemis-festival'],
    ['Lakshadweep', 'Oct - May', 'Eid celebrations', 'varies by year', 'https://lakshadweep.gov.in/about-lakshadweep/culture-heritage/'],
    ['Puducherry', 'Oct - Mar', 'Pongal', 'January', 'https://www.py.gov.in/home-holiday-orders-declaration-holiday-14-01-2026-bhogi-puducherry-karaikal-and-yanam-regions-union']
  ];

  function renderStates(list, el) {
    el.innerHTML = list.map(function (s) {
      return '<div class="state-row"><span class="st-name">' + s[0] + '</span>' +
        '<span class="st-best">Best: ' + s[1] + '</span>' +
        '<span class="st-fest"><b>' + s[2] + '</b> - ' + s[3] + ' <a class="st-src" href="' + s[4] + '" target="_blank" rel="noopener">source</a></span></div>';
    }).join('');
  }
  var statesList = $('#statesList'), utsList = $('#utsList'), statesCount = $('#statesCount');
  renderStates(STATES, statesList);
  renderStates(UTS, utsList);
  statesCount.textContent = STATES.length + ' states';
  $('#stateSearch').addEventListener('input', function (e) {
    var q = e.target.value.trim().toLowerCase();
    var filtered = q ? STATES.filter(function (s) { return (s[0] + ' ' + s[2]).toLowerCase().indexOf(q) !== -1; }) : STATES;
    var filteredUts = q ? UTS.filter(function (s) { return (s[0] + ' ' + s[2]).toLowerCase().indexOf(q) !== -1; }) : UTS;
    renderStates(filtered, statesList);
    renderStates(filteredUts, utsList);
    statesCount.textContent = filtered.length + ' of ' + STATES.length + ' states' + (filteredUts.length !== UTS.length ? ' + ' + filteredUts.length + ' UTs' : '');
  });



  /* ---------- nav ---------- */
  var nav = $('#nav');
  window.addEventListener('scroll', function () {
    nav.classList.toggle('is-scrolled', window.scrollY > 10);
  }, { passive: true });
  var navToggle = $('#navToggle'), navLinks = $('#navLinks');
  navToggle.addEventListener('click', function () {
    var open = navLinks.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(open));
  });
  // Section filtering: viewers where anchor/scrollIntoView navigation is swallowed
  // still show the target instantly because we hide the other sections outright.
  var NAV_SECTIONS = ['surprise', 'destinations', 'flights', 'seasons', 'faq', 'about'];
  function showSection(id) {
    if (NAV_SECTIONS.indexOf(id) === -1) {
      document.body.removeAttribute('data-nav-filter');
      return;
    }
    document.body.setAttribute('data-nav-filter', id);
  }
  navLinks.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('a') : null;
    if (!a) return;
    e.preventDefault();
    navLinks.classList.remove('is-open');
    navToggle.setAttribute('aria-expanded', 'false');
    var id = (a.getAttribute('href') || '').split('#')[1];
    var el = id && document.getElementById(id);
    showSection(id);
    if (el) {
      try { window.scrollTo({ top: 0, behavior: 'instant' }); } catch (err) { window.scrollTo(0, 0); }
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
  $('.nav-brand').addEventListener('click', function (e) {
    e.preventDefault();
    showSection(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  $('#heroMapBtn').addEventListener('click', function () {
    showSection('destinations');
    try { window.scrollTo({ top: 0, behavior: 'instant' }); } catch (err) { window.scrollTo(0, 0); }
    $('#destinations').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  /* ---------- chips ---------- */
  function buildChips(el, items, key) {
    items.forEach(function (pair) {
      var b = document.createElement('button');
      b.className = 'chip' + (pair[0] === 'all' ? ' is-active' : '');
      b.textContent = pair[1];
      b.dataset.value = pair[0];
      b.addEventListener('click', function () {
        state[key] = pair[0];
        el.querySelectorAll('.chip').forEach(function (c) { c.classList.toggle('is-active', c === b); });
        renderGrid();
      });
      el.appendChild(b);
    });
  }
  buildChips($('#regionFilters'), REGIONS, 'region');
  buildChips($('#vibeFilters'), VIBES, 'vibe');

  /* ---------- month bar ---------- */
  var monthBar = $('#monthBar'), monthNote = $('#monthNote');
  MONTHS.forEach(function (m, i) {
    var b = document.createElement('button');
    b.className = 'chip';
    b.textContent = m;
    b.addEventListener('click', function () {
      var at = state.months.indexOf(i);
      if (at === -1) state.months.push(i); else state.months.splice(at, 1);
      monthBar.querySelectorAll('.chip').forEach(function (c, ci) { c.classList.toggle('is-active', state.months.indexOf(ci) !== -1); });
      monthNote.textContent = state.months.length === 0
        ? ''
        : 'In ' + state.months.slice().sort(function (a, b2) { return a - b2; }).map(function (mi) { return MONTHS[mi]; }).join(', ') + ', the season favours the highlighted places - the rest are dimmed, not ruled out.';
      renderGrid();
    });
    monthBar.appendChild(b);
  });


  /* ---------- surprise trip planner ---------- */
  var SURPRISE_VIBES = [['any', 'Any mood']].concat(VIBES.slice(1));
  var SURPRISE_REGIONS = [['any', 'Anywhere']].concat(REGIONS.slice(1));
  var HUBS = {
    delhi: ['Delhi', 28.61, 77.21], amritsar: ['Amritsar', 31.63, 74.87], jaipur: ['Jaipur', 26.91, 75.79],
    mumbai: ['Mumbai', 19.08, 72.88], ahmedabad: ['Ahmedabad', 23.02, 72.57], kolkata: ['Kolkata', 22.57, 88.36],
    bengaluru: ['Bengaluru', 12.97, 77.59], chennai: ['Chennai', 13.08, 80.27], hyderabad: ['Hyderabad', 17.38, 78.49],
    kochi: ['Kochi', 9.93, 76.27]
  };
  var DEST_LL = {
    agra: [27.18, 78.01], jaipur: [26.91, 75.79], udaipur: [24.58, 73.71], amritsar: [31.63, 74.87],
    varanasi: [25.32, 82.99], ladakh: [34.16, 77.58], leh: [34.16, 77.58], manali: [32.24, 77.19], goa: [15.50, 73.83],
    kerala: [9.93, 76.27], mumbai: [19.08, 72.88], darjeeling: [27.04, 88.26], andaman: [11.62, 92.73],
    jaisalmer: [26.92, 70.90], rishikesh: [30.09, 78.29], hampi: [15.34, 76.46], shillong: [25.58, 91.89],
tirupati: [13.6287557, 79.4191795], puri: [19.8134554, 85.8312359], kolkata: [22.5743545, 88.3628734], delhi: [28.7040592, 77.10249019999999], bengaluru: [12.9628957, 77.57754], ajmer: [26.4498954, 74.6399163], shimla: [31.1044032, 77.174829], haridwar: [29.9456906, 78.16424780000001], bodhgaya: [24.6961343, 84.9869547], srinagar: [34.1079265, 74.8039205],
hyderabad: [17.406498, 78.47724389999999], chennai: [13.0570568, 80.2098219], mysuru: [12.2958104, 76.6393805], madurai: [9.9252007, 78.1197754],
pune: [18.5246091, 73.8786239], ahmedabad: [23.0225237, 72.57128639999999], lucknow: [26.8466937, 80.94616599999999], bhopal: [23.2599333, 77.412615],
indore: [22.7195687, 75.8577258], gwalior: [26.2124007, 78.1772053], orchha: [25.3511006, 78.6389169], khajuraho: [24.8318452, 79.91985489999999]
  };
  var surprise = { months: [], vibe: 'any', region: 'any', pick: null };
  var surpriseMonths = $('#surpriseMonths');
  MONTHS.forEach(function (m, i) {
    var b = document.createElement('button');
    b.className = 'chip';
    b.textContent = m;
    b.addEventListener('click', function () {
      var at = surprise.months.indexOf(i);
      if (at === -1) surprise.months.push(i); else surprise.months.splice(at, 1);
      surpriseMonths.querySelectorAll('.chip').forEach(function (c, ci) { c.classList.toggle('is-active', surprise.months.indexOf(ci) !== -1); });
    });
    surpriseMonths.appendChild(b);
  });
  var citySel = $('#surpriseCity');
  Object.keys(HUBS).forEach(function (k) {
    var o = document.createElement('option');
    o.value = k; o.textContent = HUBS[k][0];
    citySel.appendChild(o);
  });
  function surpriseChips(el, pairs, key) {
    pairs.forEach(function (pair) {
      var b = document.createElement('button');
      b.className = 'chip' + (pair[0] === surprise[key] ? ' is-active' : '');
      b.textContent = pair[1];
      b.addEventListener('click', function () {
        surprise[key] = pair[0];
        el.querySelectorAll('.chip').forEach(function (c) { c.classList.toggle('is-active', c === b); });
      });
      el.appendChild(b);
    });
  }
  surpriseChips($('#surpriseVibes'), SURPRISE_VIBES, 'vibe');
  surpriseChips($('#surpriseRegions'), SURPRISE_REGIONS, 'region');

  function haversineKm(a, b) {
    var R = 6371, rad = Math.PI / 180;
    var dLat = (b[0] - a[0]) * rad, dLon = (b[1] - a[1]) * rad;
    var h = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(a[0] * rad) * Math.cos(b[0] * rad) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return 2 * R * Math.asin(Math.sqrt(h));
  }
  function round50(n) { return Math.round(n / 50) * 50; }
  // Rough planning estimates: distance-based fare bands + typical budget rates. Not live prices.
  function estimateTrip(d, hubKey, travelers, days) {
    var hub = HUBS[hubKey] || HUBS.delhi;
    var ll = DEST_LL[d.id];
    if (!ll || ll.length !== 2 || !ll.every(Number.isFinite)) return null;
    var sameCity = d.id === hubKey || (d.id === 'kerala' && hubKey === 'kochi');
    var km = sameCity ? 0 : haversineKm([hub[1], hub[2]], ll) * 1.3;
    if (!Number.isFinite(km)) return null;
    var oneWay, mode;
    if (d.id === 'andaman' || km > 1500) { mode = 'return flight'; oneWay = Math.max(3000, km * 4 + 1500); }
    else if (km > 300) { mode = 'sleeper-class train'; oneWay = Math.max(150, km * 0.55); }
    else { mode = 'bus or drive'; oneWay = Math.max(200, km * 1.2); }
    if (sameCity) { mode = 'local trip'; oneWay = 0; }
    var transport = round50(oneWay * 2) * travelers;
    var nights = Math.max(1, days - 1);
    var rooms = Math.ceil(travelers / 2);
    var stay = round50(nights * rooms * 1200);
    var food = round50(days * travelers * 500);
    var local = round50(days * travelers * 400);
    var sub = transport + stay + food + local;
    var contingency = round50(sub * 0.1);
    return { total: sub + contingency, transport: transport, mode: mode, stay: stay, nights: nights, rooms: rooms, food: food, local: local, contingency: contingency, km: km, days: days };
  }

  function surprisePool(travelers, days) {
    var pool = DESTINATIONS.filter(function (d) {
      if (surprise.region !== 'any' && d.region !== surprise.region) return false;
      if (surprise.vibe !== 'any' && d.vibes.indexOf(surprise.vibe) === -1) return false;
      return true;
    });
    var inSeasonPool = surprise.months.length === 0 ? pool : pool.filter(function (d) { return d.months.some(function (m) { return surprise.months.indexOf(m) !== -1; }); });
    return { pool: inSeasonPool.length ? inSeasonPool : pool, seasonDropped: surprise.months.length > 0 && !inSeasonPool.length };
  }

  function inr(n) { return '\u20B9' + n.toLocaleString('en-IN'); }
  function revealSurprise(d, est, budget, seasonDropped) {
    surprise.pick = d;
    $('#surpriseImg').src = photoUrl(d.photo);
    $('#surpriseImg').alt = d.alt;
    $('#surpriseState').textContent = d.state;
    $('#surpriseName').textContent = d.name;
    var why = [];
    if (surprise.vibe !== 'any' && d.vibes.indexOf(surprise.vibe) !== -1) why.push('matches your ' + surprise.vibe + ' mood');
    var matchedMonths = surprise.months.filter(function (m) { return d.months.indexOf(m) !== -1; }).sort(function (a, b2) { return a - b2; });
    if (matchedMonths.length) why.push('in season in ' + matchedMonths.map(function (mi) { return MONTHS[mi]; }).join(', '));
    if (seasonDropped) why.push('no destination matched every pick, so we ignored the season');
    why.push('estimated fit for your ' + inr(budget) + ' budget with about ' + inr(Math.max(0, budget - est.total)) + ' buffer');
    var whyText = 'Why ' + d.name + ': ' + why.join(' - ') + '.';
    if (d.festival && d.festival.name) whyText += ' Festival: ' + d.festival.name + ', ' + d.festival.when + '.';
    $('#surpriseWhy').textContent = whyText;
    $('#surpriseBudgetNote').textContent = 'planning estimates, not live prices';
    $('#surpriseTotal').textContent = inr(est.total) + ' estimated total';
    $('#surpriseBudgetList').innerHTML =
      '<li><b>Transport</b> - ' + inr(est.transport) + ' (distance-based allowance, round trip, all travelers - route unverified)</li>' +
      '<li><b>Stay</b> - ' + inr(est.stay) + ' (' + est.nights + ' night' + (est.nights > 1 ? 's' : '') + ', ' + est.rooms + ' room' + (est.rooms > 1 ? 's' : '') + ', rough room allowance, not a quote for the listed hotels)</li>' +
      '<li><b>Food</b> - ' + inr(est.food) + ' (local eateries, all days)</li>' +
      '<li><b>Getting around + activities</b> - ' + inr(est.local) + '</li>' +
      '<li><b>Contingency 10%</b> - ' + inr(est.contingency) + '</li>';
    $('#surpriseGetting').innerHTML = (function () {
      var hubName = (HUBS[citySel.value] || HUBS.delhi)[0];
      var link;
      if (est.mode === 'return flight') link = 'https://www.google.com/travel/flights?q=' + encodeURIComponent('flights from ' + hubName + ' to ' + d.name);
      else if (est.mode === 'bus or drive') link = 'https://www.google.com/maps/dir/' + encodeURIComponent(hubName) + '/' + encodeURIComponent(d.name);
      else link = 'https://www.irctc.co.in';
      return '<div class="modal-getting-row"><span>Travel allowance, ' + hubName + ' to ' + d.name +
        ': rough distance allowance ' + Math.round(est.km) + ' km each way by ' + est.mode + ' where a direct route exists - last-mile transfers not included</span>' +
        '<a class="fare fare-link" href="' + link + '" target="_blank" rel="noopener">check live fares &nearr;</a></div>';
    })();
    var plan = [];
    for (var day = 1; day <= Math.min(est.days, 5); day++) {
      var place = d.places[day - 1] || 'explore at your own pace';
      if (day === 1) plan.push('Day 1 - arrive, then ' + place);
      else if (day === Math.min(est.days, 5) && est.days > 1) plan.push('Day ' + day + ' - ' + place + (day === est.days ? ', head back' : ''));
      else plan.push('Day ' + day + ' - ' + place);
    }
    if (est.days > 5) plan.push('Days 6 - ' + est.days + ' - slower mornings, day trips nearby, head back');
    $('#surprisePlan').innerHTML = plan.map(function (p) { return '<li>' + p + '</li>'; }).join('');
    $('#surpriseEatStay').innerHTML =
      d.food.slice(0, 3).map(function (f) { return '<li><b>Eat</b> - ' + f.n + ' (' + f.note + ')</li>'; }).join('') +
      d.stays.slice(0, 2).map(function (s) { return '<li><b>Stay</b> - ' + s.n + ' (' + s.note + (s.r ? ', rated ' + s.r : '') + ')</li>'; }).join('');
    $('#surpriseCard').hidden = false;
  }

  var rollTimer = null;
  $('#surpriseBtn').addEventListener('click', function () {
    clearInterval(rollTimer);
    rollTimer = null;
    $('#surpriseRoll').textContent = '';
    var travelers = Math.min(10, Math.max(1, parseInt($('#surpriseTravelers').value, 10) || 2));
    var days = Math.min(14, Math.max(1, parseInt($('#surpriseDays').value, 10) || 4));
    var budget = Math.max(0, parseInt($('#surpriseBudget').value, 10) || 0);
    var res = surprisePool(travelers, days);
    $('#surpriseNone').hidden = true;
    $('#surpriseRecovery').hidden = true;
    $('#surpriseCard').hidden = true;
    if (!res.pool.length) {
      var mood = SURPRISE_VIBES.filter(function (p) { return p[0] === surprise.vibe; })[0];
      var area = SURPRISE_REGIONS.filter(function (p) { return p[0] === surprise.region; })[0];
      $('#surpriseNone').textContent = 'No destinations in this guide match ' + (mood ? mood[1] : 'this mood') + ' in ' + (area ? area[1] : 'this region') + '. Choose Any mood or Anywhere, or try a different mood or region. Your other choices have been kept.';
      $('#surpriseNone').hidden = false;
      $('#surpriseRecovery').hidden = false;
      return;
    }
    var hubKey = citySel.value;
    var feasible = res.pool.map(function (d) { return { d: d, est: estimateTrip(d, hubKey, travelers, days) }; })
      .filter(function (x) { return x.est && x.est.total <= budget; });
    if (!feasible.length) {
      var cheapest = res.pool.map(function (d) { return { d: d, est: estimateTrip(d, hubKey, travelers, days) }; })
        .filter(function(x) { return x.est; }).sort(function (a, b) { return a.est.total - b.est.total; })[0];
      if (!cheapest) { $('#surpriseNone').textContent = 'Planning estimate unavailable: destination coordinates have not been verified for these filters. Open a guide and check live travel options instead.'; $('#surpriseNone').hidden = false; return; }
      $('#surpriseNone').textContent = 'Nothing fits ' + inr(budget) + ' for ' + travelers + ' traveler' + (travelers > 1 ? 's' : '') + ' over ' + days + ' day' + (days > 1 ? 's' : '') + ' from ' + HUBS[hubKey][0] +
        ' - the cheapest match is ' + cheapest.d.name + ' at about ' + inr(cheapest.est.total) + ' (' + inr(cheapest.est.total - budget) + ' over). Raise the budget, shorten the trip, or loosen the filters.';
      $('#surpriseNone').hidden = false;
      return;
    }
    var roll = $('#surpriseRoll');
    var names = feasible.map(function (x) { return x.d.name; });
    var ticks = 0;
    clearInterval(rollTimer);
    rollTimer = setInterval(function () {
      roll.textContent = names[Math.floor(Math.random() * names.length)] + '\u2026';
      if (++ticks > 16) {
        clearInterval(rollTimer);
        var pick;
        do { pick = feasible[Math.floor(Math.random() * feasible.length)]; }
        while (feasible.length > 1 && surprise.pick && pick.d.id === surprise.pick.id);
        roll.textContent = '';
        revealSurprise(pick.d, pick.est, budget, res.seasonDropped);
        $('#surpriseCard').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }, 80);
  });
  $('#surpriseAnyMood').addEventListener('click', function () {
    var choice = $('#surpriseVibes').querySelector('button');
    choice.click();
    $('#surpriseBtn').click();
  });
  $('#surpriseAnywhere').addEventListener('click', function () {
    var choice = $('#surpriseRegions').querySelector('button');
    choice.click();
    $('#surpriseBtn').click();
  });
  $('#surpriseAgain').addEventListener('click', function () { $('#surpriseBtn').click(); });
  $('#surpriseOpen').addEventListener('click', function () { if (surprise.pick) openModal(surprise.pick); });

  /* ---------- grid ---------- */
  function inSeason(d) { return state.months.length === 0 || d.months.some(function (m) { return state.months.indexOf(m) !== -1; }); }
  function matches(d) {
    if (state.region !== 'all' && d.region !== state.region) return false;
    if (state.vibe !== 'all' && d.vibes.indexOf(state.vibe) === -1) return false;
    if (state.query) {
      var q = state.query.toLowerCase();
      return (d.name + ' ' + d.state + ' ' + d.blurb + ' ' + d.vibes.join(' ')).toLowerCase().indexOf(q) !== -1;
    }
    return true;
  }

  var grid = $('#grid'), resultCount = $('#resultCount'), emptyState = $('#emptyState');
  /* ---------- map (pins sit on city coordinates; outline is simplified) ---------- */
  var MAP_W = 600, MAP_H = 689;
  var MAP_XY = {"agra": [206.8, 226.7], "jaipur": [161.4, 231.2], "udaipur": [116.2, 282.9], "amritsar": [147.7, 122.3], "varanasi": [308.1, 270.8], "leh": [202.8, 67.4], "manali": [193.9, 110.3], "goa": [107.6, 493.2], "kerala": [156.4, 623.5], "mumbai": [90.4, 412.1], "darjeeling": [415.8, 229.0], "andaman": [528.8, 580.3], "jaisalmer": [62.1, 225.8], "rishikesh": [214.2, 159.3], "hampi": [165.3, 499.6], "shillong": [491.7, 259.3], "srinagar": [146, 66], "shimla": [194, 135], "tirupati": [240, 530], "bodhgaya": [352, 279], "ajmer": [143, 239], "haridwar": [213, 152], "delhi": [209, 192], "bengaluru": [186, 553], "kolkata": [406, 317], "puri": [353, 381], "hyderabad": [218, 432], "chennai": [256, 559], "mysuru": [169, 570], "madurai": [222, 624], "pune": [145, 362], "ahmedabad": [100, 259], "lucknow": [272, 220], "bhopal": [205, 295], "indore": [178, 315], "gwalior": [225, 230], "orchha": [237, 248], "khajuraho": [259, 259]};
  var mapSel = null;
  function xyFor(d) {
    return MAP_XY[d.id] || MAP_XY[String(d.name || '').toLowerCase().split(/[ &,]/)[0]] || null;
  }
  function setSel(id) {
    mapSel = id;
    Array.prototype.forEach.call(document.querySelectorAll('#mapMarkers .marker'), function (m) { m.classList.toggle('is-sel', m.getAttribute('data-id') === id); });
    Array.prototype.forEach.call(grid.children, function (c) { if (c.classList) c.classList.toggle('is-sel', c.getAttribute('data-id') === id); });
  }
  function hoverId(id, on) {
    Array.prototype.forEach.call(document.querySelectorAll('#mapMarkers .marker'), function (m) { if (m.getAttribute('data-id') === id) m.classList.toggle('is-hover', on); });
  }
  var mapPop = $('#mapPop');
  function hidePop() { mapPop.hidden = true; }
  function pickOnMap(d) {
    var xy = xyFor(d);
    setSel(d.id);
    if (!xy) return;
    $('#mapPopName').textContent = d.name;
    $('#mapPopMeta').textContent = d.state + ' - best ' + d.best;
    var sv = document.getElementById('indiaSvg').getBoundingClientRect(), wr = document.getElementById('mapWrap').getBoundingClientRect();
    var px = (sv.left - wr.left) + xy[0] / MAP_W * sv.width, py = (sv.top - wr.top) + xy[1] / MAP_H * sv.height;
    px = Math.max(80, Math.min(wr.width - 80, px));
    mapPop.style.left = px + 'px';
    mapPop.style.top = py + 'px';
    mapPop.hidden = false;
    mapPop.onclick = null;
    $('#mapPopOpen').onclick = function () { hidePop(); openModal(d); };
    var card = grid.querySelector('[data-id="' + d.id + '"]');
    var lp = document.querySelector('.list-pane');
    if (card && lp) { try { lp.scrollTo({ top: Math.max(0, card.offsetTop - 8), behavior: 'smooth' }); } catch (err) { lp.scrollTop = Math.max(0, card.offsetTop - 8); } }
  }
  window.addEventListener('resize', function () { renderMarkers(); });
  $('#mapPopClose').addEventListener('click', function () { hidePop(); setSel(null); });
  function renderMarkers() {
    var g = document.getElementById('mapMarkers');
    if (!g) return;
    var NS = 'http://www.w3.org/2000/svg';
    g.innerHTML = '';
    var popOk = false;
    DESTINATIONS.forEach(function (d, i) {
      var xy = xyFor(d);
      if (!xy || !matches(d)) return;
      if (d.id === mapSel) popOk = true;
      var m = document.createElementNS(NS, 'g');
      m.setAttribute('class', 'marker' + (inSeason(d) ? '' : ' is-off') + (mapSel === d.id ? ' is-sel' : ''));
      m.setAttribute('transform', 'translate(' + xy[0] + ' ' + xy[1] + ') scale(' + (window.innerWidth < 700 ? 1.55 : 1) + ')');
      m.setAttribute('data-id', d.id);
      m.setAttribute('tabindex', '0');
      m.setAttribute('role', 'button');
      m.setAttribute('aria-label', d.name + ', ' + d.state + ' - show on list');
      m.innerHTML = '<circle class="m-hit" r="17"></circle><circle class="m-dot" r="10.5"></circle><text class="m-num" text-anchor="middle" dy="3.8">' + (i + 1) + '</text>';
      m.addEventListener('click', function () { pickOnMap(d); });
      m.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pickOnMap(d); } });
      m.addEventListener('mouseenter', function () { Array.prototype.forEach.call(grid.children, function (c) { if (c.getAttribute && c.getAttribute('data-id') === d.id) c.classList.add('is-hover'); }); });
      m.addEventListener('mouseleave', function () { Array.prototype.forEach.call(grid.children, function (c) { if (c.classList) c.classList.remove('is-hover'); }); });
      g.appendChild(m);
    });
    if (!popOk) hidePop();
  }

  function renderGrid() {
    grid.innerHTML = '';
    var shown = 0;
    DESTINATIONS.forEach(function (d, i) {
      if (!matches(d)) return;
      shown++;
      var card = document.createElement('div');
      card.className = 'card reveal' + (inSeason(d) ? '' : ' is-offseason') + (mapSel === d.id ? ' is-sel' : '');
      card.setAttribute('role', 'button');
      card.setAttribute('tabindex', '0');
      card.setAttribute('data-id', d.id);
      card.setAttribute('aria-label', d.name + ', ' + d.state + ' - open guide');
      card.innerHTML =
        '<div class="card-media"><img src="' + photoUrl(d.photo) + '" alt="' + d.alt + '" loading="lazy">' +
        '<span class="card-num">' + (i + 1) + '</span></div>' +
        '<div class="card-body">' +
        '<p class="card-state">' + d.state + '</p>' +
        '<h3 class="card-name">' + d.name + '</h3>' +
        '<p class="card-blurb">' + d.blurb + '</p>' +
        '<div class="card-meta">' +
        '<span class="card-best">Best: ' + d.best + '</span>' +
        d.vibes.map(function (v) { return '<span class="card-tag">' + (v === 'spiritual' ? 'Religious' : v) + '</span>'; }).join('') +
        '</div>' +
        (xyFor(d) ? '<button class="card-pin" type="button">Show on map</button>' : '') +
        '</div>';
      card.addEventListener('click', function () { openModal(d); });
      card.addEventListener('keydown', function (e) { if (e.target === card && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); openModal(d); } });
      card.addEventListener('mouseenter', function () { hoverId(d.id, true); });
      card.addEventListener('mouseleave', function () { hoverId(d.id, false); });
      var pin = card.querySelector('.card-pin');
      if (pin) pin.addEventListener('click', function (e) {
        e.stopPropagation();
        pickOnMap(d);
      });
      grid.appendChild(card);
      requestAnimationFrame(function () { card.classList.add('is-visible'); });
    });
    resultCount.textContent = shown + ' of ' + DESTINATIONS.length + ' destinations';
    emptyState.hidden = shown !== 0;
    renderMarkers();
  }

  /* ---------- search ---------- */
  $('#searchInput').addEventListener('input', function (e) {
    state.query = e.target.value.trim();
    renderGrid();
    if (state.query) $('#destinations').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  /* ---------- fare table (dated live quotes) ---------- */
  var fareBody = $('#fareBody');
  fareBody.innerHTML = FARES.map(function (f) {
    return '<tr><td>' + f.route + '</td><td>' + f.fare + '</td></tr>';
  }).join('');

  /* ---------- destination detail (in-flow, works in any embed) ---------- */
  var detail = $('#detail');
  var browseBits = ['#seasons', '.filter-bar', '#explorer', '#grid', '#resultCount', '#emptyState', '#flights', '#about'];
  function openModal(d) {
    $('#modalImg').src = photoUrl(d.photo);
    $('#modalImg').alt = d.alt;
    $('#modalState').textContent = d.state;
    $('#modalTitle').textContent = d.name;
    $('#modalBlurb').textContent = d.blurb;
    var oldCredit = document.getElementById('destinationCredit'); if (oldCredit) oldCredit.remove();
    if (d.credit) { var credit = document.createElement('p'); credit.id='destinationCredit'; credit.className='tp-note'; credit.textContent='Photo: '+d.credit+'. Display crop may differ from the original.'; var sources={delhi:['India_Gate_in_New_Delhi_03-2016.jpg','https://artlibre.org/licence/lal/en/'],bengaluru:['Vidhana_Soudha_Bangalore.jpg','https://creativecommons.org/licenses/by-sa/4.0/'],kolkata:['Victoria-Memorial-Kolkata-India.jpg','https://creativecommons.org/licenses/by-sa/4.0/'],puri:['Puri_Jagannath_Temple_Entrance.jpg','https://creativecommons.org/licenses/by/4.0/'],hyderabad:["Charminar_Aerial_View.jpg", "https://creativecommons.org/licenses/by-sa/4.0/"],chennai:["MylaporeKapaleeshwararTemple.jpg", "https://creativecommons.org/licenses/by-sa/2.0/"],mysuru:["Mysore_palace%2C_karnataka.jpg", "https://creativecommons.org/licenses/by-sa/4.0/"],madurai:["Madurai%2C_India.jpg", "https://creativecommons.org/licenses/by-sa/3.0/"],pune:["Shaniwar_Wada%2C_Pune%2C_Mumbai%2C_India.jpg", "https://creativecommons.org/licenses/by-sa/4.0/"],ahmedabad:["Sabarmati_Ashram.jpg", "https://creativecommons.org/publicdomain/mark/1.0/"],lucknow:["Rumi_Darwaja_(Rumi_Gate).jpg", "https://creativecommons.org/licenses/by-sa/4.0/"],bhopal:["Bhopal%2C_Moti_Masjid_(9840931024).jpg", "https://creativecommons.org/licenses/by/2.0/"],indore:["Rajwada_Palace%2C_Indore.jpg", "https://creativecommons.org/licenses/by-sa/3.0/"],gwalior:["Gwalior_Fort_front.jpg", "https://creativecommons.org/licenses/by-sa/4.0/"],orchha:["Chhatris-Cenotaphs_on_the_bank_of_Betwa_River%2COrcha%2C_Madhya_Pradesh.jpg", "https://creativecommons.org/licenses/by-sa/4.0/"],khajuraho:["Temple_at_Khajuraho%2C_Madhya_Pradesh%2C_India.jpg", "https://creativecommons.org/licenses/by/2.0/"]}; if(sources[d.id]) { [['Original photo','https://commons.wikimedia.org/wiki/File:'+sources[d.id][0]],['License',sources[d.id][1]]].forEach(function(item){var a=document.createElement('a');a.textContent=item[0];a.href=item[1];a.target='_blank';a.rel='noopener noreferrer';credit.appendChild(document.createTextNode(' · '));credit.appendChild(a);}); } $('#modalBlurb').after(credit); }
    $('#modalFacts').innerHTML =
      fact('Best months', d.best) +
      fact('Festival', d.festival.name + ' - ' + d.festival.when) +
      fact('Ideal stay', d.ideal) +
      fact('Stays', 'varies widely - <a class="stay-link" href="https://www.google.com/travel/hotels?q=' + encodeURIComponent(d.name + ' hotels') + '" target="_blank" rel="noopener">check live hotel prices</a>');
    $('#modalPlaces').innerHTML = d.places.map(function (p) { return '<li>' + p + '</li>'; }).join('');
    var DIET_LABEL = { veg: 'Veg', nonveg: 'Non-veg', vegan: 'Vegan', both: 'Veg & non-veg' };
    $('#modalFood').innerHTML = d.food.map(function (f) {
      return '<div class="food-row"><div><b>' + f.n + '</b><span class="food-note">' + f.note + '</span></div>' +
        '<span class="diet diet-' + f.diet + '">' + DIET_LABEL[f.diet] + '</span></div>';
    }).join('');
    function placeRow(p) {
      var ta = p.ta ? '<span class="ta">Tripadvisor ' + p.ta + ' / 5</span>' : '';
      return '<a class="place-row" href="' + p.url + '" target="_blank" rel="noopener">' +
        '<span class="place-main"><b>' + p.n + '</b><span class="food-note">' + p.note + '</span></span>' +
        (p.r ? '<span class="rating">' + p.r + ta + '</span>' : '') + '</a>';
    }
    $('#modalEats').innerHTML = d.eats.map(placeRow).join('');
    $('#modalStays').innerHTML = d.stays.map(placeRow).join('');
    $('#modalShops').innerHTML = d.shops.map(function (s) { return '<li><b>' + s.n + '</b> - ' + s.note + '</li>'; }).join('');
    tpCurrentDest = d;
    $('#modalTransport').innerHTML = renderTransport(d);
    $('#modalGetting').innerHTML = d.getting.map(function (g) {
      var fare = g.url
        ? '<a class="fare fare-link" href="' + g.url + '" target="_blank" rel="noopener">' + g.fare + ' &nearr;</a>'
        : '<span class="fare">' + g.fare + '</span>';
      return '<div class="modal-getting-row"><span>' + g.text +
        (g.source ? '<span class="src">' + g.source + '</span>' : '') +
        '</span>' + fare + '</div>';
    }).join('');
    browseBits.forEach(function (s) { var el = document.querySelector(s); if (el) el.hidden = true; });
    document.querySelector('#destinations .section-eyebrow').hidden = true;
    document.querySelector('#destinations .section-title').hidden = true;
    detail.hidden = false;
    detail.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
    var tpBox = $('#modalTransport');
    if (tpBox) tpBox.addEventListener('change', function (e) {
      if (e.target && e.target.id === 'tpFrom' && tpCurrentDest) tpBox.innerHTML = renderTransport(tpCurrentDest, e.target.value);
    });
  function fact(k, v) { return '<div class="modal-fact"><b>' + k + '</b><span>' + v + '</span></div>'; }
  function closeModal() {
    detail.hidden = true;
    browseBits.forEach(function (s) { var el = document.querySelector(s); if (el) el.hidden = false; });
    document.querySelector('#destinations .section-eyebrow').hidden = false;
    document.querySelector('#destinations .section-title').hidden = false;
    $('#explorer').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  $('#detailBack').addEventListener('click', closeModal);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !detail.hidden) closeModal(); });

  /* ---------- source downloads (hosted view provides the globals) ---------- */
  var src = window.__SAFARNAMA_SOURCE__;
  var sourceButtons = $('#sourceButtons'), sourceNote = $('#sourceNote');
  if (src) {
    var files = { html: ['index.html', src.html], css: ['styles.css', src.css], js: ['app.js', src.js] };
    sourceButtons.addEventListener('click', function (e) {
      var key = e.target.dataset && e.target.dataset.source;
      if (!key) return;
      var blob = new Blob([files[key][1]], { type: 'text/plain' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = files[key][0];
      a.click();
      URL.revokeObjectURL(a.href);
    });
  } else {
    sourceButtons.hidden = true;
    sourceNote.hidden = false;
  }

  /* ---------- demo login (front-end only, device-local) ---------- */
  var LOGIN_KEY = 'safarnama_demo_user';
  var loginBtn = $('#loginBtn'), loginSection = $('#loginSection'), loginForm = $('#loginForm'),
      loginEmail = $('#loginEmail'), loginPassword = $('#loginPassword'), loginName = $('#loginName'),
      loginNameRow = $('#loginNameRow'), loginSubmit = $('#loginSubmit'), loginModeToggle = $('#loginModeToggle'),
      loginStatus = $('#loginStatus'), loginPwHint = $('#loginPwHint'),
      loginFormView = $('#loginFormView'), loginDoneView = $('#loginDoneView'), loginHello = $('#loginHello'),
      loginDoneNote = $('#loginDoneNote');
  var SUPABASE_URL = 'https://bfwnczsysyayubbvfjbk.supabase.co';
  var SUPABASE_CALLBACK_URL = 'https://safarnama-backend-3a61.onrender.com/auth/callback';
  var SUPABASE_ANON_KEY = 'sb_publishable__-MsZfTjHMavBhNfxTcFlA_l_Dm7pHS';
  var authSession = null; // { token, refreshToken, email, uid, name }
  // Persistence: top-level hosting (Render) keeps the session in localStorage so sign-in
  // survives reloads; the hosted Instinct viewer runs sandboxed and stays memory-only.
  var SESSION_KEY = 'safarnama_session';
  function persistSession(s) {
    if (inHostedViewer) return;
    try { localStorage.setItem(SESSION_KEY, JSON.stringify({ token: s.token, refreshToken: s.refreshToken || '', email: s.email, uid: s.uid, name: s.name })); } catch (e) {}
  }
  function clearSession() { try { localStorage.removeItem(SESSION_KEY); } catch (e) {} }
  var authMode = 'login';
  function sbAuth(path, body, token) {
    var headers = { 'apikey': SUPABASE_ANON_KEY, 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = 'Bearer ' + token;
    return fetch(SUPABASE_URL + path, { method: 'POST', headers: headers, body: body ? JSON.stringify(body) : undefined })
      .then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (data) {
          if (!res.ok) {
            var msg = data.error_description || data.msg || data.message || ('Sign-in error ' + res.status);
            throw new Error(msg);
          }
          return data;
        });
      });
  }
  function nameKey(email) { return 'safarnama_name_' + email; }
  function savedName(email) {
    try { return localStorage.getItem(nameKey(email)) || ''; } catch (e) { return ''; }
  }
  function storeName(email, name) {
    if (!name) return;
    try { localStorage.setItem(nameKey(email), name); } catch (e) {}
  }
  function setStatus(msg, isErr) {
    loginStatus.textContent = msg || '';
    loginStatus.classList.toggle('err', !!isErr);
  }
  function setMode(mode) {
    authMode = mode;
    loginNameRow.hidden = mode === 'login';
    loginPwHint.textContent = mode === 'signup' ? '(min 6 characters)' : '';
    loginSubmit.textContent = mode === 'login' ? 'Log in' : 'Create account';
    loginModeToggle.textContent = mode === 'login' ? 'New here? Create an account' : 'Have an account? Log in';
    setStatus('');
  }
  var navUser = $('#navUser'), googleLoginBtn = $('#googleLoginBtn');
  var profileView = $('#profileView'), profileForm = $('#profileForm');
  var profileName = $('#profileName'), profileMobile = $('#profileMobile'), profileStatus = $('#profileStatus');
  function paintLogin() {
    loginBtn.textContent = authSession ? 'Log out' : 'Log in';
    loginBtn.classList.toggle('is-logged-in', !!authSession);
    navUser.hidden = !authSession;
    navUser.textContent = authSession ? ('Namaste, ' + authSession.name) : '';
  }
  function sbUser(token) {
    return fetch(SUPABASE_URL + '/auth/v1/user', { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + token } })
      .then(function (r) { return r.ok ? r.json() : null; });
  }
  function sbProfileGet(token, uid) {
    return fetch(SUPABASE_URL + '/rest/v1/profiles?id=eq.' + uid + '&select=name,mobile', { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + token } })
      .then(function (r) { return r.ok ? r.json() : []; }).catch(function () { return []; });
  }
  function sbProfileSave(token, uid, name, mobile) {
    return fetch(SUPABASE_URL + '/rest/v1/profiles', {
      method: 'POST',
      headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json', 'Prefer': 'resolution=merge-duplicates' },
      body: JSON.stringify({ id: uid, name: name, mobile: mobile })
    }).then(function (r) { if (!r.ok) throw new Error('save failed'); });
  }
  function afterLogin(session, opts) {
    authSession = session;
    persistSession(session);
    paintLogin();
    var silent = opts && opts.silent;
    sbProfileGet(session.token, session.uid).then(function (rows) {
      var p = rows && rows[0];
      if (p && p.name) {
        authSession.name = p.name;
        storeName(session.email, p.name);
        persistSession(authSession);
        paintLogin();
        if (!silent) openLogin();
      } else {
        if (silent) return;
        loginFormView.hidden = true;
        loginDoneView.hidden = true;
        profileView.hidden = false;
        profileName.value = session.name || '';
        loginSection.hidden = false;
        loginSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  }
  function restoreSession() {
    if (inHostedViewer) return;
    var raw;
    try { raw = localStorage.getItem(SESSION_KEY); } catch (e) { return; }
    if (!raw) return;
    var s;
    try { s = JSON.parse(raw); } catch (e) { return; }
    if (!s || !s.token) { clearSession(); return; }
    sbUser(s.token).then(function (user) {
      if (user && user.id) { afterLogin(s, { silent: true }); return; }
      if (s.refreshToken) {
        sbAuth('/auth/v1/token?grant_type=refresh_token', { refresh_token: s.refreshToken }).then(function (data) {
          if (data && data.access_token) {
            afterLogin({ token: data.access_token, refreshToken: data.refresh_token || s.refreshToken, email: s.email, uid: (data.user && data.user.id) || s.uid, name: s.name }, { silent: true });
          } else clearSession();
        }).catch(function () { clearSession(); });
      } else clearSession();
    }).catch(function () { /* offline or hiccup - keep the stored session for next load */ });
  }
  profileForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var name = profileName.value.trim(), mobile = profileMobile.value.trim();
    if (!name || !mobile || !authSession) return;
    profileSave.disabled = true;
    profileStatus.textContent = '';
    sbProfileSave(authSession.token, authSession.uid, name, mobile).then(function () {
      authSession.name = name;
      storeName(authSession.email, name);
      paintLogin();
      profileView.hidden = true;
      openLogin();
    }).catch(function () {
      profileStatus.textContent = 'Could not save right now - try again.';
    }).finally(function () { profileSave.disabled = false; });
  });
  var profileSave = $('#profileSave');
  // Google OAuth (PKCE): verifier + state live in memory only - the site viewer blocks saved
  // storage, and a popup round-trip must not depend on it. The popup returns to this same page
  // with ?code&state (PKCE) or #access_token&state (implicit fallback) and posts them to the
  // opener; the opener validates message origin, source window and state before using anything.
  var oauthPopup = null, oauthState = null, oauthVerifier = null, oauthHelloTimer = null;
  // Redirect-flow storage (top-level hosting only): state + PKCE verifier stay in local
  // storage, never in a URL or postMessage. On return the state is validated against the
  // stored value before the code is exchanged; anything unmatched is ignored.
  var OAUTH_KEY = 'safarnama_oauth';
  function storeOAuth(o) { try { localStorage.setItem(OAUTH_KEY, JSON.stringify(o)); } catch (e) {} }
  function readStoredOAuth() { try { var r = localStorage.getItem(OAUTH_KEY); return r ? JSON.parse(r) : null; } catch (e) { return null; } }
  function clearStoredOAuth() { try { localStorage.removeItem(OAUTH_KEY); } catch (e) {} }
  function isIOSWeb() {
    return /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  }
  function pkceRandom() {
    var a = new Uint8Array(32);
    crypto.getRandomValues(a);
    return btoa(String.fromCharCode.apply(null, Array.prototype.slice.call(a))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function pkceChallenge(verifier) {
    return crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier)).then(function (buf) {
      return btoa(String.fromCharCode.apply(null, Array.prototype.slice.call(new Uint8Array(buf)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    });
  }
  // Inside the hosted Instinct viewer the page runs in a sandboxed frame whose
  // popups are severed (no window.opener), so the Google round-trip can never
  // return to this page. Disable the button there with an honest note; on normal
  // hosting (top-level tab) the full popup flow works.
  var inHostedViewer = false;
  try { inHostedViewer = window.self !== window.top; } catch (e) { inHostedViewer = true; }
  if (inHostedViewer) {
    googleLoginBtn.disabled = true;
    googleLoginBtn.style.opacity = '0.55';
    googleLoginBtn.style.cursor = 'default';
    var gnote = document.createElement('p');
    gnote.className = 'login-note';
    gnote.textContent = 'Google sign-in is not available inside this hosted page - the sign-in window is not allowed to talk back to the site here. Email login below works. Google sign-in needs separate hosting and is not verified there yet.';
    googleLoginBtn.parentNode.insertBefore(gnote, googleLoginBtn.nextSibling);
  }
  googleLoginBtn.addEventListener('click', function () {
    if (googleLoginBtn.disabled) return;
    if (!crypto || !crypto.getRandomValues || !crypto.subtle) { setStatus('Google sign-in is not available in this browser - try updating it.', true); return; }
    oauthState = pkceRandom();
    oauthVerifier = pkceRandom();
    pkceChallenge(oauthVerifier).then(function (challenge) {
      var redirectTo = SUPABASE_CALLBACK_URL + (SUPABASE_CALLBACK_URL.indexOf('?') < 0 ? '?' : '&') + 'state=' + encodeURIComponent(oauthState);
      var url = SUPABASE_URL + '/auth/v1/authorize?provider=google'
        + '&redirect_to=' + encodeURIComponent(redirectTo)
        + '&flow_type=pkce'
        + '&code_challenge=' + encodeURIComponent(challenge)
        + '&code_challenge_method=s256'
        + '&state=' + encodeURIComponent(oauthState);
      storeOAuth({ state: oauthState, verifier: oauthVerifier, ts: Date.now() });
      // iOS browsers and in-app web views (WhatsApp etc.) lose window.opener through the
      // Google round-trip, so the popup flow can never report back there - redirect instead.
      if (isIOSWeb()) { location.href = url; return; }
      oauthPopup = window.open(url, 'safarnama_google', 'width=520,height=640');
      if (!oauthPopup) { location.href = url; return; }
      clearInterval(oauthHelloTimer);
      oauthHelloTimer = setInterval(function () {
        if (!oauthPopup || oauthPopup.closed) { clearInterval(oauthHelloTimer); oauthHelloTimer = null; return; }
        try { oauthPopup.postMessage({ type: 'safarnama-auth-hello' }, 'https://safarnama-backend-3a61.onrender.com'); } catch (err) {}
      }, 300);
    }).catch(function () { setStatus('Google sign-in is not available in this browser - try updating it.', true); });
  });
  function handleOAuthCallback() {
    var sp = {};
    location.search.replace(/^\?/, '').split('&').forEach(function (kv) { var p = kv.split('='); if (p[0]) sp[p[0]] = decodeURIComponent(p[1] || ''); });
    var hp = {};
    location.hash.replace(/^#/, '').split('&').forEach(function (kv) { var p = kv.split('='); if (p[0]) hp[p[0]] = decodeURIComponent(p[1] || ''); });
    var payload = null;
    if (sp.code && sp.state) payload = { type: 'safarnama-auth', code: sp.code, state: sp.state };
    else if (hp.access_token && hp.state) payload = { type: 'safarnama-auth', token: hp.access_token, refresh_token: hp.refresh_token || '', state: hp.state };
    if (!payload) return;
    try { history.replaceState(null, '', location.pathname + location.search.replace(/([?&])(code|state|error|error_description)=[^&]*/g, '$1').replace(/[?&]$/, '')); } catch (e) {}
    if (window.opener) {
      try { window.opener.postMessage(payload, location.origin); } catch (e) {}
      window.close();
      return;
    }
    // Redirect-flow return (iOS / popup-blocked): only proceed when the returned state
    // matches one this page stored locally - unsolicited codes are ignored.
    var stored = readStoredOAuth();
    // one-time, 15-minute-expiring binding to the initiation on this device
    if (!stored || payload.state !== stored.state || (stored.ts && Date.now() - stored.ts > 15 * 60 * 1000)) {
      if (stored) clearStoredOAuth();
      return;
    }
    clearStoredOAuth();
    if (payload.code && stored.verifier) {
      sbAuth('/auth/v1/token?grant_type=pkce', { auth_code: payload.code, code_verifier: stored.verifier }).then(function (data) {
        if (data && data.access_token) finishOAuth(data.access_token, data.refresh_token);
        else setStatus('Google sign-in did not complete - try again.', true);
      }).catch(function (err) { setStatus(err && err.message ? err.message : 'Google sign-in failed - try again.', true); });
    } else if (payload.token) {
      finishOAuth(payload.token, payload.refresh_token);
    }
  }
  function finishOAuth(token, refreshToken) {
    sbUser(token).then(function (user) {
      if (!user || !user.id) { setStatus('Google sign-in did not complete - try again.', true); return; }
      var meta = user.user_metadata || {};
      var name = meta.full_name || meta.name || (user.email || '').split('@')[0];
      afterLogin({ token: token, refreshToken: refreshToken || '', email: user.email || '', uid: user.id, name: name });
    }).catch(function () { setStatus('Google sign-in did not complete - try again.', true); });
  }
  window.addEventListener('message', function (e) {
    if ((e.origin !== location.origin && e.origin !== SUPABASE_URL && e.origin !== 'https://safarnama-backend-3a61.onrender.com') || !e.data || e.data.type !== 'safarnama-auth') return;
    if (!oauthPopup || e.source !== oauthPopup) return;
    if (!oauthState || e.data.state !== oauthState) return;
    clearInterval(oauthHelloTimer); oauthHelloTimer = null;
    var code = e.data.code || '', token = e.data.token || '', verifier = oauthVerifier;
    oauthPopup = null; oauthState = null; oauthVerifier = null;
    if (code && verifier) {
      sbAuth('/auth/v1/token?grant_type=pkce', { auth_code: code, code_verifier: verifier }).then(function (data) {
        if (data && data.access_token) finishOAuth(data.access_token, data.refresh_token);
        else setStatus('Google sign-in did not complete - try again.', true);
      }).catch(function (err) { setStatus(err && err.message ? err.message : 'Google sign-in failed - try again.', true); });
    } else if (token) {
      finishOAuth(token, e.data.refresh_token);
    } else {
      setStatus('Google sign-in did not complete - try again.', true);
    }
  });
  handleOAuthCallback();
  function openLogin() {
    profileView.hidden = true;
    loginFormView.hidden = !!authSession;
    loginDoneView.hidden = !authSession;
    if (!authSession) { setMode('login'); showSignupNote(); }
    if (authSession) {
      loginHello.textContent = 'Namaste, ' + authSession.name + '!';
      loginDoneNote.textContent = 'Signed in as ' + authSession.email + ' - your email was confirmed by the auth service. ' + (inHostedViewer ? 'Sign-in lasts while this page is open.' : 'You stay signed in on this device until you log out.');
    }
    loginSection.hidden = false;
    loginSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  function closeLogin() { loginSection.hidden = true; }
  loginBtn.addEventListener('click', openLogin);
  $('#loginClose').addEventListener('click', closeLogin);
  loginModeToggle.hidden = true;
  function showSignupNote() {
    if (!authSession) setStatus('New here? Only existing confirmed email accounts can log in below for now.');
  }
  function doAuth() {
    setStatus('');
    var email = loginEmail.value.trim();
    var password = loginPassword.value;
    if (!email || !password) return;
    loginSubmit.disabled = true;
    if (authMode === 'signup') {
      var name = loginName.value.trim();
      loginSubmit.textContent = 'Creating...';
      sbAuth('/auth/v1/signup', { email: email, password: password, data: { name: name } })
        .then(function (data) {
          storeName(email, name);
          if (data.access_token) {
            afterLogin({ token: data.access_token, refreshToken: data.refresh_token || '', email: email, uid: data.user && data.user.id, name: name || email.split('@')[0] });
          } else {
            setMode('login');
            loginPassword.value = '';
            setStatus('Account created. Open the confirmation email we sent to ' + email + ', tap the link, then log in here.');
          }
        })
        .catch(function (err) {
          setStatus(err.message || 'Could not create the account. Try again.', true);
          loginSubmit.textContent = 'Create account';
        })
        .finally(function () { loginSubmit.disabled = false; });
    } else {
      loginSubmit.textContent = 'Logging in...';
      sbAuth('/auth/v1/token?grant_type=password', { email: email, password: password })
        .then(function (data) {
          var meta = (data.user && data.user.user_metadata) || {};
          var name = meta.name || savedName(email) || email.split('@')[0];
          loginPassword.value = '';
          afterLogin({ token: data.access_token, refreshToken: data.refresh_token || '', email: email, uid: data.user && data.user.id, name: name });
        })
        .catch(function (err) {
          var msg = err.message || '';
          if (/email not confirmed/i.test(msg)) msg = 'Confirm your email first - open the link we sent to ' + email + '.';
          else if (/invalid/i.test(msg)) msg = 'Wrong email or password.';
          setStatus(msg || 'Could not log in. Try again.', true);
          loginSubmit.textContent = 'Log in';
        })
        .finally(function () { loginSubmit.disabled = false; });
    }
  }
  loginForm.addEventListener('submit', function (e) { e.preventDefault(); doAuth(); });
  loginSubmit.addEventListener('click', function (e) { e.preventDefault(); doAuth(); });
  $('#logoutBtn').addEventListener('click', function () {
    var s = authSession;
    authSession = null;
    clearSession();
    paintLogin();
    openLogin();
    if (s) sbAuth('/auth/v1/logout', null, s.token).catch(function () {});
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !loginSection.hidden) closeLogin(); });
  setMode('login');
  paintLogin();
  restoreSession();



  /* ---------- Photo discovery (Gemini free tier via Render proxy) ---------- */
  var photoInput = $('#photoInput'), photoPickBtn = $('#photoPickBtn'), photoStatus = $('#photoStatus'),
      photoPreviewWrap = $('#photoPreviewWrap'), photoPreview = $('#photoPreview'), photoResult = $('#photoResult');
  var PHOTO_API = location.hostname === 'safarnama-backend-3a61.onrender.com' ? '/api/photo' : 'https://safarnama-backend-3a61.onrender.com/api/photo';
  function photoSay(msg) { photoStatus.textContent = msg || ''; }
  function shrinkPhoto(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(url);
        var max = 1400, w = img.naturalWidth, h = img.naturalHeight;
        if (Math.max(w, h) > max) { var k = max / Math.max(w, h); w = Math.round(w * k); h = Math.round(h * k); }
        var c = document.createElement('canvas');
        c.width = w; c.height = h;
        c.getContext('2d').drawImage(img, 0, 0, w, h);
        resolve(c.toDataURL('image/jpeg', 0.82));
      };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('bad image')); };
      img.src = url;
    });
  }
  function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
  function showPhotoGuess(g) {
    if (!g || !g.place) {
      photoResult.innerHTML = '<h3>No clear match</h3><p class="photo-meta">' + esc((g && g.reason) || 'The photo did not look like a recognisable place in India.') + '</p>';
      photoResult.hidden = false;
      return;
    }
    var cost = g.estimated_trip_cost_inr || {};
    var match = DESTINATIONS.find(function (d) { return d.name.toLowerCase() === String(g.place).toLowerCase() || String(g.place).toLowerCase().indexOf(d.name.toLowerCase()) !== -1 || d.name.toLowerCase().indexOf(String(g.place).toLowerCase()) !== -1; });
    photoResult.innerHTML =
      '<h3>' + esc(g.place) + (g.state ? ', ' + esc(g.state) : '') + '</h3>' +
      '<p class="photo-meta">AI guess - confidence: ' + esc(g.confidence || 'unknown') + '. Not verified.</p>' +
      (g.why ? '<p>' + esc(g.why) + '</p>' : '') +
      (g.best_season ? '<p><b>Best season:</b> ' + esc(g.best_season) + '</p>' : '') +
      ((cost.budget || cost.comfort) ? '<p><b>Rough 3-day cost per person:</b> ' + (cost.budget ? 'budget \u20b9' + esc(cost.budget) : '') + (cost.budget && cost.comfort ? ' - ' : '') + (cost.comfort ? 'comfort \u20b9' + esc(cost.comfort) : '') + ' (estimates in INR, not live prices)</p>' : '') +
      (match ? '<p><button class="btn btn-ghost" id="photoOpenDest" type="button">Open the ' + esc(match.name) + ' guide</button></p>' : '');
    photoResult.hidden = false;
    var btn = $('#photoOpenDest');
    if (btn && match) btn.addEventListener('click', function () { openModal(match); });
  }
  if (photoPickBtn && photoInput && inHostedViewer) {
    photoPickBtn.disabled = true;
    photoPickBtn.style.opacity = '0.55';
    photoPickBtn.style.cursor = 'default';
    photoSay('Photo discovery needs the full hosted site - open it at https://safarnama-backend-3a61.onrender.com (your photo goes to Google only from there).');
  }
  if (photoPickBtn && photoInput && !inHostedViewer) {
    photoPickBtn.addEventListener('click', function () { photoInput.click(); });
    photoInput.addEventListener('change', function () {
      var f = photoInput.files && photoInput.files[0];
      if (!f) return;
      if (!/^image\/(jpeg|png|webp)$/.test(f.type)) { photoSay('Please choose a JPEG, PNG or WebP photo.'); return; }
      photoResult.hidden = true;
      photoSay('Reading photo...');
      shrinkPhoto(f).then(function (dataUrl) {
        photoPreview.src = dataUrl;
        photoPreviewWrap.hidden = false;
        photoSay('Asking the AI - this can take a few seconds...');
        var base64 = dataUrl.split(',')[1];
        return fetch(PHOTO_API, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ image: base64, mimeType: 'image/jpeg' })
        });
      }).then(function (r) {
        return r.json().then(function (data) {
          if (!r.ok) {
            if (data && data.error === 'rate_limited') photoSay('Too many tries this hour - please try again later.');
            else if (data && data.error === 'photo_ai_unconfigured') photoSay('Photo discovery is not set up on the server yet.');
            else photoSay('The AI could not read that photo - try another one.');
            return null;
          }
          return data.guess;
        });
      }).then(function (guess) {
        if (!guess) return;
        photoSay('');
        showPhotoGuess(guess);
      }).catch(function () {
        photoSay('Could not reach the photo service - check your connection and try again.');
      }).finally(function () {
        photoInput.value = '';
      });
    });
  }

  /* ---------- FAQ (English + India's 22 Scheduled Languages) ---------- */
  /* Non-English text is AI-assisted and not professionally verified; English is the reference. */
  var FAQ_I18N = {
  en: { label: 'English', dir: 'ltr', langLabel: 'Language',
    title: 'Questions, answered',
    note: 'Read this FAQ in English or any of India\'s 22 Scheduled Languages (the Eighth Schedule of the Constitution - India speaks many more). Non-English translations are AI-assisted and not professionally verified; the English text is the reference. Santali and Manipuri are shown in English while their translations are finalized - 21 languages translated, 2 shown in English for now.',
    items: [
      ['Can I book flights, hotels or restaurants on Safarnama?', 'No. Safarnama is a front-end travel concept - a demo. Nothing here books, reserves or charges anything. Restaurant and stay names link out to their live listings so you can check them yourself.'],
      ['Are the flight fares on this site live?', 'No. They are dated examples from a real booking search (Duffel), pulled on 30 Oct 2026 for one-way economy flights on 28 Nov 2026, shown in USD as returned. Prices change constantly - re-check before planning.'],
      ['What do the veg, non-veg and vegan food tags mean?', 'They describe each dish\'s classic recipe, not one kitchen\'s version. Ghee, butter or cream can appear even in dishes tagged veg or vegan - ask at the counter before ordering.'],
      ['Where do the restaurant and hotel ratings come from?', 'Star ratings are from Google Maps, with check dates shown in guide notes, with a Tripadvisor rating added where confirmed. Ratings move over time - treat them as a snapshot, not a guarantee.'],
      ['Why are there no hotel prices, and are the views guaranteed?', 'Budget stays change prices daily, so none are listed - tap a stay to open its live listing. Any view mentioned comes from the property\'s own listing and rooms vary, so check recent review photos before booking.'],
      ['Is the Log in button a real account?', 'Yes. You can log in with an email and password checked by the Supabase auth service. Google sign-in needs separate hosting and is not verified yet; new email sign-up is paused until the site owner connects an email sender. Your password is never seen or stored by this site.'],
      ['Does Safarnama cover all of India?', 'The 12 destination cards are hand-picked, but the season guide covers all 28 states and 8 union territories, with one festival each. Festival dates mostly follow the lunar calendar and shift year to year - confirm before you plan.']
    ] },
  hi: { label: '\u0939\u093f\u0928\u094d\u0926\u0940 (Hindi)', dir: 'ltr', langLabel: '\u092d\u093e\u0937\u093e',
    title: '\u0938\u0935\u093e\u0932\u094b\u0902 \u0915\u0947 \u091c\u0935\u093e\u092c',
    note: '\u092f\u0939 FAQ \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u093c\u0940 \u092f\u093e \u092d\u093e\u0930\u0924 \u0915\u0940 22 \u0905\u0928\u0942\u0938\u0942\u091a\u093f\u0924 \u092d\u093e\u0937\u093e\u0913\u0902 \u092e\u0947\u0902 \u092a\u0922\u093c\u0947\u0902 (\u0938\u0902\u0935\u093f\u0927\u093e\u0928 \u0915\u0940 \u0906\u0920\u0935\u0940\u0902 \u0905\u0928\u0942\u0938\u0942\u091a\u0940 - \u092d\u093e\u0930\u0924 \u092e\u0947\u0902 \u0914\u0930 \u092d\u0940 \u0915\u0908 \u092d\u093e\u0937\u093e\u090f\u0902 \u092c\u094b\u0932\u0940 \u091c\u093e\u0924\u0940 \u0939\u0948\u0902)\u0964 \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u093c\u0940 \u0915\u0947 \u0905\u0932\u093e\u0935\u093e \u0905\u0928\u0941\u0935\u093e\u0926 AI \u0915\u0940 \u092e\u0926\u0926 \u0938\u0947 \u092c\u0928\u0947 \u0939\u0948\u0902 \u0914\u0930 \u092a\u0947\u0936\u0947\u0935\u0930 \u0930\u0942\u092a \u0938\u0947 \u091c\u093e\u0902\u091a\u0947 \u0928\u0939\u0940\u0902 \u0917\u090f \u0939\u0948\u0902; \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u093c\u0940 \u092a\u093e\u0920 \u0939\u0940 \u092e\u0942\u0932 \u0938\u0902\u0926\u0930\u094d\u092d \u0939\u0948\u0964',
    items: [
      ['\u0915\u094d\u092f\u093e \u092e\u0948\u0902 Safarnama \u092a\u0930 \u092b\u093c\u094d\u0932\u093e\u0907\u091f, \u0939\u094b\u091f\u0932 \u092f\u093e \u0930\u0947\u0938\u094d\u091f\u094b\u0930\u093e\u0902 \u092c\u0941\u0915 \u0915\u0930 \u0938\u0915\u0924\u093e \u0939\u0942\u0901?', '\u0928\u0939\u0940\u0902\u0964 Safarnama \u090f\u0915 \u092b\u093c\u094d\u0930\u0902\u091f-\u090f\u0902\u0921 \u091f\u094d\u0930\u0948\u0935\u0932 \u0915\u0949\u0928\u094d\u0938\u0947\u092a\u094d\u091f \u0939\u0948 - \u090f\u0915 \u0921\u0947\u092e\u094b\u0964 \u092f\u0939\u093e\u0901 \u0915\u0941\u091b \u092d\u0940 \u092c\u0941\u0915, \u0930\u093f\u091c\u093c\u0930\u094d\u0935 \u092f\u093e \u091a\u093e\u0930\u094d\u091c \u0928\u0939\u0940\u0902 \u0939\u094b\u0924\u093e\u0964 \u0930\u0947\u0938\u094d\u091f\u094b\u0930\u093e\u0902 \u0914\u0930 \u0938\u094d\u091f\u0947 \u0915\u0947 \u0928\u093e\u092e \u0909\u0928\u0915\u0940 \u0932\u093e\u0907\u0935 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u092a\u0930 \u0932\u093f\u0902\u0915 \u0915\u0930\u0924\u0947 \u0939\u0948\u0902, \u0924\u093e\u0915\u093f \u0906\u092a \u0916\u0941\u0926 \u091c\u093e\u0902\u091a \u0938\u0915\u0947\u0902\u0964'],
      ['\u0915\u094d\u092f\u093e \u0907\u0938 \u0938\u093e\u0907\u091f \u092a\u0930 \u092b\u093c\u094d\u0932\u093e\u0907\u091f \u0915\u0947 \u0915\u093f\u0930\u093e\u090f \u0932\u093e\u0907\u0935 \u0939\u0948\u0902?', '\u0928\u0939\u0940\u0902\u0964 \u092f\u0947 \u090f\u0915 \u0905\u0938\u0932\u0940 \u092c\u0941\u0915\u093f\u0902\u0917 \u0938\u0930\u094d\u091a (Duffel) \u0938\u0947 \u0932\u093f\u090f \u0917\u090f \u0926\u093f\u0928\u093e\u0902\u0915\u093f\u0924 \u0909\u0926\u093e\u0939\u0930\u0923 \u0939\u0948\u0902 - 30 \u0905\u0915\u094d\u091f\u0942\u092c\u0930 2026 \u0915\u094b 28 \u0928\u0935\u0902\u092c\u0930 2026 \u0915\u0940 \u0935\u0928-\u0935\u0947 \u0907\u0915\u094b\u0928\u0949\u092e\u0940 \u092b\u093c\u094d\u0932\u093e\u0907\u091f\u094d\u0938 \u0915\u0947 \u0932\u093f\u090f, USD \u092e\u0947\u0902\u0964 \u0915\u0940\u092e\u0924\u0947\u0902 \u0932\u0917\u093e\u0924\u093e\u0930 \u092c\u0926\u0932\u0924\u0940 \u0939\u0948\u0902 - \u092f\u093e\u0924\u094d\u0930\u093e \u0938\u0947 \u092a\u0939\u0932\u0947 \u0926\u094b\u092c\u093e\u0930\u093e \u091c\u093e\u0902\u091a\u0947\u0902\u0964'],
      ['\u0935\u0947\u091c, \u0928\u0949\u0928-\u0935\u0947\u091c \u0914\u0930 \u0935\u0940\u0917\u0928 \u091f\u0948\u0917 \u0915\u093e \u0915\u094d\u092f\u093e \u092e\u0924\u0932\u092c \u0939\u0948?', '\u092f\u0947 \u0939\u0930 \u092a\u0935\u0928 \u0915\u0940 \u092a\u0930\u0902\u092a\u0930\u093e\u0917\u0924 \u0930\u0947\u0938\u093f\u092a\u0940 \u092c\u0924\u093e\u0924\u0947 \u0939\u0948\u0902, \u0915\u093f\u0938\u0940 \u090f\u0915 \u0930\u0938\u094b\u0908 \u0915\u093e \u0924\u0930\u0940\u0915\u093e \u0928\u0939\u0940\u0902\u0964 \u0935\u0947\u091c \u092f\u093e \u0935\u0940\u0917\u0928 \u091f\u0948\u0917 \u0935\u093e\u0932\u0947 \u092a\u0935\u0928\u094b\u0902 \u092e\u0947\u0902 \u092d\u0940 \u0918\u0940, \u092e\u0915\u094d\u0916\u0928 \u092f\u093e \u0915\u094d\u0930\u0940\u092e \u0939\u094b \u0938\u0915\u0924\u093e \u0939\u0948 - \u0911\u0930\u094d\u0921\u0930 \u0915\u0930\u0928\u0947 \u0938\u0947 \u092a\u0939\u0932\u0947 \u0915\u093e\u0909\u0902\u091f\u0930 \u092a\u0930 \u092a\u0942\u091b \u0932\u0947\u0902\u0964'],
      ['\u0930\u0947\u0938\u094d\u091f\u094b\u0930\u093e\u0902 \u0914\u0930 \u0939\u094b\u091f\u0932 \u0915\u0940 \u0930\u0947\u091f\u093f\u0902\u0917 \u0915\u0939\u093e\u0901 \u0938\u0947 \u0906\u0924\u0940 \u0939\u0948?', '\u0938\u094d\u091f\u093e\u0930 \u0930\u0947\u091f\u093f\u0902\u0917 Google Maps \u0938\u0947 \u0939\u0948, 1 \u0928\u0935\u0902\u092c\u0930 2026 \u0915\u094b \u091c\u093e\u0902\u091a\u0940 \u0917\u0908; \u091c\u0939\u093e\u0901 \u092a\u0941\u0937\u094d\u091f\u093f \u0939\u0941\u0908, Tripadvisor \u0930\u0947\u091f\u093f\u0902\u0917 \u092d\u0940 \u091c\u094b\u0921\u093c\u0940 \u0917\u0908 \u0939\u0948\u0964 \u0930\u0947\u091f\u093f\u0902\u0917 \u0938\u092e\u092f \u0915\u0947 \u0938\u093e\u0925 \u092c\u0926\u0932\u0924\u0940 \u0939\u0948\u0902 - \u0907\u0928\u094d\u0939\u0947\u0902 \u090f\u0915 \u0938\u094d\u0928\u0948\u092a\u0936\u0949\u091f \u0938\u092e\u091d\u0947\u0902, \u0917\u093e\u0930\u0902\u091f\u0940 \u0928\u0939\u0940\u0902\u0964'],
      ['\u0939\u094b\u091f\u0932 \u0915\u0940 \u0915\u0940\u092e\u0924\u0947\u0902 \u0915\u094d\u092f\u094b\u0902 \u0928\u0939\u0940\u0902 \u0939\u0948\u0902, \u0914\u0930 \u0915\u094d\u092f\u093e \u0935\u094d\u092f\u0942 \u0915\u0940 \u0917\u093e\u0930\u0902\u091f\u0940 \u0939\u0948?', '\u092c\u091c\u091f \u0938\u094d\u091f\u0947 \u0915\u0940 \u0915\u0940\u092e\u0924\u0947\u0902 \u0930\u094b\u091c\u093c \u092c\u0926\u0932\u0924\u0940 \u0939\u0948\u0902, \u0907\u0938\u0932\u093f\u090f \u0915\u094b\u0908 \u0928\u0939\u0940\u0902 \u0926\u093f\u0916\u093e\u0908 \u0917\u0908 - \u0932\u093e\u0907\u0935 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0916\u094b\u0932\u0928\u0947 \u0915\u0947 \u0932\u093f\u090f \u0938\u094d\u091f\u0947 \u092a\u0930 \u091f\u0948\u092a \u0915\u0930\u0947\u0902\u0964 \u091c\u094b \u092d\u0940 \u0935\u094d\u092f\u0942 \u092c\u0924\u093e\u092f\u093e \u0917\u092f\u093e \u0939\u0948 \u0935\u0939 \u092a\u094d\u0930\u0949\u092a\u0930\u094d\u091f\u0940 \u0915\u0940 \u0905\u092a\u0928\u0940 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0938\u0947 \u0939\u0948 \u0914\u0930 \u0915\u092e\u0930\u0947 \u0905\u0932\u0917-\u0905\u0932\u0917 \u0939\u094b\u0924\u0947 \u0939\u0948\u0902 - \u092c\u0941\u0915\u093f\u0902\u0917 \u0938\u0947 \u092a\u0939\u0932\u0947 \u0939\u093e\u0932 \u0915\u0940 \u0930\u0947\u0935\u094d\u092f\u0942 \u092b\u093c\u094b\u091f\u094b \u0926\u0947\u0916 \u0932\u0947\u0902\u0964'],
      ['\u0915\u094d\u092f\u093e Log in \u092c\u091f\u0928 \u0905\u0938\u0932\u0940 \u0905\u0915\u093e\u0909\u0902\u091f \u0939\u0948?', '\u0939\u093e\u0901\u0964 Log in \u0905\u092c \u0905\u0938\u0932\u0940 email \u0914\u0930 password \u0938\u0947 \u0939\u094b\u0924\u093e \u0939\u0948, \u091c\u093f\u0938\u0947 Supabase auth \u0938\u0947\u0935\u093e \u091c\u093e\u0901\u091a\u0924\u0940 \u0939\u0948\u0964 \u091c\u092c \u0924\u0915 project \u0938\u0947 email sender \u0928\u0939\u0940\u0902 \u091c\u0941\u0921\u093c\u0924\u093e, public sign-up \u092c\u0902\u0926 \u0939\u0948 - \u0905\u092d\u0940 \u0915\u0947\u0935\u0932 \u092a\u0939\u0932\u0947 \u0938\u0947 confirmed accounts \u0939\u0940 log in \u0915\u0930 \u0938\u0915\u0924\u0947 \u0939\u0948\u0902\u0964'],
      ['\u0915\u094d\u092f\u093e Safarnama \u092a\u0942\u0930\u0947 \u092d\u093e\u0930\u0924 \u0915\u094b \u0915\u0935\u0930 \u0915\u0930\u0924\u093e \u0939\u0948?', '12 \u0921\u0947\u0938\u094d\u091f\u093f\u0928\u0947\u0936\u0928 \u0915\u093e\u0930\u094d\u0921 \u091a\u0941\u0928\u093f\u0902\u0926\u093e \u0939\u0948\u0902, \u0932\u0947\u0915\u093f\u0928 \u0938\u0940\u091c\u093c\u0928 \u0917\u093e\u0907\u0921 \u0938\u092d\u0940 28 \u0930\u093e\u091c\u094d\u092f\u094b\u0902 \u0914\u0930 8 \u0915\u0947\u0902\u0926\u094d\u0930 \u0936\u093e\u0938\u093f\u0924 \u092a\u094d\u0930\u0926\u0947\u0936\u094b\u0902 \u0915\u094b \u0915\u0935\u0930 \u0915\u0930\u0924\u093e \u0939\u0948, \u0939\u0930 \u090f\u0915 \u0915\u0947 \u0938\u093e\u0925 \u090f\u0915 \u0924\u094d\u092f\u094b\u0939\u093e\u0930\u0964 \u0924\u094d\u092f\u094b\u0939\u093e\u0930\u094b\u0902 \u0915\u0940 \u0924\u093e\u0930\u0940\u0916\u0947\u0902 \u091c\u093c\u094d\u092f\u093e\u0926\u093e\u0924\u0930 \u091a\u0902\u0926\u094d\u0930 \u0915\u0948\u0932\u0947\u0902\u0921\u0930 \u092a\u0930 \u091a\u0932\u0924\u0940 \u0939\u0948\u0902 \u0914\u0930 \u0939\u0930 \u0938\u093e\u0932 \u092c\u0926\u0932\u0924\u0940 \u0939\u0948\u0902 - \u092f\u093e\u0924\u094d\u0930\u093e \u0938\u0947 \u092a\u0939\u0932\u0947 \u092a\u0941\u0937\u094d\u091f\u093f \u0915\u0930 \u0932\u0947\u0902\u0964']
    ] },
  pa: { label: '\u0a2a\u0a70\u0a1c\u0a3e\u0a2c\u0a40 (Punjabi)', dir: 'ltr', langLabel: '\u0a2d\u0a3e\u0a38\u0a3c\u0a3e',
    title: '\u0a38\u0a35\u0a3e\u0a32\u0a3e\u0a02 \u0a26\u0a47 \u0a1c\u0a35\u0a3e\u0a2c',
    note: '\u0a07\u0a39 FAQ \u0a05\u0a70\u0a17\u0a30\u0a47\u0a1c\u0a3c\u0a40 \u0a1c\u0a3e\u0a02 \u0a2d\u0a3e\u0a30\u0a24 \u0a26\u0a40\u0a06\u0a02 22 \u0a38\u0a3c\u0a47\u0a1c\u0a3f\u0a09\u0a32\u0a21 \u0a2d\u0a3e\u0a38\u0a3c\u0a3e\u0a35\u0a3e\u0a02 \u0a35\u0a3f\u0a71\u0a1a \u0a2a\u0a22\u0a3c\u0a4b (\u0a38\u0a70\u0a35\u0a3f\u0a27\u0a3e\u0a28 \u0a26\u0a40 \u0a05\u0a1f\u0a35\u0a35\u0a40\u0a02 \u0a05\u0a28\u0a41\u0a38\u0a42\u0a1a\u0a40 - \u0a2d\u0a3e\u0a30\u0a24 \u0a35\u0a3f\u0a71\u0a1a \u0a39\u0a4b\u0a30 \u0a35\u0a40 \u0a15\u0a08 \u0a2d\u0a3e\u0a38\u0a3c\u0a3e\u0a35\u0a3e\u0a02 \u0a2c\u0a4b\u0a32\u0a40\u0a06\u0a02 \u0a1c\u0a3e\u0a02\u0a26\u0a40\u0a06\u0a02 \u0a39\u0a28)\u0964 \u0a05\u0a70\u0a17\u0a30\u0a47\u0a1c\u0a3c\u0a40 \u0a24\u0a4b\u0a02 \u0a07\u0a32\u0a3e\u0a35\u0a3e \u0a05\u0a28\u0a41\u0a35\u0a3e\u0a26 AI \u0a26\u0a40 \u0a2e\u0a26\u0a26 \u0a28\u0a3e\u0a32 \u0a2c\u0a23\u0a47 \u0a39\u0a28 \u0a05\u0a24\u0a47 \u0a2a\u0a47\u0a38\u0a3c\u0a47\u0a35\u0a30 \u0a24\u0a4c\u0a30 \u0a27\u0a47 \u0a1c\u0a3e\u0a02\u0a1a\u0a47 \u0a28\u0a39\u0a40\u0a02 \u0a17\u0a0f; \u0a05\u0a70\u0a17\u0a30\u0a47\u0a1c\u0a3c\u0a40 \u0a2a\u0a3e\u0a20 \u0a39\u0a40 \u0a05\u0a38\u0a32\u0a40 \u0a39\u0a35\u0a3e\u0a32\u0a3e \u0a39\u0a48\u0964',
    items: [
      ['\u0a15\u0a40 \u0a2e\u0a48\u0a02 Safarnama \u0a27\u0a47 \u0a2b\u0a3c\u0a32\u0a3e\u0a07\u0a1f, \u0a39\u0a4b\u0a1f\u0a32 \u0a1c\u0a3e\u0a02 \u0a30\u0a48\u0a38\u0a1f\u0a4b\u0a30\u0a3e\u0a02 \u0a2c\u0a41\u0a71\u0a15 \u0a15\u0a30 \u0a38\u0a15\u0a26\u0a3e/\u0a38\u0a15\u0a26\u0a40 \u0a39\u0a3e\u0a02?', '\u0a28\u0a39\u0a40\u0a02\u0964 Safarnama \u0a07\u0a71\u0a15 \u0a2b\u0a3c\u0a30\u0a70\u0a1f-\u0a10\u0a02\u0a21 \u0a1f\u0a30\u0a48\u0a35\u0a32 \u0a15\u0a3e\u0a28\u0a38\u0a48\u0a2a\u0a1f \u0a39\u0a48 - \u0a07\u0a71\u0a15 \u0a21\u0a48\u0a2e\u0a4b\u0964 \u0a07\u0a71\u0a25\u0a47 \u0a15\u0a41\u0a1d \u0a35\u0a40 \u0a2c\u0a41\u0a71\u0a15, \u0a30\u0a3f\u0a1c\u0a3c\u0a30\u0a35 \u0a1c\u0a3e\u0a02 \u0a1a\u0a3e\u0a30\u0a1c \u0a28\u0a39\u0a40\u0a02 \u0a39\u0a41\u0a70\u0a26\u0a3e\u0964 \u0a30\u0a48\u0a38\u0a1f\u0a4b\u0a30\u0a3e\u0a02 \u0a05\u0a24\u0a47 \u0a38\u0a1f\u0a47 \u0a26\u0a47 \u0a28\u0a3e\u0a02 \u0a09\u0a28\u0a4d\u0a39\u0a3e\u0a02 \u0a26\u0a40 \u0a32\u0a3e\u0a07\u0a35 \u0a32\u0a3f\u0a38\u0a1f\u0a3f\u0a70\u0a17 \u0a28\u0a42\u0a70\u0a1a \u0a32\u0a3f\u0a70\u0a15 \u0a15\u0a30\u0a26\u0a47 \u0a39\u0a28, \u0a24\u0a3e\u0a1c\u0a4b \u0a24\u0a41\u0a38\u0a40\u0a02 \u0a06\u0a2a \u0a1c\u0a3e\u0a02\u0a1a \u0a38\u0a15\u0a4b\u0964'],
      ['\u0a15\u0a40 \u0a07\u0a38 \u0a38\u0a3e\u0a07\u0a1f \u0a27\u0a47 \u0a2b\u0a3c\u0a32\u0a3e\u0a07\u0a1f \u0a26\u0a47 \u0a15\u0a3f\u0a30\u0a3e\u0a0f \u0a32\u0a3e\u0a07\u0a35 \u0a39\u0a28?', '\u0a28\u0a39\u0a40\u0a02\u0964 \u0a07\u0a39 \u0a07\u0a71\u0a15 \u0a05\u0a38\u0a32\u0a40 \u0a2c\u0a41\u0a71\u0a15\u0a3f\u0a70\u0a17 \u0a38\u0a30\u0a1a (Duffel) \u0a24\u0a4b\u0a02 \u0a32\u0a08\u0a06\u0a02 \u0a17\u0a08\u0a06\u0a02 \u0a24\u0a3e\u0a30\u0a40\u0a16\u0a3c\u0a35\u0a3e\u0a30 \u0a09\u0a26\u0a3e\u0a39\u0a30\u0a23\u0a3e\u0a02 \u0a39\u0a28 - 30 \u0a05\u0a15\u0a24\u0a42\u0a2c\u0a30 2026 \u0a28\u0a42\u0a70 28 \u0a28\u0a35\u0a70\u0a2c\u0a30 2026 \u0a26\u0a40\u0a06\u0a02 \u0a35\u0a28-\u0a35\u0a47 \u0a07\u0a15\u0a4b\u0a28\u0a4b\u0a2e\u0a40 \u0a2b\u0a3c\u0a32\u0a3e\u0a07\u0a1f\u0a3e\u0a02 \u0a32\u0a08, USD \u0a35\u0a3f\u0a71\u0a1a\u0964 \u0a15\u0a40\u0a2e\u0a24\u0a3e\u0a02 \u0a32\u0a17\u0a3e\u0a24\u0a3e\u0a30 \u0a2c\u0a26\u0a32\u0a26\u0a40\u0a06\u0a02 \u0a39\u0a28 - \u0a2f\u0a3e\u0a24\u0a30\u0a3e \u0a24\u0a4b\u0a02 \u0a2a\u0a39\u0a3f\u0a32\u0a3e\u0a02 \u0a26\u0a41\u0a2c\u0a3e\u0a30\u0a3e \u0a1c\u0a3e\u0a02\u0a1a \u0a32\u0a47\u0a23\u0a40\u0964'],
      ['\u0a35\u0a48\u0a1c, \u0a28\u0a49\u0a28-\u0a35\u0a48\u0a1c \u0a05\u0a24\u0a47 \u0a35\u0a40\u0a17\u0a28 \u0a1f\u0a48\u0a17\u0a3e\u0a02 \u0a26\u0a3e \u0a15\u0a40 \u0a2e\u0a24\u0a32\u0a2c \u0a39\u0a48?', '\u0a07\u0a39 \u0a39\u0a30 \u0a2a\u0a35\u0a28 \u0a26\u0a40 \u0a2a\u0a30\u0a70\u0a2a\u0a30\u0a3e\u0a17\u0a24 \u0a30\u0a48\u0a38\u0a3f\u0a2a\u0a40 \u0a26\u0a38\u0a3c\u0a26\u0a47 \u0a39\u0a28, \u0a15\u0a3f\u0a38\u0a47 \u0a07\u0a71\u0a15 \u0a30\u0a38\u0a4b\u0a08 \u0a26\u0a3e \u0a24\u0a30\u0a40\u0a15\u0a3e \u0a28\u0a39\u0a40\u0a02\u0964 \u0a35\u0a48\u0a1c \u0a1c\u0a3e\u0a02 \u0a35\u0a40\u0a17\u0a28 \u0a1f\u0a48\u0a17 \u0a35\u0a3e\u0a32\u0a47 \u0a2a\u0a35\u0a28\u0a3e\u0a02 \u0a35\u0a3f\u0a71\u0a1a \u0a35\u0a40 \u0a18\u0a40, \u0a2e\u0a71\u0a16\u0a23 \u0a1c\u0a3e\u0a02 \u0a15\u0a30\u0a40\u0a2e \u0a39\u0a4b \u0a38\u0a15\u0a26\u0a40 \u0a39\u0a48 - \u0a13\u0a30\u0a21\u0a30 \u0a15\u0a30\u0a28 \u0a24\u0a4b\u0a02 \u0a2a\u0a39\u0a3f\u0a32\u0a3e\u0a02 \u0a15\u0a3e\u0a09\u0a02\u0a1f\u0a30 \u0a27\u0a47 \u0a2a\u0a41\u0a71\u0a1a \u0a32\u0a47\u0a13\u0964'],
      ['\u0a30\u0a48\u0a38\u0a1f\u0a4b\u0a30\u0a3e\u0a02 \u0a05\u0a24\u0a47 \u0a39\u0a4b\u0a1f\u0a32\u0a3e\u0a02 \u0a26\u0a40 \u0a30\u0a47\u0a1f\u0a3f\u0a70\u0a17 \u0a15\u0a3f\u0a71\u0a25\u0a4b\u0a02 \u0a06\u0a09\u0a02\u0a26\u0a40 \u0a39\u0a48?', '\u0a38\u0a1f\u0a3e\u0a30 \u0a30\u0a47\u0a1f\u0a3f\u0a70\u0a17 Google Maps \u0a24\u0a4b\u0a02 \u0a39\u0a48, 1 \u0a28\u0a35\u0a70\u0a2c\u0a30 2026 \u0a28\u0a42\u0a70 \u0a1c\u0a3e\u0a02\u0a1a\u0a40 \u0a17\u0a08; \u0a1c\u0a3f\u0a71\u0a25\u0a47 \u0a2a\u0a41\u0a38\u0a3c\u0a1f\u0a40 \u0a39\u0a4b\u0a08, Tripadvisor \u0a30\u0a47\u0a1f\u0a3f\u0a70\u0a17 \u0a35\u0a40 \u0a1c\u0a4b\u0a5c\u0a40 \u0a17\u0a08 \u0a39\u0a48\u0964 \u0a30\u0a47\u0a1f\u0a3f\u0a70\u0a17 \u0a38\u0a2e\u0a47\u0a02 \u0a28\u0a3e\u0a32 \u0a2c\u0a26\u0a32\u0a26\u0a40 \u0a39\u0a48 - \u0a07\u0a28\u0a4d\u0a39\u0a3e\u0a02 \u0a28\u0a42\u0a70 \u0a38\u0a28\u0a48\u0a2a\u0a38\u0a3c\u0a3e\u0a1f \u0a38\u0a2e\u0a1d\u0a4b, \u0a17\u0a3e\u0a30\u0a02\u0a1f\u0a40 \u0a28\u0a39\u0a40\u0a02\u0964'],
      ['\u0a39\u0a4b\u0a1f\u0a32 \u0a26\u0a40\u0a06\u0a02 \u0a15\u0a40\u0a2e\u0a24\u0a3e\u0a02 \u0a15\u0a3f\u0a09\u0a02 \u0a28\u0a39\u0a40\u0a02, \u0a05\u0a24\u0a47 \u0a15\u0a40 \u0a35\u0a3f\u0a0a \u0a26\u0a40 \u0a17\u0a3e\u0a30\u0a02\u0a1f\u0a40 \u0a39\u0a48?', '\u0a2c\u0a1c\u0a1f \u0a38\u0a1f\u0a47 \u0a26\u0a40\u0a06\u0a02 \u0a15\u0a40\u0a2e\u0a24\u0a3e\u0a02 \u0a30\u0a4b\u0a1c\u0a3c \u0a2c\u0a26\u0a32\u0a26\u0a40\u0a06\u0a02 \u0a39\u0a28, \u0a07\u0a38 \u0a32\u0a08 \u0a15\u0a4b\u0a08 \u0a28\u0a39\u0a40\u0a02 \u0a26\u0a3f\u0a71\u0a16\u0a3e\u0a08\u0a06\u0a02 \u0a17\u0a08\u0a06\u0a02 - \u0a32\u0a3e\u0a07\u0a35 \u0a32\u0a3f\u0a38\u0a1f\u0a3f\u0a70\u0a17 \u0a16\u0a41\u0a71\u0a32\u0a4d\u0a39\u0a23 \u0a32\u0a08 \u0a38\u0a1f\u0a47 \u0a27\u0a47 \u0a1f\u0a48\u0a2a \u0a15\u0a30\u0a4b\u0964 \u0a1c\u0a4b \u0a35\u0a40 \u0a35\u0a3f\u0a0a \u0a26\u0a71\u0a38\u0a3f\u0a06 \u0a17\u0a3f\u0a06 \u0a39\u0a48 \u0a09\u0a39 \u0a2a\u0a4d\u0a30\u0a3e\u0a2a\u0a30\u0a1f\u0a40 \u0a26\u0a40 \u0a06\u0a2a\u0a23\u0a40 \u0a32\u0a3f\u0a38\u0a1f\u0a3f\u0a70\u0a17 \u0a24\u0a4b\u0a02 \u0a39\u0a48 \u0a05\u0a24\u0a47 \u0a15\u0a2e\u0a30\u0a47 \u0a35\u0a71\u0a16-\u0a35\u0a71\u0a16 \u0a39\u0a41\u0a70\u0a26\u0a47 \u0a39\u0a28 - \u0a2c\u0a41\u0a71\u0a15\u0a3f\u0a70\u0a17 \u0a24\u0a4b\u0a02 \u0a2a\u0a39\u0a3f\u0a32\u0a3e\u0a02 \u0a24\u0a3e\u0a1c\u0a3c\u0a40 \u0a30\u0a3f\u0a35\u0a3f\u0a0a \u0a2b\u0a3c\u0a4b\u0a1f\u0a4b\u0a06\u0a02 \u0a26\u0a47\u0a16 \u0a32\u0a47\u0a13\u0964'],
      ['\u0a15\u0a40 Log in \u0a2c\u0a1f\u0a23 \u0a05\u0a38\u0a32\u0a40 \u0a05\u0a15\u0a3e\u0a09\u0a02\u0a1f \u0a39\u0a48?', '\u0a39\u0a3e\u0a02\u0964 Log in \u0a39\u0a41\u0a23 \u0a05\u0a38\u0a32\u0a40 email \u0a05\u0a24\u0a47 password \u0a28\u0a3e\u0a32 \u0a39\u0a41\u0a70\u0a26\u0a3e \u0a39\u0a48, \u0a1c\u0a3f\u0a38\u0a28\u0a42\u0a70 Supabase auth \u0a38\u0a47\u0a35\u0a3e \u0a1c\u0a3e\u0a02\u0a1a\u0a26\u0a40 \u0a39\u0a48\u0964 \u0a1c\u0a26\u0a4b\u0a02 \u0a24\u0a71\u0a15 project \u0a28\u0a3e\u0a32 email sender \u0a28\u0a39\u0a40\u0a02 \u0a1c\u0a41\u0a5c\u0a26\u0a3e, public sign-up \u0a2c\u0a70\u0a26 \u0a39\u0a48 - \u0a39\u0a41\u0a23\u0a47 \u0a38\u0a3f\u0a30\u0a2b\u0a3c \u0a2a\u0a39\u0a3f\u0a32\u0a3e\u0a02 \u0a24\u0a4b\u0a02 confirmed accounts \u0a39\u0a40 log in \u0a15\u0a30 \u0a38\u0a15\u0a26\u0a47 \u0a39\u0a28\u0964'],
      ['\u0a15\u0a40 Safarnama \u0a2a\u0a42\u0a30\u0a47 \u0a2d\u0a3e\u0a30\u0a24 \u0a28\u0a42\u0a70 \u0a15\u0a35\u0a30 \u0a15\u0a30\u0a26\u0a3e \u0a39\u0a48?', '12 \u0a21\u0a48\u0a38\u0a1f\u0a40\u0a28\u0a47\u0a38\u0a3c\u0a28 \u0a15\u0a3e\u0a30\u0a21 \u0a1a\u0a41\u0a23\u0a47 \u0a39\u0a4b\u0a0f \u0a39\u0a28, \u0a2a\u0a30 \u0a38\u0a40\u0a1c\u0a3c\u0a28 \u0a17\u0a3e\u0a07\u0a21 \u0a38\u0a3e\u0a30\u0a47 28 \u0a38\u0a1f\u0a47\u0a1f\u0a3e\u0a02 \u0a05\u0a24\u0a47 8 \u0a2f\u0a42\u0a28\u0a40\u0a05\u0a28 \u0a1f\u0a48\u0a30\u0a40\u0a1f\u0a30\u0a40\u0a06\u0a02 \u0a28\u0a42\u0a70 \u0a15\u0a35\u0a30 \u0a15\u0a30\u0a26\u0a40 \u0a39\u0a48, \u0a39\u0a30 \u0a07\u0a71\u0a15 \u0a28\u0a3e\u0a32 \u0a07\u0a71\u0a15 \u0a24\u0a3f\u0a09\u0a39\u0a3e\u0a30\u0964 \u0a24\u0a3f\u0a09\u0a39\u0a3e\u0a30\u0a3e\u0a02 \u0a26\u0a40\u0a06\u0a02 \u0a24\u0a3e\u0a30\u0a40\u0a16\u0a3c\u0a3e\u0a02 \u0a05\u0a15\u0a38\u0a30 \u0a1a\u0a70\u0a26 \u0a15\u0a48\u0a32\u0a70\u0a21\u0a30 \u0a27\u0a47 \u0a1a\u0a32\u0a26\u0a40\u0a06\u0a02 \u0a39\u0a28 \u0a05\u0a24\u0a47 \u0a39\u0a30 \u0a38\u0a3e\u0a32 \u0a2c\u0a26\u0a32\u0a26\u0a40\u0a06\u0a02 \u0a39\u0a28 - \u0a2f\u0a3e\u0a24\u0a30\u0a3e \u0a24\u0a4b\u0a02 \u0a2a\u0a39\u0a3f\u0a32\u0a3e\u0a02 \u0a2a\u0a41\u0a38\u0a3c\u0a1f\u0a40 \u0a15\u0a30 \u0a32\u0a47\u0a13\u0964']
    ] },
  ur: { label: '\u0627\u0631\u062f\u0648 (Urdu)', dir: 'rtl', langLabel: '\u0632\u0628\u0627\u0646',
    title: '\u0633\u0648\u0627\u0644\u0648\u06ba \u06a9\u06d2 \u062c\u0648\u0627\u0628',
    note: '\u06cc\u06c1 FAQ \u0627\u0646\u06af\u0631\u06cc\u0632\u06cc \u06cc\u0627 \u0628\u06be\u0627\u0631\u062a \u06a9\u06cc 22 \u0645\u0642\u0631\u0631\u06c1 \u0632\u0628\u0627\u0646\u0648\u06ba \u0645\u06cc\u06ba \u067e\u0691\u06be\u06cc\u06ba (\u0622\u0626\u06cc\u0646 \u06a9\u06cc \u0622\u0679\u06be\u0648\u06cc\u06ba \u0641\u06c1\u0631\u0633\u062a - \u0628\u06be\u0627\u0631\u062a \u0645\u06cc\u06ba \u0627\u0648\u0631 \u0628\u06be\u06cc \u0628\u06c1\u062a \u0633\u06cc \u0632\u0628\u0627\u0646\u06cc\u06ba \u0628\u0648\u0644\u06cc \u062c\u0627\u062a\u06cc \u06c1\u06cc\u06ba)\u06d4 \u0627\u0646\u06af\u0631\u06cc\u0632\u06cc \u06a9\u06d2 \u0639\u0644\u0627\u0648\u06c1 \u062a\u0631\u0627\u062c\u0645 AI \u06a9\u06cc \u0645\u062f\u062f \u0633\u06d2 \u0628\u0646\u06d2 \u06c1\u06cc\u06ba \u0627\u0648\u0631 \u067e\u06cc\u0634\u06c1 \u0648\u0631\u0627\u0646\u06c1 \u0637\u0648\u0631 \u067e\u0631 \u062c\u0627\u0646\u0686\u06d2 \u0646\u06c1\u06cc\u06ba \u06af\u0626\u06d2; \u0627\u0646\u06af\u0631\u06cc\u0632\u06cc \u0645\u062a\u0646 \u06c1\u06cc \u0627\u0635\u0644 \u062d\u0648\u0627\u0644\u06c1 \u06c1\u06d2\u06d4',
    items: [
      ['\u06a9\u06cc\u0627 \u0645\u06cc\u06ba Safarnama \u067e\u0631 \u0641\u0644\u0627\u0626\u0679\u060c \u06c1\u0648\u0679\u0644 \u06cc\u0627 \u0631\u06cc\u0633\u0679\u0648\u0631\u0646\u0679 \u0628\u06a9 \u06a9\u0631 \u0633\u06a9\u062a\u0627 \u06c1\u0648\u06ba\u061f', '\u0646\u06c1\u06cc\u06ba\u06d4 Safarnama \u0627\u06cc\u06a9 \u0641\u0631\u0646\u0679 \u0627\u06cc\u0646\u0688 \u0679\u0631\u06cc\u0648\u0644 \u06a9\u0646\u0633\u06cc\u0679\u0679 \u06c1\u06d2 - \u0627\u06cc\u06a9 \u0688\u06cc\u0645\u0648\u06d4 \u06cc\u06c1\u0627\u06ba \u06a9\u0648\u0626\u06cc \u0686\u06cc\u0632 \u0628\u06a9\u060c \u0631\u06cc\u0632\u0631\u0648 \u06cc\u0627 \u0686\u0627\u0631\u062c \u0646\u06c1\u06cc\u06ba \u06c1\u0648\u062a\u06cc\u06d4 \u0631\u06cc\u0633\u0679\u0648\u0631\u0646\u0679 \u0627\u0648\u0631 \u0627\u0633\u0679\u06d2 \u06a9\u06d2 \u0646\u0627\u0645 \u0627\u0646 \u06a9\u06cc \u0644\u0627\u0626\u0648 \u0644\u0633\u0679\u0646\u06af \u0633\u06d2 \u0644\u0646\u06a9 \u06c1\u0648\u062a\u06d2 \u06c1\u06cc\u06ba \u062a\u0627\u06a9\u06c1 \u0622\u067e \u062e\u0648\u062f \u062c\u0627\u0646\u0686 \u0633\u06a9\u06cc\u06ba\u06d4'],
      ['\u06a9\u06cc\u0627 \u0627\u0633 \u0633\u0627\u0626\u0679 \u067e\u0631 \u0641\u0644\u0627\u0626\u0679 \u06a9\u06d2 \u06a9\u0631\u0627\u0626\u06d2 \u0644\u0627\u0626\u0648 \u06c1\u06cc\u06ba\u061f', '\u0646\u06c1\u06cc\u06ba\u06d4 \u06cc\u06c1 \u0627\u06cc\u06a9 \u062d\u0642\u06cc\u0642\u06cc \u0628\u06a9\u0646\u06af \u0633\u0631\u0686 (Duffel) \u0633\u06d2 \u0644\u06cc \u06af\u0626\u06d2 \u062a\u0627\u0631\u06cc\u062e \u0648\u0627\u0631 \u0645\u062b\u0627\u0644\u06cc\u06ba \u06c1\u06cc\u06ba - 30 \u0627\u06a9\u062a\u0648\u0628\u0631 2026 \u06a9\u0648 28 \u0646\u0648\u0645\u0628\u0631 2026 \u06a9\u06cc \u0648\u0646 \u0648\u06d2 \u0627\u06cc\u06a9\u0648\u0646\u0645\u06cc \u0641\u0644\u0627\u0626\u0679\u0633 \u06a9\u06d2 \u0644\u06cc\u06d2\u060c USD \u0645\u06cc\u06ba\u06d4 \u0642\u06cc\u0645\u062a\u06cc\u06ba \u0645\u0633\u062a\u0642\u0644 \u0628\u062f\u0644\u062a\u06cc \u06c1\u06cc\u06ba - \u0633\u0641\u0631 \u0633\u06d2 \u067e\u06c1\u0644\u06d2 \u062f\u0648\u0628\u0627\u0631\u06c1 \u062c\u0627\u0646\u0686 \u0644\u06cc\u06ba\u06d4'],
      ['\u0648\u06cc\u062c\u060c \u0646\u0627\u0646 \u0648\u06cc\u062c \u0627\u0648\u0631 \u0648\u06cc\u06af\u0646 \u0679\u06cc\u06af\u0632 \u06a9\u0627 \u06a9\u06cc\u0627 \u0645\u0637\u0644\u0628 \u06c1\u06d2\u061f', '\u06cc\u06c1 \u06c1\u0631 \u067e\u0648\u0627\u0646 \u06a9\u06cc \u0631\u0648\u0627\u06cc\u062a\u06cc \u0631\u06cc\u0633\u067e\u06cc \u0628\u062a\u0627\u062a\u06d2 \u06c1\u06cc\u06ba\u060c \u06a9\u0633\u06cc \u0627\u06cc\u06a9 \u0628\u0627\u0648\u0631\u0686\u06cc \u062e\u0627\u0646\u06d2 \u06a9\u0627 \u0637\u0631\u06cc\u0642\u06c1 \u0646\u06c1\u06cc\u06ba\u06d4 \u0648\u06cc\u062c \u06cc\u0627 \u0648\u06cc\u06af\u0646 \u0679\u06cc\u06af \u0648\u0627\u0644\u06d2 \u067e\u0648\u0627\u0646\u0648\u06ba \u0645\u06cc\u06ba \u0628\u06be\u06cc \u06af\u06be\u06cc\u060c \u0645\u06a9\u06be\u0646 \u06cc\u0627 \u06a9\u0631\u06cc\u0645 \u06c1\u0648 \u0633\u06a9\u062a\u06cc \u06c1\u06d2 - \u0622\u0631\u0688\u0631 \u06a9\u0631\u0646\u06d2 \u0633\u06d2 \u067e\u06c1\u0644\u06d2 \u06a9\u0627\u0624\u0646\u0679\u0631 \u067e\u0631 \u067e\u0648\u0686\u06be \u0644\u06cc\u06ba\u06d4'],
      ['\u0631\u06cc\u0633\u0679\u0648\u0631\u0646\u0679 \u0627\u0648\u0631 \u06c1\u0648\u0679\u0644 \u06a9\u06cc \u0631\u06cc\u0679\u0646\u06af \u06a9\u06c1\u0627\u06ba \u0633\u06d2 \u0622\u062a\u06cc \u06c1\u06d2\u061f', '\u0633\u0679\u0627\u0631 \u0631\u06cc\u0679\u0646\u06af Google Maps \u0633\u06d2 \u06c1\u06d2\u060c 1 \u0646\u0648\u0645\u0628\u0631 2026 \u06a9\u0648 \u062c\u0627\u0646\u0686\u06cc \u06af\u0626\u06cc; \u062c\u06c1\u0627\u06ba \u062a\u0635\u062f\u06cc\u0642 \u06c1\u0648\u0626\u06cc\u060c Tripadvisor \u0631\u06cc\u0679\u0646\u06af \u0628\u06be\u06cc \u0634\u0627\u0645\u0644 \u06c1\u06d2\u06d4 \u0631\u06cc\u0679\u0646\u06af \u0648\u0642\u062a \u06a9\u06d2 \u0633\u0627\u062a\u06be \u0628\u062f\u0644\u062a\u06cc \u06c1\u06d2 - \u0627\u0646\u06c1\u06cc\u06ba \u0627\u06cc\u06a9 \u0627\u0633\u0646\u06cc\u067e \u0634\u0627\u0679 \u0633\u0645\u062c\u06be\u06cc\u06ba\u060c \u0636\u0645\u0627\u0646\u062a \u0646\u06c1\u06cc\u06ba\u06d4'],
      ['\u06c1\u0648\u0679\u0644 \u06a9\u06cc \u0642\u06cc\u0645\u062a\u06cc\u06ba \u06a9\u06cc\u0648\u06ba \u0646\u06c1\u06cc\u06ba\u060c \u0627\u0648\u0631 \u06a9\u06cc\u0627 \u0646\u0638\u0627\u0631\u06d2 \u06a9\u06cc \u0636\u0645\u0627\u0646\u062a \u06c1\u06d2\u061f', '\u0628\u062c\u0679 \u0627\u0633\u0679\u06d2 \u06a9\u06cc \u0642\u06cc\u0645\u062a\u06cc\u06ba \u0631\u0648\u0632 \u0628\u062f\u0644\u062a\u06cc \u06c1\u06cc\u06ba\u060c \u0627\u0633 \u0644\u06cc\u06d2 \u06a9\u0648\u0626\u06cc \u0646\u06c1\u06cc\u06ba \u062f\u06a9\u06be\u0627\u0626\u06cc \u06af\u0626\u06cc - \u0644\u0627\u0626\u0648 \u0644\u0633\u0679\u0646\u06af \u06a9\u06be\u0648\u0644\u0646\u06d2 \u06a9\u06d2 \u0644\u06cc\u06d2 \u0627\u0633\u0679\u06d2 \u067e\u0631 \u0679\u06cc\u067e \u06a9\u0631\u06cc\u06ba\u06d4 \u062c\u0648 \u0628\u06be\u06cc \u0646\u0638\u0627\u0631\u06c1 \u0628\u062a\u0627\u06cc\u0627 \u06af\u06cc\u0627 \u06c1\u06d2 \u0648\u06c1 \u067e\u0631\u0627\u067e\u0631\u0679\u06cc \u06a9\u06cc \u0627\u067e\u0646\u06cc \u0644\u0633\u0679\u0646\u06af \u0633\u06d2 \u06c1\u06d2 \u0627\u0648\u0631 \u06a9\u0645\u0631\u06d2 \u0645\u062e\u062a\u0644\u0641 \u06c1\u0648\u062a\u06d2 \u06c1\u06cc\u06ba - \u0628\u06a9\u0646\u06af \u0633\u06d2 \u067e\u06c1\u0644\u06d2 \u062d\u0627\u0644 \u06a9\u06cc \u0631\u06cc\u0648\u06cc\u0648 \u0641\u0648\u0679\u0648\u0632 \u062f\u06cc\u06a9\u06be \u0644\u06cc\u06ba\u06d4'],
      ['\u06a9\u06cc\u0627 Log in \u0628\u0679\u0646 \u062d\u0642\u06cc\u0642\u06cc \u0627\u06cc\u06a9\u0627\u0624\u0646\u0679 \u06c1\u06d2\u061f', '\u06c1\u0627\u06ba\u06d4 Log in \u0627\u0628 \u0627\u0635\u0644\u06cc email \u0627\u0648\u0631 password \u0633\u06d2 \u06c1\u0648\u062a\u0627 \u06c1\u06d2\u060c \u062c\u0633\u06d2 Supabase auth \u0633\u0631\u0648\u0633 \u062c\u0627\u0646\u0686\u062a\u06cc \u06c1\u06d2\u06d4 \u062c\u0628 \u062a\u06a9 project \u0633\u06d2 email sender \u0646\u06c1\u06cc\u06ba \u062c\u064f\u0691\u062a\u0627\u060c public sign-up \u0628\u0646\u062f \u06c1\u06d2 - \u0627\u0628\u06be\u06cc \u0635\u0631\u0641 \u067e\u06c1\u0644\u06d2 \u0633\u06d2 confirmed accounts \u06c1\u06cc log in \u06a9\u0631 \u0633\u06a9\u062a\u06d2 \u06c1\u06cc\u06ba\u06d4'],
      ['\u06a9\u06cc\u0627 Safarnama \u067e\u0648\u0631\u06d2 \u0628\u06be\u0627\u0631\u062a \u06a9\u0648 \u06a9\u0648\u0631 \u06a9\u0631\u062a\u0627 \u06c1\u06d2\u061f', '12 \u0688\u06cc\u0633\u0679\u06cc\u0646\u06cc\u0634\u0646 \u06a9\u0627\u0631\u0688 \u0645\u0646\u062a\u062e\u0628 \u06c1\u06cc\u06ba\u060c \u0644\u06cc\u06a9\u0646 \u0633\u06cc\u0632\u0646 \u06af\u0627\u0626\u0688 \u062a\u0645\u0627\u0645 28 \u0631\u06cc\u0627\u0633\u062a\u0648\u06ba \u0627\u0648\u0631 8 \u06cc\u0648\u0646\u06cc\u0646 \u0679\u06cc\u0631\u06cc\u0679\u0631\u06cc\u0632 \u06a9\u0648 \u06a9\u0648\u0631 \u06a9\u0631\u062a\u0627 \u06c1\u06d2\u060c \u06c1\u0631 \u0627\u06cc\u06a9 \u06a9\u06d2 \u0633\u0627\u062a\u06be \u0627\u06cc\u06a9 \u062a\u06cc\u0648\u06c1\u0627\u0631\u06d4 \u062a\u06cc\u0648\u06c1\u0627\u0631\u0648\u06ba \u06a9\u06cc \u062a\u0627\u0631\u06cc\u062e\u06cc\u06ba \u0627\u06a9\u062b\u0631 \u0642\u0645\u0631\u06cc \u06a9\u06cc\u0644\u0646\u0688\u0631 \u067e\u0631 \u0686\u0644\u062a\u06cc \u06c1\u06cc\u06ba \u0627\u0648\u0631 \u06c1\u0631 \u0633\u0627\u0644 \u0628\u062f\u0644\u062a\u06cc \u06c1\u06cc\u06ba - \u0633\u0641\u0631 \u0633\u06d2 \u067e\u06c1\u0644\u06d2 \u062a\u0635\u062f\u06cc\u0642 \u06a9\u0631 \u0644\u06cc\u06ba\u06d4']
    ] },
  bn: { label: '\u09ac\u09be\u0982\u09b2\u09be (Bengali)', dir: 'ltr', langLabel: '\u09ad\u09be\u09b7\u09be',
    title: '\u09aa\u09cd\u09b0\u09b6\u09cd\u09a8\u09c7\u09b0 \u0989\u09a4\u09cd\u09a4\u09b0',
    note: '\u098f\u0987 FAQ \u0987\u0982\u09b0\u09c7\u099c\u09bf \u09ac\u09be \u09ad\u09be\u09b0\u09a4\u09c7\u09b0 \u09e8\u09e8\u099f\u09bf \u09a4\u09be\u09b2\u09bf\u0995\u09be\u09ad\u09c1\u0995\u09cd\u09a4 \u09ad\u09be\u09b7\u09be\u09df \u09aa\u09a1\u09bc\u09c1\u09a8 (\u09b8\u0982\u09ac\u09bf\u09a7\u09be\u09a8\u09c7\u09b0 \u0985\u09b7\u09cd\u099f\u09ae \u09a4\u09be\u09b2\u09bf\u0995\u09be - \u09ad\u09be\u09b0\u09a4\u09c7 \u0986\u09b0\u0993 \u0985\u09a8\u09c7\u0995 \u09ad\u09be\u09b7\u09be \u09ac\u09b2\u09be \u09b9\u09df)\u0964 \u0987\u0982\u09b0\u09c7\u099c\u09bf \u09ac\u09cd\u09af\u09a4\u09c0\u09a4 \u0985\u09a8\u09c1\u09ac\u09be\u09a6\u0997\u09c1\u09b2\u09bf AI-\u09b8\u09b9\u09be\u09df\u09a4\u09be\u09af \u09a4\u09c8\u09b0\u09bf \u098f\u09ac\u0982 \u09aa\u09c7\u09b6\u09be\u09a6\u09be\u09b0 \u09ad\u09be\u09ac\u09c7 \u09af\u09be\u099a\u09be\u0987 \u0995\u09b0\u09be \u09b9\u09df\u09a8\u09bf; \u0987\u0982\u09b0\u09c7\u099c\u09bf \u09aa\u09be\u09a0\u0987 \u09ae\u09c2\u09b2 \u09b0\u09c7\u09ab\u09be\u09b0\u09c7\u09a8\u09cd\u09b8\u0964',
    items: [
      ['\u0986\u09ae\u09bf \u0995\u09bf Safarnama-\u098f \u09ab\u09cd\u09b2\u09be\u0987\u099f, \u09b9\u09cb\u099f\u09c7\u09b2 \u09ac\u09be \u09b0\u09c7\u09b8\u09cd\u099f\u09c1\u09b0\u09be\u0981 \u09ac\u09c1\u0995 \u0995\u09b0\u09a4\u09c7 \u09aa\u09be\u09b0\u09bf?', '\u09a8\u09be\u0964 Safarnama \u098f\u0995\u099f\u09bf \u09ab\u09cd\u09b0\u09a8\u09cd\u099f-\u098f\u09a8\u09cd\u09a1 \u099f\u09cd\u09b0\u09cd\u09af\u09be\u09ad\u09c7\u09b2 \u0995\u09a8\u09b8\u09c7\u09aa\u09cd\u099f - \u098f\u0995\u099f\u09be \u09a1\u09c7\u09ae\u09cb\u0964 \u098f\u0996\u09be\u09a8\u09c7 \u0995\u09bf\u099b\u09c1\u0987 \u09ac\u09c1\u0995, \u09b0\u09bf\u099c\u09be\u09b0\u09cd\u09ad \u09ac\u09be \u099a\u09be\u09b0\u09cd\u099c \u09b9\u09df \u09a8\u09be\u0964 \u09b0\u09c7\u09b8\u09cd\u099f\u09c1\u09b0\u09be\u0981 \u0993 \u09b8\u09cd\u099f\u09c7\u09b0 \u09a8\u09be\u09ae \u09a4\u09be\u09a6\u09c7\u09b0 \u09b2\u09be\u0987\u09ad \u09b2\u09bf\u09b8\u09cd\u099f\u09bf\u0982-\u098f \u09b2\u09bf\u0982\u0995 \u0995\u09b0\u09be, \u09af\u09be\u09a4\u09c7 \u0986\u09aa\u09a8\u09bf \u09a8\u09bf\u099c\u09c7 \u09af\u09be\u099a\u09be\u0987 \u0995\u09b0\u09a4\u09c7 \u09aa\u09be\u09b0\u09c7\u09a8\u0964'],
      ['\u098f\u0987 \u09b8\u09be\u0987\u099f\u09c7 \u09ab\u09cd\u09b2\u09be\u0987\u099f\u09c7\u09b0 \u09ad\u09be\u09a1\u09bc\u09be \u0995\u09bf \u09b2\u09be\u0987\u09ad?', '\u09a8\u09be\u0964 \u098f\u0997\u09c1\u09b2\u09bf \u098f\u0995\u099f\u09bf \u0986\u09b8\u09b2 \u09ac\u09c1\u0995\u09bf\u0982 \u09b8\u09be\u09b0\u09cd\u099a (Duffel) \u09a5\u09c7\u0995\u09c7 \u09a8\u09c7\u0993\u09df\u09be \u09a4\u09be\u09b0\u09bf\u0996\u09b8\u09b9 \u0989\u09a6\u09be\u09b9\u09b0\u09a3 - \u09e9\u09e6 \u0985\u0995\u09cd\u099f\u09cb\u09ac\u09b0 \u09e8\u09e6\u09e8\u09ec-\u098f \u09e8\u09ee \u09a8\u09ad\u09c7\u09ae\u09cd\u09ac\u09b0 \u09e8\u09e6\u09e8\u09ec-\u098f\u09b0 \u0993\u09df\u09be\u09a8-\u0993\u09df\u09c7 \u0987\u0995\u09cb\u09a8\u09ae\u09bf \u09ab\u09cd\u09b2\u09be\u0987\u099f\u09c7\u09b0 \u099c\u09a8\u09cd\u09af, USD-\u09a4\u09c7\u0964 \u09a6\u09be\u09ae \u09ae\u09cb\u099f\u09c7\u0987 \u09ac\u09a6\u09b2\u09be\u09df - \u09ad\u09cd\u09b0\u09ae\u09a3\u09c7\u09b0 \u0986\u0997\u09c7 \u0986\u09ac\u09be\u09b0 \u09af\u09be\u099a\u09be\u0987 \u0995\u09b0\u09c1\u09a8\u0964'],
      ['\u09ad\u09c7\u099c, \u09a8\u09a8-\u09ad\u09c7\u099c \u098f\u09ac\u0982 \u09ad\u09bf\u0997\u09be\u09a8 \u099f\u09cd\u09af\u09be\u0997\u09c7\u09b0 \u09ae\u09be\u09a8\u09c7 \u0995\u09c0?', '\u098f\u0997\u09c1\u09b2\u09bf \u09aa\u09cd\u09b0\u09a4\u09bf\u099f\u09bf \u09a5\u09be\u09a8\u09cd\u09a1\u09be\u09b0 \u09aa\u09cd\u09b0\u09be\u099a\u09c0\u09a8 \u09b0\u09c7\u09b8\u09bf\u09aa\u09bf \u09ac\u09cb\u099d\u09be\u09df, \u0995\u09cb\u09a8\u0993 \u098f\u0995\u099f\u09bf \u09b0\u09be\u0981\u09a7\u09a8\u09be\u0998\u09b0\u09c7\u09b0 \u09ac\u09cd\u09af\u09be\u09b9\u09be\u09b0 \u09a8\u09df\u0964 \u09ad\u09c7\u099c \u09ac\u09be \u09ad\u09bf\u0997\u09be\u09a8 \u099f\u09cd\u09af\u09be\u0997 \u0995\u09b0\u09be \u09a5\u09be\u09a8\u09cd\u09a1\u09be\u09a4\u09c7\u0993 \u0998\u09bf, \u09ae\u09be\u0996\u09a8 \u09ac\u09be \u0995\u09cd\u09b0\u09bf\u09ae \u09a5\u09be\u0995\u09a4\u09c7 \u09aa\u09be\u09b0\u09c7 - \u0985\u09b0\u09cd\u09a1\u09be\u09b0 \u0995\u09b0\u09be\u09b0 \u0986\u0997\u09c7 \u0995\u09be\u0989\u09a8\u09cd\u099f\u09be\u09b0\u09c7 \u099c\u09bf\u099c\u09cd\u099e\u09be\u09b8 \u0995\u09b0\u09c1\u09a8\u0964'],
      ['\u09b0\u09c7\u09b8\u09cd\u099f\u09c1\u09b0\u09be\u0981 \u0993 \u09b9\u09cb\u099f\u09c7\u09b2\u09c7\u09b0 \u09b0\u09c7\u099f\u09bf\u0982 \u0986\u09b8\u09c7 \u0995\u09cb\u09a5\u09be \u09a5\u09c7\u0995\u09c7?', '\u09b8\u09cd\u099f\u09be\u09b0 \u09b0\u09c7\u099f\u09bf\u0982 Google Maps \u09a5\u09c7\u0995\u09c7, \u09e7 \u09a8\u09ad\u09c7\u09ae\u09cd\u09ac\u09b0 \u09e8\u09e6\u09e8\u09ec \u09af\u09be\u099a\u09be\u0987 \u0995\u09b0\u09be; \u09af\u09c7\u0996\u09be\u09a8\u09c7 \u09a8\u09bf\u09b6\u09cd\u099a\u09bf\u09a4 \u0995\u09b0\u09be \u0997\u09c7\u099b\u09c7, Tripadvisor \u09b0\u09c7\u099f\u09bf\u0982\u0993 \u09af\u09cb\u0997 \u0995\u09b0\u09be \u09b9\u09df\u09c7\u099b\u09c7\u0964 \u09b0\u09c7\u099f\u09bf\u0982 \u09b8\u09ae\u09df\u09c7\u09b0 \u09b8\u09be\u09a5\u09c7 \u09ac\u09a6\u09b2\u09be\u09df - \u098f\u0997\u09c1\u09b2\u09bf\u0995\u09c7 \u09b8\u09cd\u09a8\u09cd\u09af\u09be\u09aa\u09b6\u099f \u09ad\u09be\u09ac\u09c1\u09a8, \u0997\u09cd\u09af\u09be\u09b0\u09be\u09a8\u09cd\u099f\u09bf \u09a8\u09df\u0964'],
      ['\u09b9\u09cb\u099f\u09c7\u09b2\u09c7\u09b0 \u09a6\u09be\u09ae \u0995\u09c7\u09a8 \u09a8\u09c7\u0987, \u0986\u09b0 \u09ad\u09bf\u0989 \u0995\u09bf \u09a8\u09bf\u09b6\u09cd\u099a\u09bf\u09a4?', '\u09ac\u09be\u099c\u09c7\u099f \u09b8\u09cd\u099f\u09c7\u09b0 \u09a6\u09be\u09ae \u09aa\u09cd\u09b0\u09a4\u09bf\u09a6\u09bf\u09a8 \u09ac\u09a6\u09b2\u09be\u09df, \u09a4\u09be\u0987 \u0995\u09cb\u09a8\u0993\u099f\u09bf \u09a6\u09c7\u0996\u09be\u09a8\u09cb \u09b9\u09df\u09a8\u09bf - \u09b2\u09be\u0987\u09ad \u09b2\u09bf\u09b8\u09cd\u099f\u09bf\u0982 \u0996\u09c1\u09b2\u09a4\u09c7 \u09b8\u09cd\u099f\u09c7-\u09a4\u09c7 \u099f\u09cd\u09af\u09be\u09aa \u0995\u09b0\u09c1\u09a8\u0964 \u09af\u09c7 \u09ad\u09bf\u0989 \u0989\u09b2\u09cd\u09b2\u09c7\u0996 \u0995\u09b0\u09be \u09b9\u09df\u09c7\u099b\u09c7 \u09a4\u09be \u09aa\u09cd\u09b0\u09aa\u09be\u09b0\u09be\u09b0\u09cd\u099f\u09bf\u09b0 \u09a8\u09bf\u099c\u09c7\u09b0 \u09b2\u09bf\u09b8\u09cd\u099f\u09bf\u0982 \u09a5\u09c7\u0995\u09c7 \u098f\u09b8\u09c7\u099b\u09c7 \u098f\u09ac\u0982 \u0998\u09b0 \u09ad\u09bf\u09a8\u09cd\u09a8 \u09ad\u09bf\u09a8\u09cd\u09a8 \u09b9\u09df - \u09ac\u09c1\u0995\u09bf\u0982\u09c7\u09b0 \u0986\u0997\u09c7 \u09b8\u09be\u09ae\u09cd\u09aa\u09cd\u09b0\u09a4\u09bf\u0995 \u09b0\u09bf\u09ad\u09bf\u0989 \u099b\u09ac\u09bf \u09a6\u09c7\u0996\u09c1\u09a8\u0964'],
      ['Log in \u09ac\u09cb\u09a4\u09be\u09ae\u099f\u09bf \u0995\u09bf \u0986\u09b8\u09b2 \u0985\u09cd\u09af\u09be\u0995\u09be\u0989\u09a8\u09cd\u099f?', '\u09b9\u09cd\u09af\u09be\u0981\u0964 Log in \u098f\u0996\u09a8 \u0986\u09b8\u09b2 email \u0993 password \u09a6\u09bf\u09af\u09bc\u09c7 \u09b9\u09af\u09bc, \u09af\u09be Supabase auth \u09aa\u09b0\u09bf\u09b7\u09c7\u09ac\u09be \u09af\u09be\u099a\u09be\u0987 \u0995\u09b0\u09c7\u0964 project-\u098f email sender \u09af\u09c1\u0995\u09cd\u09a4 \u09a8\u09be \u09b9\u0993\u09af\u09bc\u09be \u09aa\u09b0\u09cd\u09af\u09a8\u09cd\u09a4 public sign-up \u09ac\u09a8\u09cd\u09a7 - \u098f\u0996\u09a8 \u09b6\u09c1\u09a7\u09c1 \u0986\u0997\u09c7 \u09a5\u09c7\u0995\u09c7 confirmed accounts-\u0987 log in \u0995\u09b0\u09a4\u09c7 \u09aa\u09be\u09b0\u09c7\u0964'],
      ['Safarnama \u0995\u09bf \u09aa\u09c1\u09b0\u09cb \u09ad\u09be\u09b0\u09a4\u0995\u09c7 \u0995\u09be\u09ad\u09be\u09b0 \u0995\u09b0\u09c7?', '\u09e7\u09e8\u099f\u09bf \u09a1\u09c7\u09b8\u09cd\u099f\u09bf\u09a8\u09c7\u09b6\u09a8 \u0995\u09be\u09b0\u09cd\u09a1 \u09ac\u09be\u0981\u099a\u09be\u0987 \u0995\u09b0\u09be, \u0995\u09bf\u09a8\u09cd\u09a4\u09c1 \u09b8\u09bf\u099c\u09a8 \u0997\u09be\u0987\u09a1 \u09b8\u09ac \u09e8\u09ee\u099f\u09bf \u09b0\u09be\u099c\u09cd\u09af \u0993 \u09ee\u099f\u09bf \u0995\u09c7\u09a8\u09cd\u09a6\u09cd\u09b0\u09b6\u09be\u09b8\u09bf\u09a4 \u0985\u099e\u09cd\u099a\u09b2 \u0995\u09be\u09ad\u09be\u09b0 \u0995\u09b0\u09c7, \u09aa\u09cd\u09b0\u09a4\u09bf\u099f\u09bf\u09b0 \u09b8\u09be\u09a5\u09c7 \u098f\u0995\u099f\u09bf \u0995\u09b0\u09c7 \u0989\u09ce\u09b8\u09ac\u0964 \u0989\u09ce\u09b8\u09ac\u09c7\u09b0 \u09a4\u09be\u09b0\u09bf\u0996 \u09ac\u09c7\u09b6\u09bf\u09b0\u09ad\u09be\u0997 \u099a\u09be\u0981\u09a6\u09c7\u09b0 \u09aa\u09de\u09cd\u099c\u09bf\u0995\u09be \u09ae\u09c7\u09a8\u09c7 \u099a\u09b2\u09c7 \u098f\u09ac\u0982 \u09aa\u09cd\u09b0\u09a4\u09bf\u09ac\u099b\u09b0 \u09ac\u09a6\u09b2\u09be\u09df - \u09ad\u09cd\u09b0\u09ae\u09a3\u09c7\u09b0 \u0986\u0997\u09c7 \u09a8\u09bf\u09b6\u09cd\u099a\u09bf\u09a4 \u0995\u09b0\u09c1\u09a8\u0964']
    ] },
  gu: { label: '\u0a97\u0ac1\u0a9c\u0ab0\u0abe\u0aa4\u0ac0 (Gujarati)', dir: 'ltr', langLabel: '\u0aad\u0abe\u0ab7\u0abe',
    title: '\u0aaa\u0acd\u0ab0\u0ab6\u0acd\u0aa8\u0acb\u0aa8\u0abe \u0a9c\u0ab5\u0abe\u0aac',
    note: '\u0a86 FAQ \u0a85\u0a82\u0a97\u0acd\u0ab0\u0ac7\u0a9c\u0ac0 \u0a85\u0aa5\u0ab5\u0abe \u0aad\u0abe\u0ab0\u0aa4\u0aa8\u0ac0 \u0ae8\u0ae8 \u0a85\u0aa8\u0ac1\u0ab8\u0ac2\u0a9a\u0abf\u0aa4 \u0aad\u0abe\u0ab7\u0abe\u0a93\u0aae\u0abe\u0a82 \u0ab5\u0abe\u0a82\u0a9a\u0acb (\u0ab8\u0a82\u0ab5\u0abf\u0aa7\u0abe\u0aa8\u0aa8\u0ac0 \u0a86\u0aa0\u0aae\u0ac0 \u0a85\u0aa8\u0ac1\u0ab8\u0ac2\u0a9a\u0abf - \u0aad\u0abe\u0ab0\u0aa4\u0aae\u0abe\u0a82 \u0ab5\u0aa7\u0ac1 \u0a98\u0aa8\u0ac0 \u0aad\u0abe\u0ab7\u0abe\u0a93 \u0aac\u0acb\u0ab2\u0abe\u0aaf \u0a9b\u0ac7)\u0964 \u0a85\u0a82\u0a97\u0acd\u0ab0\u0ac7\u0a9c\u0ac0 \u0ab8\u0abf\u0ab5\u0abe\u0aaf\u0aa8\u0abe \u0a85\u0aa8\u0ac1\u0ab5\u0abe\u0aa6 AI \u0aa8\u0ac0 \u0aae\u0aa6\u0aa6\u0aa5\u0ac0 \u0aac\u0aa8\u0acd\u0aaf\u0abe \u0a9b\u0ac7 \u0a85\u0aa8\u0ac7 \u0ab5\u0ab3\u0a9a\u0aa3\u0abe\u0ab0\u0ac0\u0a95 \u0ab0\u0ac0\u0aa4\u0ac7 \u0a9a\u0a95\u0abe\u0ab8\u0ab5\u0abe\u0aae\u0abe\u0a82 \u0a86\u0ab5\u0acd\u0aaf\u0abe \u0aa8\u0aa5\u0ac0; \u0a85\u0a82\u0a97\u0acd\u0ab0\u0ac7\u0a9c\u0ac0 \u0aaa\u0abe\u0aa0 \u0a9c \u0aae\u0ac2\u0ab3 \u0ab8\u0a82\u0aa6\u0ab0\u0acd\u0aad \u0a9b\u0ac7\u0964',
    items: [
      ['\u0ab6\u0ac1\u0a82 \u0ab9\u0ac1\u0a82 Safarnama \u0aaa\u0ab0 \u0aab\u0acd\u0ab2\u0abe\u0a87\u0a9f, \u0ab9\u0acb\u0a9f\u0ac7\u0ab2 \u0a95\u0ac7 \u0ab0\u0ac7\u0ab8\u0acd\u0a9f\u0acb\u0ab0\u0aa8\u0acd\u0a9f \u0aac\u0ac1\u0a95 \u0a95\u0ab0\u0ac0 \u0ab6\u0a95\u0ac1\u0a82?', '\u0aa8\u0abe\u0964 Safarnama \u0a8f\u0a95 \u0aab\u0acd\u0ab0\u0aa8\u0acd\u0a9f-\u0a8f\u0aa8\u0acd\u0aa1 \u0a9f\u0acd\u0ab0\u0ac7\u0ab5\u0ab2 \u0a95\u0aa8\u0acd\u0ab8\u0ac7\u0aaa\u0acd\u0a9f \u0a9b\u0ac7 - \u0a8f\u0a95 \u0aa1\u0ac7\u0aae\u0acb\u0964 \u0a85\u0ab9\u0ac0\u0a82 \u0a95\u0a88\u0a82 \u0aac\u0ac1\u0a95, \u0ab0\u0abf\u0a9d\u0ab0\u0acd\u0ab5 \u0a95\u0ac7 \u0a9a\u0abe\u0ab0\u0acd\u0a9c \u0aa5\u0aa4\u0ac1\u0a82 \u0aa8\u0aa5\u0ac0\u0964 \u0ab0\u0ac7\u0ab8\u0acd\u0a9f\u0acb\u0ab0\u0aa8\u0acd\u0a9f \u0a85\u0aa8\u0ac7 \u0ab8\u0acd\u0a9f\u0ac7\u0aa8\u0abe \u0aa8\u0abe\u0aae \u0a8f\u0aae\u0aa8\u0ac0 \u0ab2\u0abe\u0a87\u0ab5 \u0ab2\u0abf\u0ab8\u0acd\u0a9f\u0abf\u0a82\u0a97 \u0ab8\u0abe\u0aa5\u0ac7 \u0ab2\u0abf\u0a82\u0a95 \u0a9b\u0ac7, \u0a9c\u0ac7\u0aa5\u0ac0 \u0aa4\u0aae\u0ac7 \u0a9c\u0ac1\u0aa6\u0ac7 \u0a9a\u0a95\u0abe\u0ab8\u0ac0 \u0ab6\u0a95\u0acb\u0964'],
      ['\u0ab6\u0ac1\u0a82 \u0a86 \u0ab8\u0abe\u0a87\u0a9f \u0aaa\u0ab0 \u0aab\u0acd\u0ab2\u0abe\u0a87\u0a9f\u0aa8\u0abe \u0aad\u0abe\u0aa1\u0abe \u0ab2\u0abe\u0a87\u0ab5 \u0a9b\u0ac7?', '\u0aa8\u0abe\u0964 \u0a86 \u0a8f\u0a95 \u0ab5\u0abe\u0ab8\u0acd\u0aa4\u0ab5\u0abf\u0a95 \u0aac\u0ac1\u0a95\u0abf\u0a82\u0a97 \u0ab8\u0ab0\u0acd\u0a9a (Duffel) \u0aae\u0abe\u0a82\u0aa5\u0ac0 \u0ab2\u0ac7\u0ab5\u0abe\u0aaf\u0ac7\u0ab2\u0abe \u0aa4\u0abe\u0ab0\u0ac0\u0a96\u0ab5\u0abe\u0ab3\u0abe \u0a89\u0aa6\u0abe\u0ab9\u0ab0\u0aa3\u0acb \u0a9b\u0ac7 - \u0ae9\u0ae6 \u0a91\u0a95\u0acd\u0a9f\u0acb\u0aac\u0ab0 \u0ae8\u0ae6\u0ae8\u0aea \u0a8f \u0ae8\u0aee \u0aa8\u0ab5\u0ac7\u0aae\u0acd\u0aac\u0ab0 \u0ae8\u0ae6\u0ae8\u0aea\u0aa8\u0ac0 \u0ab5\u0aa8-\u0ab5\u0ac7 \u0a87\u0a95\u0acb\u0aa8\u0acb\u0aae\u0ac0 \u0aab\u0acd\u0ab2\u0abe\u0a87\u0a9f\u0acd\u0ab8 \u0aae\u0abe\u0a9f\u0ac7, USD \u0aae\u0abe\u0a82\u0964 \u0a95\u0ac0\u0aae\u0aa4\u0acb \u0ab8\u0aa4\u0aa4 \u0aac\u0aa6\u0ab2\u0abe\u0aaf \u0a9b\u0ac7 - \u0aae\u0aa1\u0ab2\u0ac1\u0a82 \u0aaa\u0ab9\u0ac7\u0ab2\u0abe\u0a82 \u0aab\u0ab0\u0ac0 \u0a9a\u0a95\u0abe\u0ab8\u0acb\u0964'],
      ['\u0ab5\u0ac7\u0a9c, \u0aa8\u0acb\u0aa8-\u0ab5\u0ac7\u0a9c \u0a85\u0aa8\u0ac7 \u0ab5\u0ac0\u0a97\u0aa8 \u0a9f\u0ac7\u0a97\u0aa8\u0acb \u0ab6\u0ac1\u0a82 \u0a85\u0ab0\u0acd\u0aa5 \u0aa5\u0abe\u0aaf?', '\u0a8f \u0aa6\u0ab0\u0ac7\u0a95 \u0ab5\u0abe\u0a82\u0a9c\u0a95\u0ac0\u0aa8\u0ac0 \u0aae\u0ac2\u0ab3 \u0ab0\u0ac7\u0ab8\u0abf\u0aaa\u0ac0 \u0aac\u0aa4\u0abe\u0ab5\u0ac7 \u0a9b\u0ac7, \u0a95\u0acb\u0a88 \u0a8f\u0a95 \u0ab0\u0ab8\u0acb\u0a88\u0aa8\u0ac0 \u0ab0\u0ac0\u0aa4 \u0aa8\u0aa5\u0ac0\u0964 \u0ab5\u0ac7\u0a9c \u0a95\u0ac7 \u0ab5\u0ac0\u0a97\u0aa8 \u0a9f\u0ac7\u0a97\u0ab5\u0abe\u0ab3\u0abe \u0ab5\u0abe\u0a82\u0a9c\u0a95\u0acb\u0aae\u0abe\u0a82 \u0aaa\u0aa3 \u0a98\u0ac0, \u0aae\u0abe\u0a96\u0aa3 \u0a95\u0ac7 \u0a95\u0acd\u0ab0\u0ac0\u0aae \u0ab9\u0acb\u0aaf \u0ab6\u0a95\u0ac7 - \u0a91\u0ab0\u0acd\u0aa1\u0ab0 \u0a95\u0ab0\u0aa4\u0abe\u0a82 \u0aaa\u0ab9\u0ac7\u0ab2\u0abe\u0a82 \u0a95\u0abe\u0a89\u0aa8\u0acd\u0a9f\u0ab0 \u0aaa\u0ab0 \u0aaa\u0ac2\u0a9b\u0ac0 \u0ab2\u0acb\u0964'],
      ['\u0ab0\u0ac7\u0ab8\u0acd\u0a9f\u0acb\u0ab0\u0aa8\u0acd\u0a9f \u0a85\u0aa8\u0ac7 \u0ab9\u0acb\u0a9f\u0ac7\u0ab2\u0aa8\u0ac0 \u0ab0\u0ac7\u0a9f\u0abf\u0a82\u0a97 \u0a95\u0acd\u0aaf\u0abe\u0a82\u0aa5\u0ac0 \u0a86\u0ab5\u0ac7 \u0a9b\u0ac7?', '\u0ab8\u0acd\u0a9f\u0abe\u0ab0 \u0ab0\u0ac7\u0a9f\u0abf\u0a82\u0a97 Google Maps \u0aaa\u0ab0\u0aa5\u0ac0 \u0a9b\u0ac7, \u0ae7 \u0aa8\u0ab5\u0ac7\u0aae\u0acd\u0aac\u0ab0 \u0ae8\u0ae6\u0ae8\u0aea\u0a8f \u0a9a\u0a95\u0abe\u0ab8\u0ac7\u0ab2\u0ac0; \u0a9c\u0acd\u0aaf\u0abe\u0a82 \u0a96\u0abe\u0aa4\u0ab0\u0ac0 \u0aa5\u0a88, \u0aa4\u0acd\u0aaf\u0abe\u0a82 Tripadvisor \u0ab0\u0ac7\u0a9f\u0abf\u0a82\u0a97 \u0aaa\u0aa3 \u0a89\u0aae\u0ac7\u0ab0\u0ab5\u0abe\u0aae\u0abe\u0a82 \u0a86\u0ab5\u0ac0 \u0a9b\u0ac7\u0964 \u0ab0\u0ac7\u0a9f\u0abf\u0a82\u0a97 \u0ab8\u0aae\u0aaf \u0ab8\u0abe\u0aa5\u0ac7 \u0aac\u0aa6\u0ab2\u0abe\u0aaf \u0a9b\u0ac7 - \u0a8f\u0aae\u0aa8\u0ac7 \u0ab8\u0acd\u0aa8\u0ac7\u0aaa\u0ab6\u0acb\u0a9f \u0a97\u0aa3\u0acb, \u0a97\u0abe\u0ab0\u0aa8\u0acd\u0a9f\u0ac0 \u0aa8\u0ab9\u0ac0\u0a82\u0964'],
      ['\u0ab9\u0acb\u0a9f\u0ac7\u0ab2\u0aa8\u0ac0 \u0a95\u0ac0\u0aae\u0aa4\u0acb \u0a95\u0ac7\u0aae \u0aa8\u0aa5\u0ac0, \u0a85\u0aa8\u0ac7 \u0ab6\u0ac1\u0a82 \u0ab5\u0acd\u0aaf\u0ac1\u0aa8\u0ac0 \u0a97\u0abe\u0ab0\u0aa8\u0acd\u0a9f\u0ac0 \u0a9b\u0ac7?', '\u0aac\u0a9c\u0ac7\u0a9f \u0ab8\u0acd\u0a9f\u0ac7\u0aa8\u0ac0 \u0a95\u0ac0\u0aae\u0aa4\u0acb \u0ab0\u0acb\u0a9c \u0aac\u0aa6\u0ab2\u0abe\u0aaf \u0a9b\u0ac7, \u0a8f\u0a9f\u0ab2\u0ac7 \u0a95\u0acb\u0a88 \u0aac\u0aa4\u0abe\u0ab5\u0ab5\u0abe\u0aae\u0abe\u0a82 \u0a86\u0ab5\u0ac0 \u0aa8\u0aa5\u0ac0 - \u0ab2\u0abe\u0a87\u0ab5 \u0ab2\u0abf\u0ab8\u0acd\u0a9f\u0abf\u0a82\u0a97 \u0a96\u0acb\u0ab2\u0ab5\u0abe \u0ab8\u0acd\u0a9f\u0ac7 \u0aaa\u0ab0 \u0a9f\u0ac7\u0aaa \u0a95\u0ab0\u0acb\u0964 \u0a9c\u0ac7 \u0ab5\u0acd\u0aaf\u0ac1 \u0a89\u0ab2\u0acd\u0ab2\u0ac7\u0a96 \u0a95\u0ab0\u0ab5\u0abe\u0aae\u0abe\u0a82 \u0a86\u0ab5\u0acd\u0aaf\u0acb \u0a9b\u0ac7 \u0a8f \u0aaa\u0acd\u0ab0\u0acb\u0aaa\u0ab0\u0acd\u0a9f\u0ac0\u0aa8\u0ac0 \u0aaa\u0acb\u0aa4\u0abe\u0aa8\u0ac0 \u0ab2\u0abf\u0ab8\u0acd\u0a9f\u0abf\u0a82\u0a97 \u0aae\u0abe\u0a82\u0aa5\u0ac0 \u0a9b\u0ac7 \u0a85\u0aa8\u0ac7 \u0ab0\u0ac2\u0aae \u0a85\u0ab2\u0a97-\u0a85\u0ab2\u0a97 \u0ab9\u0acb\u0aaf \u0a9b\u0ac7 - \u0aac\u0ac1\u0a95\u0abf\u0a82\u0a97 \u0aaa\u0ab9\u0ac7\u0ab2\u0abe\u0a82 \u0aa4\u0abe\u0a9c\u0ac7\u0aa4\u0ab0\u0aa8\u0abe \u0ab0\u0ac0\u0ab5\u0acd\u0aaf\u0ac1 \u0aab\u0acb\u0a9f\u0abe \u0a9c\u0acb\u0a88 \u0ab2\u0acb\u0964'],
      ['\u0ab6\u0ac1\u0a82 Log in \u0aac\u0a9f\u0aa3 \u0ab5\u0abe\u0ab8\u0acd\u0aa4\u0ab5\u0abf\u0a95 \u0a8f\u0a95\u0abe\u0a89\u0aa8\u0acd\u0a9f \u0a9b\u0ac7?', '\u0ab9\u0abe. Log in \u0ab9\u0ab5\u0ac7 \u0a85\u0ab8\u0ab2\u0ac0 email \u0a85\u0aa8\u0ac7 password \u0aa5\u0ac0 \u0aa5\u0abe\u0aaf \u0a9b\u0ac7, \u0a9c\u0ac7\u0aa8\u0ac7 Supabase auth \u0ab8\u0ac7\u0ab5\u0abe \u0a9a\u0a95\u0abe\u0ab8\u0ac7 \u0a9b\u0ac7. project \u0ab8\u0abe\u0aa5\u0ac7 email sender \u0aa8 \u0a9c\u0acb\u0aa1\u0abe\u0aaf \u0aa4\u0acd\u0aaf\u0abe\u0a82 \u0ab8\u0ac1\u0aa7\u0ac0 public sign-up \u0aac\u0a82\u0aa7 \u0a9b\u0ac7 - \u0ab9\u0aae\u0aa3\u0abe\u0a82 \u0aab\u0a95\u0acd\u0aa4 \u0aaa\u0ab9\u0ac7\u0ab2\u0ac7\u0aa5\u0ac0 confirmed accounts \u0a9c log in \u0a95\u0ab0\u0ac0 \u0ab6\u0a95\u0ac7 \u0a9b\u0ac7.'],
      ['\u0ab6\u0ac1\u0a82 Safarnama \u0a86\u0a96\u0abe \u0aad\u0abe\u0ab0\u0aa4\u0aa8\u0ac7 \u0a95\u0ab5\u0ab0 \u0a95\u0ab0\u0ac7 \u0a9b\u0ac7?', '\u0ae7\u0ae8 \u0aa1\u0ac7\u0ab8\u0acd\u0a9f\u0abf\u0aa8\u0ac7\u0ab6\u0aa8 \u0a95\u0abe\u0ab0\u0acd\u0aa1 \u0aaa\u0abe\u0ab8\u0a82\u0aa6 \u0a95\u0ab0\u0ac7\u0ab2\u0abe \u0a9b\u0ac7, \u0aaa\u0aa3 \u0ab8\u0ac0\u0a9d\u0aa8 \u0a97\u0abe\u0a87\u0aa1 \u0aac\u0aa7\u0abe \u0ae8\u0aee \u0ab0\u0abe\u0a9c\u0acd\u0aaf\u0acb \u0a85\u0aa8\u0ac7 \u0aee \u0a95\u0ac7\u0a82\u0aa6\u0acd\u0ab0\u0ab6\u0abe\u0ab8\u0abf\u0aa4 \u0aaa\u0acd\u0ab0\u0aa6\u0ac7\u0ab6\u0acb\u0aa8\u0ac7 \u0a95\u0ab5\u0ab0 \u0a95\u0ab0\u0ac7 \u0a9b\u0ac7, \u0aa6\u0ab0\u0ac7\u0a95 \u0ab8\u0abe\u0aa5\u0ac7 \u0a8f\u0a95 \u0aa4\u0ac7\u0ab5\u0ab9\u0abe\u0ab0\u0964 \u0aa4\u0ac7\u0ab5\u0ab9\u0abe\u0ab0\u0acb\u0aa8\u0ac0 \u0aa4\u0abe\u0ab0\u0ac0\u0a96\u0acb \u0aae\u0acb\u0a9f\u0abe\u0aad\u0abe\u0a97\u0ac7 \u0a9a\u0abe\u0a82\u0aa6\u0acd\u0ab0 \u0a95\u0ac7\u0ab2\u0ac7\u0aa8\u0acd\u0aa1\u0ab0 \u0aaa\u0ab0 \u0a9a\u0abe\u0ab2\u0ac7 \u0a9b\u0ac7 \u0a85\u0aa8\u0ac7 \u0aa6\u0ab0 \u0ab5\u0ab0\u0acd\u0ab7\u0ac7 \u0aac\u0aa6\u0ab2\u0abe\u0aaf \u0a9b\u0ac7 - \u0aae\u0aa1\u0ab2\u0ac1\u0a82 \u0aaa\u0ab9\u0ac7\u0ab2\u0abe\u0a82 \u0a96\u0abe\u0aa4\u0ab0\u0ac0 \u0a95\u0ab0\u0ac0 \u0ab2\u0acb\u0964']
    ] },
  mr: { label: '\u092e\u0930\u093e\u0920\u0940 (Marathi)', dir: 'ltr', langLabel: '\u092d\u093e\u0937\u093e',
    title: '\u092a\u094d\u0930\u0936\u094d\u0928\u093e\u0902\u091a\u0940 \u0909\u0924\u094d\u0924\u0930\u0947',
    note: '\u0939\u0947 FAQ \u0907\u0902\u0917\u094d\u0930\u091c\u0940 \u0915\u093f\u0902\u0935\u093e \u092d\u093e\u0930\u0924\u093e\u091a\u094d\u092f\u093e \u0968\u0968 \u0905\u0928\u0942\u0938\u0942\u091a\u093f\u0924 \u092d\u093e\u0937\u093e\u0902\u092e\u0927\u094d\u092f\u0947 \u0935\u093e\u091a\u093e (\u0938\u0902\u0935\u093f\u0927\u093e\u0928\u093e\u091a\u0940 \u0906\u0920\u0935\u0940 \u0905\u0928\u0941\u0938\u0942\u091a\u0940)\u0964 \u0907\u0902\u0917\u094d\u0930\u091c\u0940 \u0935\u094d\u092f\u0924\u093f\u0930\u093f\u0915\u094d\u0924 \u092d\u093e\u0937\u093e\u0902\u0924\u0930\u0947 AI \u091a\u094d\u092f\u093e \u092e\u0926\u0924\u0940\u0928\u0947 \u0915\u0947\u0932\u0940 \u0917\u0947\u0932\u0940 \u0906\u0939\u0947\u0924 \u0906\u0923\u093f \u0935\u094d\u092f\u093e\u0935\u0938\u093e\u092f\u093f\u0915 \u0924\u092a\u093e\u0938\u0923\u0940 \u091d\u093e\u0932\u0947\u0932\u0940 \u0928\u093e\u0939\u0940; \u0907\u0902\u0917\u094d\u0930\u091c\u0940 \u092e\u0924\u0941\u0926\u093e \u0939\u093e\u091a \u092e\u0942\u0933 \u0938\u0902\u0926\u0930\u094d\u092d \u0906\u0939\u0947\u0964',
    items: [
      ['Safarnama \u0935\u0930 \u092e\u0940 \u092b\u094d\u0932\u093e\u092f\u091f, \u0939\u0949\u091f\u0947\u0932 \u0915\u093f\u0902\u0935\u093e \u0930\u0947\u0938\u094d\u091f\u0949\u0930\u0902\u091f \u092c\u0941\u0915 \u0915\u0930\u0942 \u0936\u0915\u0924\u094b \u0915\u093e?', '\u0928\u093e\u0939\u0940\u0964 Safarnama \u0939\u0947 \u090f\u0915 \u092b\u094d\u0930\u0902\u091f-\u090f\u0902\u0921 \u091f\u094d\u0930\u0945\u0935\u094d\u0939\u0947\u0932 \u0915\u0949\u0928\u094d\u0938\u0947\u092a\u094d\u091f \u0906\u0939\u0947 - \u090f\u0915 \u0921\u0946\u092e\u094b\u0964 \u0907\u0925\u0947 \u0915\u093e\u0939\u0940\u0939\u0940 \u092c\u0941\u0915, \u0930\u093f\u091d\u0930\u094d\u0935 \u0915\u093f\u0902\u0935\u093e \u091a\u093e\u0930\u094d\u091c \u0939\u094b\u0924 \u0928\u093e\u0939\u0940\u0964 \u0930\u0947\u0938\u094d\u091f\u0949\u0930\u0902\u091f \u0906\u0923\u093f \u0938\u094d\u091f\u0947\u091a\u0940 \u0928\u093e\u0935\u0947 \u0924\u094d\u092f\u093e\u0902\u091a\u094d\u092f\u093e \u0932\u093e\u092f\u0935\u094d\u0939 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917\u0932\u093e \u0932\u093f\u0902\u0915 \u0915\u0930\u0924\u093e\u0924, \u092e\u094d\u0939\u0923\u0942\u0928 \u0924\u0941\u092e\u094d\u0939\u0940 \u0938\u094d\u0935\u0924\u0903 \u0924\u092a\u093e\u0938\u0942 \u0936\u0915\u0924\u093e\u0964'],
      ['\u092f\u093e \u0938\u093e\u0907\u091f\u0935\u0930\u091a\u0947 \u092b\u094d\u0932\u093e\u092f\u091f \u092d\u093e\u0921\u0947 \u0932\u093e\u092f\u0935\u094d\u0939 \u0906\u0939\u0947 \u0915\u093e?', '\u0928\u093e\u0939\u0940\u0964 \u0939\u0940 \u090f\u0916\u093e\u0926\u094d\u092f\u093e \u0916\u0930\u094d\u092f\u093e \u092c\u0941\u0915\u093f\u0902\u0917 \u0938\u0930\u094d\u091a\u092e\u0927\u0942\u0928 (Duffel) \u0918\u0947\u0924\u0932\u0947\u0932\u0940 \u0924\u093e\u0930\u0916\u093e\u0938\u0939 \u0909\u0926\u093e\u0939\u0930\u0923\u0947 \u0906\u0939\u0947\u0924 - \u0969\u0966 \u0911\u0915\u094d\u091f\u094b\u092c\u0930 \u0968\u0966\u0968\u096c \u0930\u094b\u091c\u0940 \u0968\u096e \u0928\u094b\u0935\u094d\u0939\u0947\u0902\u092c\u0930 \u0968\u0966\u0968\u096c \u091a\u094d\u092f\u093e \u0935\u0928-\u0935\u0947 \u0907\u0915\u0949\u0928\u0949\u092e\u0940 \u092b\u094d\u0932\u093e\u092f\u091f\u094d\u0938\u0938\u093e\u0920\u0940, USD \u092e\u0927\u094d\u092f\u0947\u0964 \u0915\u093f\u0902\u092e\u0924\u0940 \u0938\u0924\u0924 \u092c\u0926\u0932\u0924\u093e\u0924 - \u092a\u094d\u0930\u0935\u093e\u0938\u093e\u092a\u0942\u0930\u094d\u0935\u0940 \u092a\u0941\u0928\u094d\u0939\u093e \u0924\u092a\u093e\u0938\u093e\u0964'],
      ['\u0935\u0947\u091c, \u0928\u0949\u0928-\u0935\u0947\u091c \u0906\u0923\u093f \u0935\u0940\u0917\u0928 \u091f\u0945\u0917\u091a\u093e \u0905\u0930\u094d\u0925 \u0915\u093e\u092f?', '\u0924\u0947 \u092a\u094d\u0930\u0924\u094d\u092f\u0947\u0915 \u092a\u0935\u0928\u093e\u091a\u0940 \u092a\u0930\u0902\u092a\u0930\u093e\u0917\u0924 \u0930\u0947\u0938\u093f\u092a\u0940 \u0926\u0930\u094d\u0936\u0935\u0924\u093e\u0924, \u090f\u0916\u093e\u0926\u094d\u092f\u093e \u0938\u094d\u0935\u092f\u0902\u092a\u093e\u0915\u0918\u0930\u093e\u0924\u0932\u0940 \u092a\u0926\u094d\u0927\u0924 \u0928\u093e\u0939\u0940\u0964 \u0935\u0947\u091c \u0915\u093f\u0902\u0935\u093e \u0935\u0940\u0917\u0928 \u091f\u0945\u0917 \u0915\u0947\u0932\u0947\u0932\u094d\u092f\u093e \u092a\u0935\u0928\u093e\u0902\u0924\u0939\u0940 \u0924\u0942\u092a, \u0932\u094b\u0923\u0940 \u0915\u093f\u0902\u0935\u093e \u0915\u094d\u0930\u0940\u092e \u0905\u0938\u0942 \u0936\u0915\u0924\u0947 - \u0911\u0930\u094d\u0921\u0930 \u0915\u0930\u0923\u094d\u092f\u093e\u0906\u0927\u0940 \u0915\u093e\u0909\u0902\u091f\u0930\u0935\u0930 \u0935\u093f\u091a\u093e\u0930\u093e\u0964'],
      ['\u0930\u0947\u0938\u094d\u091f\u0949\u0930\u0902\u091f \u0906\u0923\u093f \u0939\u0949\u091f\u0947\u0932\u091a\u0940 \u0930\u0947\u091f\u093f\u0902\u0917 \u0915\u0941\u0925\u0942\u0928 \u092f\u0947\u0924\u0947?', '\u0938\u094d\u091f\u093e\u0930 \u0930\u0947\u091f\u093f\u0902\u0917 Google Maps \u0935\u0930\u0942\u0928, \u0967 \u0928\u094b\u0935\u094d\u0939\u0947\u0902\u092c\u0930 \u0968\u0966\u0968\u096c \u0930\u094b\u091c\u0940 \u0924\u092a\u093e\u0938\u0932\u0947\u0932\u0940; \u091c\u093f\u0924\u0947 \u0916\u093e\u0924\u0930\u0940 \u091d\u093e\u0932\u0940 \u0924\u093f\u0925\u0947 Tripadvisor \u0930\u0947\u091f\u093f\u0902\u0917\u0939\u0940 \u091c\u094b\u0921\u0932\u0940 \u0917\u0947\u0932\u0940 \u0906\u0939\u0947\u0964 \u0930\u0947\u091f\u093f\u0902\u0917 \u0915\u093e\u0932\u093e\u0928\u0941\u0938\u093e\u0930 \u092c\u0926\u0932\u0924\u0947 - \u0924\u0940 \u090f\u0915 \u0938\u094d\u0928\u0945\u092a\u0936\u0949\u091f \u0938\u092e\u091c\u093e, \u0939\u093e\u092e\u0940 \u0928\u0935\u0939\u0947\u0964'],
      ['\u0939\u0949\u091f\u0947\u0932\u091a\u094d\u092f\u093e \u0915\u093f\u0902\u092e\u0924\u0940 \u0915\u093e \u0928\u093e\u0939\u0940\u0924, \u0906\u0923\u093f \u0935\u094d\u0939\u094d\u092f\u0942\u091a\u0940 \u0939\u093e\u092e\u0940 \u0906\u0939\u0947 \u0915\u093e?', '\u092c\u091c\u0947\u091f \u0938\u094d\u091f\u0947\u091a\u094d\u092f\u093e \u0915\u093f\u0902\u092e\u0924\u0940 \u0930\u094b\u091c \u092c\u0926\u0932\u0924\u093e\u0924, \u092e\u094d\u0939\u0923\u0942\u0928 \u0915\u094b\u0923\u0924\u0940\u0939\u0940 \u0926\u093e\u0916\u0935\u0932\u0947\u0932\u0940 \u0928\u093e\u0939\u0940 - \u0932\u093e\u092f\u0935\u094d\u0939 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0909\u0918\u0921\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u0938\u094d\u091f\u0947\u0935\u0930 \u091f\u0945\u092a \u0915\u0930\u093e\u0964 \u091c\u094b \u0935\u094d\u0939\u094d\u092f\u0942 \u0928\u094b\u0902\u0926\u0935\u0932\u093e \u0906\u0939\u0947 \u0924\u094b \u092a\u094d\u0930\u0949\u092a\u0930\u094d\u091f\u0940\u091a\u094d\u092f\u093e \u0938\u094d\u0935\u0924\u0903\u091a\u094d\u092f\u093e \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917\u092e\u0927\u0942\u0928 \u0906\u0939\u0947 \u0906\u0923\u093f \u0916\u094b\u0932\u094d\u092f\u093e \u0935\u0947\u0917\u0935\u0947\u0917\u0933\u094d\u092f\u093e \u0905\u0938\u0924\u093e\u0924 - \u092c\u0941\u0915\u093f\u0902\u0917\u092a\u0942\u0930\u094d\u0935\u0940 \u0905\u0932\u0940\u0915\u0921\u091a\u0947 \u0930\u093f\u0935\u094d\u0939\u094d\u092f\u0942 \u092b\u094b\u091f\u094b \u092a\u0939\u093e\u0964'],
      ['Log in \u092c\u091f\u0923 \u0916\u0930\u0902 \u0905\u0945\u0915\u093e\u0909\u0902\u091f \u0906\u0939\u0947 \u0915\u093e?', '\u0939\u094b\u092f. Log in \u0906\u0924\u093e \u0916\u0931\u094d\u092f\u093e email \u0906\u0923\u093f password \u0928\u0947 \u0939\u094b\u0924\u0947, \u091c\u0947 Supabase auth \u0938\u0947\u0935\u093e \u0924\u092a\u093e\u0938\u0924\u0947. project \u0936\u0940 email sender \u091c\u094b\u0921\u0932\u0947 \u091c\u093e\u090f\u092a\u0930\u094d\u092f\u0902\u0924 public sign-up \u092c\u0902\u0926 \u0906\u0939\u0947 - \u0906\u0924\u094d\u0924\u093e \u092b\u0915\u094d\u0924 \u0906\u0927\u0940\u091a confirmed accounts log in \u0915\u0930\u0942 \u0936\u0915\u0924\u093e\u0924.'],
      ['Safarnama \u0938\u0902\u092a\u0942\u0930\u094d\u0923 \u092d\u093e\u0930\u0924\u093e\u091a\u0947 \u0915\u0935\u0930\u0947\u091c \u0915\u0930\u0924\u094b \u0915\u093e?', '\u0967\u0968 \u0921\u0947\u0938\u094d\u091f\u093f\u0928\u0947\u0936\u0928 \u0915\u093e\u0930\u094d\u0921 \u0928\u094b\u0902\u0926\u0935\u0932\u0947\u0932\u0940 \u0906\u0939\u0947\u0924, \u092a\u0923 \u0938\u0940\u091d\u0928 \u0917\u093e\u0907\u0921 \u0938\u0930\u094d\u0935 \u0968\u096e \u0930\u093e\u091c\u094d\u092f\u0947 \u0906\u0923\u093f \u096e \u0915\u0947\u0902\u0926\u094d\u0930\u0936\u093e\u0938\u093f\u0924 \u092a\u094d\u0930\u0926\u0947\u0936 \u0938\u092e\u093e\u0935\u093f\u0937\u094d\u091f \u0915\u0930\u0924\u094b, \u092a\u094d\u0930\u0924\u094d\u092f\u0947\u0915\u093e\u0938\u0939 \u090f\u0915 \u0938\u0923\u0964 \u0938\u0923\u093e\u0902\u091a\u094d\u092f\u093e \u0924\u093e\u0930\u0916\u093e \u092c\u0947\u0931\u092a\u0924 \u091a\u093e\u0902\u0926\u094d\u0930 \u0926\u093f\u0928\u0926\u0930\u094d\u0936\u093f\u0915\u0947\u0935\u0930 \u0905\u0938\u0924\u093e\u0924 \u0906\u0923\u093f \u0926\u0930\u0935\u0930\u094d\u0937\u0940 \u092c\u0926\u0932\u0924\u093e\u0924 - \u092a\u094d\u0930\u0935\u093e\u0938\u093e\u092a\u0942\u0930\u094d\u0935\u0940 \u0916\u093e\u0924\u0930\u0940 \u0915\u0930\u093e\u0964']
    ] },
  ta: { label: '\u0ba4\u0bae\u0bbf\u0bb4\u0bcd (Tamil)', dir: 'ltr', langLabel: '\u0bae\u0bca\u0bb4\u0bbf',
    title: '\u0b95\u0bc7\u0bb3\u0bcd\u0bb5\u0bbf\u0b95\u0bb3\u0bc1\u0b95\u0bcd\u0b95\u0bc1 \u0baa\u0ba4\u0bbf\u0bb2\u0bcd\u0b95\u0bb3\u0bcd',
    note: '\u0b87\u0ba8\u0bcd\u0ba4 FAQ-\u0b90 \u0b86\u0b99\u0bcd\u0b95\u0bbf\u0bb2\u0ba4\u0bcd\u0ba4\u0bbf\u0bb2\u0bcb \u0b85\u0bb2\u0bcd\u0bb2\u0ba4\u0bc1 \u0b87\u0ba8\u0bcd\u0ba4\u0bbf\u0baf\u0bbe\u0bb5\u0bbf\u0ba9\u0bcd \u0be8\u0be8 \u0b85\u0b9f\u0bcd\u0b9f\u0bb5\u0ba3\u0bc8 \u0bae\u0bca\u0bb4\u0bbf\u0b95\u0bb3\u0bbf\u0bb2\u0bcb \u0baa\u0b9f\u0bbf\u0b95\u0bcd\u0b95\u0bb2\u0bbe\u0bae\u0bcd (\u0b85\u0bb0\u0b9a\u0bbf\u0baf\u0bb2\u0bae\u0baa\u0bcd\u0baa\u0bc1 \u0b8e\u0b9f\u0bcd\u0b9f\u0bbe\u0bb5\u0ba4\u0bc1 \u0b85\u0b9f\u0bcd\u0b9f\u0bb5\u0ba3\u0bc8)\u0bcd. \u0b86\u0b99\u0bcd\u0b95\u0bbf\u0bb2\u0bae\u0bcd \u0ba4\u0bb5\u0bbf\u0bb0 \u0bae\u0bca\u0bb4\u0bbf\u0baa\u0bc6\u0baf\u0bb0\u0bcd\u0baa\u0bcd\u0baa\u0bc1\u0b95\u0bb3\u0bcd AI \u0b89\u0ba4\u0bb5\u0bbf\u0baf\u0bbe\u0bb2\u0bcd \u0b9a\u0bc6\u0baf\u0bcd\u0baf\u0baa\u0bcd\u0baa\u0b9f\u0bcd\u0b9f\u0bb5\u0bc8, \u0ba4\u0bca\u0bb4\u0bbf\u0bb2\u0bcd\u0bae\u0bc1\u0ba9\u0bc8 \u0b9a\u0bb0\u0bbf\u0baa\u0bbe\u0bb0\u0bcd\u0baa\u0baa\u0bc1 \u0b87\u0bb2\u0bcd\u0bb2\u0bc8; \u0b86\u0b99\u0bcd\u0b95\u0bbf\u0bb2 \u0b89\u0bb0\u0bc8\u0baf\u0bc7 \u0b85\u0b9f\u0bbf\u0baa\u0bcd\u0baa\u0b9f\u0bc8\u0b95\u0bcd \u0b95\u0bc1\u0bb1\u0bbf\u0baa\u0bcd\u0baa\u0bc1\u0bcd.',
    items: [
      ['Safarnama-\u0bb5\u0bbf\u0bb2\u0bcd \u0bb5\u0bbf\u0bae\u0bbe\u0ba9\u0bae\u0bcd, \u0b93\u0b9f\u0bb2\u0bcd \u0b85\u0bb2\u0bcd\u0bb2\u0ba4\u0bc1 \u0b89\u0ba3\u0bb5\u0b95\u0bae\u0bcd \u0baa\u0bc1\u0b95\u0bcd \u0b9a\u0bc6\u0baf\u0bcd\u0baf \u0bae\u0bc1\u0b9f\u0bbf\u0baf\u0bc1\u0bae\u0bbe?', '\u0b87\u0bb2\u0bcd\u0bb2\u0bc8\u0bcd. Safarnama \u0b92\u0bb0\u0bc1 \u0baa\u0bcd\u0bb0\u0ba9\u0bcd\u0b9f\u0bcd-\u0b8e\u0ba8\u0bcd\u0b9f\u0bcd \u0baa\u0baf\u0ba3\u0b95\u0bcd \u0b95\u0bbe\u0bb1\u0bcd\u0baa\u0bc1 - \u0b92\u0bb0\u0bc1 \u0b9f\u0bc6\u0bae\u0bcb\u0bb5\u0bcb\u0bcd. \u0b87\u0b99\u0bcd\u0b95\u0bc1 \u0b8e\u0ba4\u0bc1\u0bb5\u0bc1\u0bae\u0bcd \u0baa\u0bc1\u0b95\u0bcd, \u0bb0\u0bbf\u0b9a\u0bb0\u0bcd\u0bb5\u0bcd \u0b85\u0bb2\u0bcd\u0bb2\u0ba4\u0bc1 \u0b9a\u0bbe\u0bb0\u0bcd\u0b9c\u0bcd \u0b9a\u0bc6\u0baf\u0bcd\u0baf\u0baa\u0bcd\u0baa\u0b9f\u0bb5\u0bbf\u0bb2\u0bcd\u0bb2\u0bc8\u0bcd. \u0b89\u0ba3\u0bb5\u0b95\u0b99\u0bcd\u0b95\u0bb3\u0bcd \u0bae\u0bb1\u0bcd\u0bb1\u0bc1\u0bae\u0bcd \u0ba4\u0b99\u0bcd\u0b95\u0bc1\u0bae\u0bcd \u0b87\u0b9f\u0b99\u0bcd\u0b95\u0bb3\u0bbf\u0ba9\u0bcd \u0baa\u0bc6\u0baf\u0bb0\u0bcd\u0b95\u0bb3\u0bcd \u0b85\u0bb5\u0bb1\u0bcd\u0bb1\u0bbf\u0ba9\u0bcd \u0ba8\u0bbf\u0b95\u0bb4\u0bcd \u0baa\u0ba4\u0bcd\u0ba4\u0bbf\u0baf\u0bb2\u0bc1\u0b95\u0bcd\u0b95\u0bc1 \u0b87\u0ba3\u0bc8\u0b95\u0bcd\u0b95\u0baa\u0bcd\u0baa\u0b9f\u0bcd\u0b9f\u0bc1\u0bb3\u0bcd\u0bb3\u0ba9; \u0ba8\u0bc0\u0b99\u0bcd\u0b95\u0bb3\u0bc7 \u0b9a\u0bb0\u0bbf\u0baa\u0bbe\u0bb0\u0bcd\u0b95\u0bcd\u0b95\u0bb2\u0bbe\u0bae\u0bcd.'],
      ['\u0b87\u0ba8\u0bcd\u0ba4 \u0ba4\u0bb3\u0ba4\u0bcd\u0ba4\u0bbf\u0bb2\u0bcd \u0bb5\u0bbf\u0bae\u0bbe\u0ba9 \u0b95\u0bc2\u0bb2\u0bbf\u0b95\u0bb3\u0bcd \u0ba8\u0bbf\u0b95\u0bb4\u0bcd\u0bb5\u0bc1 \u0bb5\u0bbf\u0bb2\u0bc8\u0b95\u0bb3\u0bbe?', '\u0b87\u0bb2\u0bcd\u0bb2\u0bc8\u0bcd. \u0b87\u0bb5\u0bc8 \u0b92\u0bb0\u0bc1 \u0b89\u0ba3\u0bcd\u0bae\u0bc8\u0baf\u0bbe\u0ba9 \u0baa\u0bc1\u0b95\u0bcd\u0b95\u0bbf\u0b99\u0bcd \u0ba4\u0bc6\u0b9f\u0bb2\u0bbf\u0bb2\u0bbf\u0bb0\u0bc1\u0ba8\u0bcd\u0ba4\u0bc1 (Duffel) \u0b8e\u0b9f\u0bc1\u0b95\u0bcd\u0b95\u0baa\u0bcd\u0baa\u0b9f\u0bcd\u0b9f \u0ba4\u0bc7\u0ba4\u0bbf\u0baf\u0bbf\u0b9f\u0bcd\u0b9f \u0b89\u0ba4\u0bbe\u0bb0\u0ba3\u0b99\u0bcd\u0b95\u0bb3\u0bcd - \u0be9\u0be6 \u0b85\u0b95\u0bcd\u0b9f\u0bcb\u0baa\u0bb0\u0bcd \u0be8\u0be6\u0be8\u0bec \u0b85\u0ba9\u0bcd\u0bb1\u0bc1 \u0be8\u0bee \u0ba8\u0bb5\u0bae\u0bcd\u0baa\u0bb0\u0bcd \u0be8\u0be6\u0be8\u0bec \u0b92\u0bb0\u0bc1\u0bb5\u0b95\u0bc8 \u0b8e\u0b95\u0bbe\u0ba9\u0bae\u0bbf \u0bb5\u0bbf\u0bae\u0bbe\u0ba9\u0b99\u0bcd\u0b95\u0bb3\u0bc1\u0b95\u0bcd\u0b95\u0bc1, USD-\u0b87\u0bb2\u0bcd\u0bcd. \u0bb5\u0bbf\u0bb2\u0bc8\u0b95\u0bb3\u0bcd \u0b85\u0b9f\u0bbf\u0b95\u0bcd\u0b95\u0b9f\u0bbf \u0bae\u0bbe\u0bb1\u0bc1\u0bae\u0bcd - \u0baa\u0baf\u0ba3\u0ba4\u0bcd\u0ba4\u0bbf\u0bb1\u0bcd\u0b95\u0bc1 \u0bae\u0bc1\u0ba9\u0bcd \u0bae\u0bc0\u0ba3\u0bcd\u0b9f\u0bc1\u0bae\u0bcd \u0b9a\u0bb0\u0bbf\u0baa\u0bbe\u0bb0\u0bcd\u0b95\u0bcd\u0b95\u0bb5\u0bc1\u0bae\u0bcd.'],
      ['\u0bb5\u0bc6\u0b9c\u0bcd, \u0ba8\u0bbe\u0ba9\u0bcd-\u0bb5\u0bc6\u0b9c\u0bcd \u0bae\u0bb1\u0bcd\u0bb1\u0bc1\u0bae\u0bcd \u0bb5\u0bc0\u0b95\u0ba9\u0bcd \u0b95\u0bc1\u0bb1\u0bbf\u0b9a\u0bcd\u0b9a\u0bca\u0bb1\u0bcd\u0b95\u0bb3\u0bbf\u0ba9\u0bcd \u0baa\u0bca\u0bb0\u0bc1\u0bb3\u0bcd \u0b8e\u0ba9\u0bcd\u0ba9?', '\u0b85\u0bb5\u0bc8 \u0b92\u0bb5\u0bcd\u0bb5\u0bca\u0bb0\u0bc1 \u0b89\u0ba3\u0bb5\u0bbf\u0ba9\u0bcd \u0baa\u0bb4\u0bae\u0bc8\u0baf\u0bbe\u0ba9 \u0b9a\u0bc6\u0baf\u0bcd\u0bae\u0bc1\u0bb1\u0bc8\u0baf\u0bc8\u0b95\u0bcd \u0b95\u0bc1\u0bb1\u0bbf\u0b95\u0bcd\u0b95\u0bc1\u0bae\u0bcd, \u0b92\u0bb0\u0bc1 \u0b95\u0bc1\u0bb1\u0bbf\u0baa\u0bcd\u0baa\u0bbf\u0b9f\u0bcd\u0b9f \u0b9a\u0bae\u0bc8\u0baf\u0bb2\u0bb1\u0bc8\u0baf\u0bbf\u0ba9\u0bcd \u0bae\u0bc1\u0bb1\u0bc8\u0baf\u0bc8 \u0b85\u0bb2\u0bcd\u0bb2\u0bcd. \u0bb5\u0bc6\u0b9c\u0bcd \u0b85\u0bb2\u0bcd\u0bb2\u0ba4\u0bc1 \u0bb5\u0bc0\u0b95\u0ba9\u0bcd \u0b8e\u0ba9\u0bcd\u0bb1\u0bc1 \u0b95\u0bc1\u0bb1\u0bbf\u0b95\u0bcd\u0b95\u0baa\u0bcd\u0baa\u0b9f\u0bcd\u0b9f \u0b89\u0ba3\u0bb5\u0bc1\u0b95\u0bb3\u0bbf\u0bb2\u0b95\u0bc1\u0bae\u0bcd \u0ba8\u0bc6\u0baf\u0bcd, \u0bb5\u0bc6\u0ba3\u0bcd\u0ba3\u0bc8 \u0b85\u0bb2\u0bcd\u0bb2\u0ba4\u0bc1 \u0b95\u0bbf\u0bb0\u0bc0\u0bae\u0bcd \u0b87\u0bb0\u0bc1\u0b95\u0bcd\u0b95\u0bb2\u0bbe\u0bae\u0bcd - \u0b86\u0bb0\u0bcd\u0b9f\u0bb0\u0bcd \u0b9a\u0bc6\u0baf\u0bcd\u0baf\u0bc1\u0bae\u0bcd \u0bae\u0bc1\u0ba9\u0bcd \u0b95\u0bcc\u0ba3\u0bcd\u0b9f\u0bb0\u0bbf\u0bb2\u0bcd \u0b95\u0bc7\u0b9f\u0bcd\u0b9f\u0bc1\u0b95\u0bcd \u0b95\u0bca\u0bb3\u0bcd\u0bb3\u0bb5\u0bc1\u0bae\u0bcd.'],
      ['\u0b89\u0ba3\u0bb5\u0b95\u0b99\u0bcd\u0b95\u0bb3\u0bcd \u0bae\u0bb1\u0bcd\u0bb1\u0bc1\u0bae\u0bcd \u0b93\u0b9f\u0bb2\u0bcd \u0bae\u0ba4\u0bbf\u0baa\u0bcd\u0baa\u0bc0\u0b9f\u0bc1\u0b95\u0bb3\u0bcd \u0b8e\u0b99\u0bcd\u0b95\u0bbf\u0bb0\u0bc1\u0ba8\u0bcd\u0ba4\u0bc1 \u0bb5\u0bb0\u0bc1\u0b95\u0bbf\u0ba9\u0bcd\u0bb1\u0ba9?', '\u0ba8\u0b9f\u0bcd\u0b9a\u0ba4\u0bcd\u0ba4\u0bbf\u0bb0 \u0bae\u0ba4\u0bbf\u0baa\u0bcd\u0baa\u0bc0\u0b9f\u0bc1\u0b95\u0bb3\u0bcd Google Maps \u0b87\u0bb2\u0bbf\u0bb0\u0bc1\u0ba8\u0bcd\u0ba4\u0bc1, \u0be7 \u0ba8\u0bb5\u0bae\u0bcd\u0baa\u0bb0\u0bcd \u0be8\u0be6\u0be8\u0bec \u0b9a\u0bb0\u0bbf\u0baa\u0bbe\u0bb0\u0bcd\u0b95\u0bcd\u0b95\u0baa\u0bcd\u0baa\u0b9f\u0bcd\u0b9f\u0ba9; \u0b89\u0bb1\u0bc1\u0ba4\u0bbf\u0baf\u0bbe\u0ba9 \u0b87\u0b9f\u0b99\u0bcd\u0b95\u0bb3\u0bbf\u0bb2\u0bcd Tripadvisor \u0bae\u0ba4\u0bbf\u0baa\u0bcd\u0baa\u0bc0\u0b9f\u0bc1\u0bae\u0bcd \u0b9a\u0bc7\u0bb0\u0bcd\u0b95\u0bcd\u0b95\u0baa\u0bcd\u0baa\u0b9f\u0bcd\u0b9f\u0bc1\u0bb3\u0bcd\u0bb3\u0ba4\u0bc1\u0bcd. \u0bae\u0ba4\u0bbf\u0baa\u0bcd\u0baa\u0bc0\u0b9f\u0bc1\u0b95\u0bb3\u0bcd \u0b95\u0bbe\u0bb2\u0ba4\u0bcd\u0ba4\u0bbf\u0bb2\u0bcd \u0bae\u0bbe\u0bb1\u0bc1\u0bae\u0bcd - \u0b87\u0bb5\u0bb1\u0bcd\u0bb1\u0bc8 \u0b92\u0bb0\u0bc1 \u0baa\u0bbe\u0b95\u0bcd\u0bb7\u0bbe\u0b9f\u0bcd\u0b9f\u0bbe\u0b95 \u0b95\u0bb0\u0bc1\u0ba4\u0bb5\u0bc1\u0bae\u0bcd, \u0b89\u0bb1\u0bc1\u0ba4\u0bbf\u0baf\u0bb3\u0bbf\u0baa\u0bcd\u0baa\u0bbe\u0b95 \u0b85\u0bb2\u0bcd\u0bb2\u0bcd.'],
      ['\u0b93\u0b9f\u0bb2\u0bcd \u0bb5\u0bbf\u0bb2\u0bc8\u0b95\u0bb3\u0bcd \u0b8f\u0ba9\u0bcd \u0b87\u0bb2\u0bcd\u0bb2\u0bc8, \u0b95\u0bbe\u0b9f\u0bcd\u0b9a\u0bbf\u0b95\u0bb3\u0bc1\u0b95\u0bcd\u0b95\u0bc1 \u0b89\u0bb1\u0bc1\u0ba4\u0bbf \u0b89\u0ba3\u0bcd\u0b9f\u0bbe?', '\u0baa\u0b9f\u0bcd\u0b9c\u0bc6\u0b9f\u0bcd \u0ba4\u0b99\u0bcd\u0b95\u0bc1\u0bae\u0bcd \u0b87\u0b9f\u0b99\u0bcd\u0b95\u0bb3\u0bbf\u0ba9\u0bcd \u0bb5\u0bbf\u0bb2\u0bc8\u0b95\u0bb3\u0bcd \u0ba4\u0bbf\u0ba9\u0bae\u0bc1\u0bae\u0bcd \u0bae\u0bbe\u0bb1\u0bc1\u0bae\u0bcd, \u0b85\u0ba4\u0ba9\u0bbe\u0bb2\u0bcd \u0b8e\u0ba4\u0bc1\u0bb5\u0bc1\u0bae\u0bcd \u0b95\u0bbe\u0b9f\u0bcd\u0b9f\u0baa\u0bcd\u0baa\u0b9f\u0bb5\u0bbf\u0bb2\u0bcd\u0bb2\u0bc8 - \u0ba8\u0bbf\u0b95\u0bb4\u0bcd \u0baa\u0ba4\u0bcd\u0ba4\u0bbf\u0baf\u0bb2\u0bc8 \u0ba4\u0bbf\u0bb1\u0b95\u0bcd\u0b95 \u0ba4\u0b99\u0bcd\u0b95\u0bc1\u0bae\u0bcd \u0b87\u0b9f\u0ba4\u0bcd\u0ba4\u0bc8 \u0ba4\u0b9f\u0bcd\u0b9f\u0bb5\u0bc1\u0bae\u0bcd. \u0b95\u0bc1\u0bb1\u0bbf\u0baa\u0bcd\u0baa\u0bbf\u0b9f\u0bcd\u0b9f\u0bc1\u0bb3\u0bcd\u0bb3 \u0b95\u0bbe\u0b9f\u0bcd\u0b9a\u0bbf \u0b85\u0ba8\u0bcd\u0ba4 \u0b87\u0b9f\u0ba4\u0bcd\u0ba4\u0bbf\u0ba9\u0bcd \u0b9a\u0bca\u0ba8\u0bcd\u0ba4 \u0baa\u0ba4\u0bcd\u0ba4\u0bbf\u0baf\u0bb2\u0bbf\u0bb2\u0bbf\u0bb0\u0bc1\u0ba8\u0bcd\u0ba4\u0bc1 \u0bb5\u0bb0\u0bc1\u0b95\u0bbf\u0bb1\u0ba4\u0bc1; \u0b85\u0bb1\u0bc8\u0b95\u0bb3\u0bcd \u0bae\u0bbe\u0bb1\u0bc1\u0baa\u0b9f\u0bc1\u0bae\u0bcd - \u0baa\u0bc1\u0b95\u0bcd\u0b95\u0bbf\u0b99\u0bcd \u0b9a\u0bc6\u0baf\u0bcd\u0baf\u0bc1\u0bae\u0bcd \u0bae\u0bc1\u0ba9\u0bcd \u0b9a\u0bc0\u0bae\u0bbf\u0b95\u0bb3\u0bbf\u0bb2\u0bcd \u0bb5\u0bbf\u0bae\u0bb0\u0bcd\u0b9a\u0ba9 \u0baa\u0b9b\u0b99\u0bcd\u0b95\u0bb3\u0bc8\u0baa\u0bcd \u0baa\u0bbe\u0bb0\u0bcd\u0b95\u0bcd\u0b95\u0bb5\u0bc1\u0bae\u0bcd.'],
      ['Log in \u0baa\u0bca\u0ba4\u0bcd\u0ba4\u0bbe\u0ba9\u0bcd \u0b89\u0ba3\u0bcd\u0bae\u0bc8\u0baf\u0bbe\u0ba9 \u0b95\u0ba3\u0b95\u0bcd\u0b95\u0bbe?', '\u0b86\u0bae\u0bcd. Log in \u0b87\u0baa\u0bcd\u0baa\u0bcb\u0ba4\u0bc1 \u0b89\u0ba3\u0bcd\u0bae\u0bc8\u0baf\u0bbe\u0ba9 email \u0bae\u0bb1\u0bcd\u0bb1\u0bc1\u0bae\u0bcd password \u0bae\u0bc2\u0bb2\u0bae\u0bcd \u0ba8\u0b9f\u0b95\u0bcd\u0b95\u0bbf\u0bb1\u0ba4\u0bc1, \u0b85\u0ba4\u0bc8 Supabase auth \u0b9a\u0bc7\u0bb5\u0bc8 \u0b9a\u0bb0\u0bbf\u0baa\u0bbe\u0bb0\u0bcd\u0b95\u0bcd\u0b95\u0bbf\u0bb1\u0ba4\u0bc1. project-\u0b89\u0b9f\u0ba9\u0bcd email sender \u0b87\u0ba3\u0bc8\u0b95\u0bcd\u0b95\u0bc1\u0bae\u0bcd \u0bb5\u0bb0\u0bc8 public sign-up \u0ba8\u0bbf\u0bb1\u0bc1\u0ba4\u0bcd\u0ba4\u0baa\u0bcd\u0baa\u0b9f\u0bcd\u0b9f\u0bc1\u0bb3\u0bcd\u0bb3\u0ba4\u0bc1 - \u0b87\u0baa\u0bcd\u0baa\u0bcb\u0ba4\u0bc1 \u0b8f\u0bb1\u0bcd\u0b95\u0ba9\u0bb5\u0bc7 confirmed accounts \u0bae\u0b9f\u0bcd\u0b9f\u0bc1\u0bae\u0bc7 log in \u0b9a\u0bc6\u0baf\u0bcd\u0baf \u0bae\u0bc1\u0b9f\u0bbf\u0baf\u0bc1\u0bae\u0bcd.'],
      ['Safarnama \u0b87\u0ba8\u0bcd\u0ba4\u0bbf\u0baf\u0bbe \u0bae\u0bc1\u0bb4\u0bc1\u0bb5\u0ba4\u0bc8\u0baf\u0bc1\u0bae\u0bcd \u0b89\u0bb3\u0bcd\u0bb3\u0b9f\u0b95\u0bcd\u0b95\u0bc1\u0b95\u0bbf\u0bb1\u0ba4\u0bbe?', '\u0be7\u0be8 \u0b87\u0b9f \u0b85\u0b9f\u0bcd\u0b9f\u0bc8\u0b95\u0bb3\u0bcd \u0ba4\u0bc7\u0bb0\u0bcd\u0ba8\u0bcd\u0ba4\u0bc6\u0b9f\u0bc1\u0b95\u0bcd\u0b95\u0baa\u0bcd\u0baa\u0b9f\u0bcd\u0b9f\u0bb5\u0bc8, \u0b86\u0ba9\u0bbe\u0bb2\u0bcd \u0baa\u0bb0\u0bc1\u0bb5\u0b95\u0bbe\u0bb2 \u0bb5\u0bb4\u0bbf\u0b95\u0bbe\u0b9f\u0bcd\u0b9f\u0bbf \u0b85\u0ba9\u0bc8\u0ba4\u0bcd\u0ba4\u0bc1 \u0be8\u0bee \u0bae\u0bbe\u0ba9\u0bbf\u0bb2\u0b99\u0bcd\u0b95\u0bb3\u0bc8\u0baf\u0bc1\u0bae\u0bcd \u0bee \u0baf\u0bc2\u0ba9\u0bbf\u0baf\u0ba9\u0bcd \u0baa\u0bbf\u0bb0\u0ba4\u0bc7\u0b9a\u0b99\u0bcd\u0b95\u0bb3\u0bc8\u0baf\u0bc1\u0bae\u0bcd \u0b89\u0bb3\u0bcd\u0bb3\u0b9f\u0b95\u0bcd\u0b95\u0bc1\u0b95\u0bbf\u0bb1\u0ba4\u0bc1, \u0b92\u0bb5\u0bcd\u0bb5\u0bca\u0ba9\u0bcd\u0bb1\u0bc1\u0b95\u0bcd\u0b95\u0bc1\u0bae\u0bcd \u0b92\u0bb0\u0bc1 \u0bb5\u0bbf\u0bb4\u0bbe\u0bb5\u0bc1\u0b9f\u0ba9\u0bcd. \u0bb5\u0bbf\u0bb4\u0bbe \u0ba4\u0bc7\u0ba4\u0bbf\u0b95\u0bb3\u0bcd \u0baa\u0bc6\u0bb0\u0bc1\u0bae\u0bcd\u0baa\u0bbe\u0bb2\u0bc1\u0bae\u0bcd \u0b9a\u0ba8\u0bcd\u0ba4\u0bbf\u0bb0 \u0ba8\u0bbe\u0b9f\u0bcd\u0b9f\u0bc1\u0b95\u0bbe\u0b9f\u0bcd\u0b9f\u0bbf\u0bb2\u0bcd \u0b87\u0bb0\u0bc1\u0b95\u0bcd\u0b95\u0bc1\u0bae\u0bcd; \u0b86\u0ba3\u0bcd\u0b9f\u0bc1\u0ba4\u0bcb\u0bb1\u0bc1\u0bae\u0bcd \u0bae\u0bbe\u0bb1\u0bc1\u0bae\u0bcd - \u0baa\u0baf\u0ba3\u0bae\u0bcd \u0b9a\u0bc6\u0baf\u0bcd\u0bb5\u0ba4\u0bb1\u0bcd\u0b95\u0bc1 \u0bae\u0bc1\u0ba9\u0bcd \u0b89\u0bb1\u0bc1\u0ba4\u0bbf\u0baa\u0bcd\u0baa\u0b9f\u0bc1\u0ba4\u0bcd\u0ba4\u0bb5\u0bc1\u0bae\u0bcd.']
    ] },
  te: { label: '\u0c24\u0c46\u0c32\u0c41\u0c17\u0c41 (Telugu)', dir: 'ltr', langLabel: '\u0c2d\u0c3e\u0c37',
    title: '\u0c2a\u0c4d\u0c30\u0c36\u0c4d\u0c28\u0c32\u0c15\u0c41 \u0c38\u0c2e\u0c3e\u0c27\u0c3e\u0c28\u0c3e\u0c32\u0c41',
    note: '\u0c08 FAQ \u0c28\u0c3f \u0c06\u0c02\u0c17\u0c4d\u0c32\u0c02\u0c32\u0c4b \u0c32\u0c47\u0c26\u0c3e \u0c2d\u0c3e\u0c30\u0c24\u0c26\u0c47\u0c36 22 \u0c37\u0c46\u0c21\u0c4d\u0c2f\u0c42\u0c32\u0c4d\u0c21\u0c4d \u0c2d\u0c3e\u0c37\u0c32\u0c32\u0c4b \u0c1a\u0c26\u0c35\u0c02\u0c21\u0c3f (\u0c30\u0c3e\u0c1c\u0c4d\u0c2f\u0c3e\u0c02\u0c17\u0c02 \u0c0e\u0c1f\u0c4d\u0c38\u0c35 \u0c37\u0c46\u0c21\u0c4d\u0c2f\u0c42\u0c32\u0c4d)\u0c41. \u0c06\u0c02\u0c17\u0c4d\u0c32\u0c02 \u0c15\u0c3e\u0c15\u0c41\u0c02\u0c21\u0c3e \u0c07\u0c24\u0c30 \u0c05\u0c28\u0c41\u0c35\u0c3e\u0c26\u0c3e\u0c32\u0c41 AI \u0c38\u0c39\u0c3e\u0c2f\u0c02\u0c24\u0c4b \u0c1a\u0c47\u0c2f\u0c4d\u0c2f\u0c2c\u0c21\u0c4d\u0c21\u0c3e\u0c2f\u0c3f, \u0c35\u0c43\u0c24\u0c4d\u0c24\u0c3f\u0c2a\u0c30\u0c02\u0c17\u0c3e \u0c27\u0c43\u0c35\u0c40\u0c15\u0c30\u0c3f\u0c02\u0c1a\u0c2c\u0c21\u0c32\u0c47\u0c26\u0c41; \u0c06\u0c02\u0c17\u0c4d\u0c32 \u0c2a\u0c3e\u0c20\u0c4d\u0c2f\u0c2e\u0c47 \u0c2a\u0c4d\u0c30\u0c3e\u0c27\u0c3e\u0c28\u0c3f\u0c15\u0c02\u0c41.',
    items: [
      ['Safarnama\u0c32\u0c4b \u0c2b\u0c4d\u0c32\u0c48\u0c1f\u0c4d, \u0c39\u0c4a\u0c1f\u0c46\u0c32\u0c4d \u0c32\u0c47\u0c26\u0c3e \u0c30\u0c46\u0c38\u0c4d\u0c1f\u0c3e\u0c30\u0c46\u0c02\u0c1f\u0c4d \u0c2c\u0c41\u0c15\u0c4d \u0c1a\u0c47\u0c2f\u0c35\u0c1a\u0c4d\u0c1a\u0c3e?', '\u0c32\u0c47\u0c26\u0c41\u0c41. \u0c07\u0c26\u0c3f \u0c12\u0c15 \u0c2b\u0c4d\u0c30\u0c02\u0c1f\u0c4d-\u0c0e\u0c02\u0c21\u0c4d \u0c1f\u0c4d\u0c30\u0c3e\u0c35\u0c46\u0c32\u0c4d \u0c21\u0c46\u0c2e\u0c4b - \u0c07\u0c15\u0c4d\u0c15\u0c21 \u0c0f\u0c26\u0c40 \u0c2c\u0c41\u0c15\u0c4d, \u0c30\u0c3f\u0c1c\u0c30\u0c4d\u0c35\u0c4d \u0c32\u0c47\u0c26\u0c3e \u0c1a\u0c3e\u0c30\u0c4d\u0c1c\u0c4d \u0c1a\u0c46\u0c2f\u0c4d\u0c2f\u0c2c\u0c21\u0c26\u0c41\u0c41. \u0c2a\u0c47\u0c30\u0c4d\u0c32\u0c41 \u0c35\u0c3e\u0c1f\u0c3f \u0c32\u0c48\u0c35\u0c4d \u0c32\u0c3f\u0c38\u0c4d\u0c1f\u0c3f\u0c02\u0c17\u0c4d\u200c\u0c32\u0c15\u0c41 \u0c32\u0c3f\u0c02\u0c15\u0c4d \u0c1a\u0c47\u0c2f\u0c4d\u0c2f\u0c2c\u0c21\u0c4d\u0c21\u0c3e\u0c2f\u0c3f.'],
      ['\u0c08 \u0c38\u0c48\u0c1f\u0c4d\u0c32\u0c4b \u0c2b\u0c4d\u0c32\u0c48\u0c1f\u0c4d \u0c27\u0c30\u0c32\u0c41 \u0c32\u0c48\u0c35\u0c4d\u200c\u0c28\u0c3e?', '\u0c32\u0c47\u0c26\u0c41\u0c41. \u0c07\u0c35\u0c3f \u0c28\u0c3f\u0c1c\u0c2e\u0c48\u0c28 \u0c2c\u0c41\u0c15\u0c3f\u0c02\u0c17\u0c4d \u0c38\u0c30\u0c4d\u0c1a\u0c4d (Duffel) \u0c28\u0c41\u0c02\u0c21\u0c3f 30 \u0c05\u0c15\u0c4d\u0c1f\u0c4b\u0c2c\u0c30\u0c4d 2026 \u0c28 \u0c24\u0c40\u0c38\u0c3f\u0c28 \u0c09\u0c26\u0c3e\u0c39\u0c30\u0c23\u0c32\u0c41 - 28 \u0c28\u0c35\u0c02\u0c2c\u0c30\u0c4d 2026 \u0c35\u0c28\u0c4d-\u0c35\u0c47 \u0c0e\u0c15\u0c3e\u0c28\u0c2e\u0c40 \u0c15\u0c4b\u0c38\u0c02, USD \u0c32\u0c4b\u0c41. \u0c27\u0c30\u0c32\u0c41 \u0c28\u0c3f\u0c24\u0c4d\u0c2f\u0c02 \u0c2e\u0c3e\u0c30\u0c41\u0c24\u0c41\u0c28\u0c4d\u0c28\u0c3e\u0c2f\u0c3f - \u0c2a\u0c4d\u0c30\u0c2f\u0c3e\u0c23\u0c3e\u0c28\u0c3f\u0c15\u0c3f \u0c2e\u0c41\u0c02\u0c26\u0c41 \u0c2e\u0c33\u0c4d\u0c32\u0c40 \u0c1a\u0c42\u0c21\u0c02\u0c21\u0c3f.'],
      ['\u0c35\u0c46\u0c1c\u0c4d, \u0c28\u0c3e\u0c28\u0c4d-\u0c35\u0c46\u0c1c\u0c4d, \u0c35\u0c40\u0c17\u0c28\u0c4d \u0c1f\u0c4d\u0c2f\u0c3e\u0c17\u0c4d\u200c\u0c32 \u0c05\u0c30\u0c4d\u0c25\u0c02 \u0c0f\u0c2e\u0c3f\u0c1f\u0c3f?', '\u0c05\u0c35\u0c3f \u0c2a\u0c4d\u0c30\u0c24\u0c3f \u0c35\u0c02\u0c1f\u0c15 \u0c38\u0c3e\u0c02\u0c2a\u0c4d\u0c30\u0c26\u0c3e\u0c2f \u0c30\u0c46\u0c38\u0c3f\u0c2a\u0c40\u0c28\u0c3f \u0c1a\u0c46\u0c2a\u0c41\u0c24\u0c3e\u0c2f\u0c3f, \u0c12\u0c15 \u0c35\u0c02\u0c1f\u0c17\u0c26\u0c3f \u0c2a\u0c26\u0c4d\u0c27\u0c24\u0c3f\u0c28\u0c3f \u0c15\u0c3e\u0c26\u0c41\u0c41. \u0c35\u0c46\u0c1c\u0c4d/\u0c35\u0c40\u0c17\u0c28\u0c4d \u0c1f\u0c4d\u0c2f\u0c3e\u0c17\u0c4d \u0c09\u0c28\u0c4d\u0c28\u0c3e \u0c28\u0c46\u0c2f\u0c4d\u0c2f\u0c3f, \u0c35\u0c46\u0c28\u0c4d\u0c28 \u0c32\u0c47\u0c26\u0c3e \u0c15\u0c4d\u0c30\u0c40\u0c2e\u0c4d \u0c09\u0c02\u0c21\u0c35\u0c1a\u0c4d\u0c1a\u0c41 - \u0c06\u0c30\u0c4d\u0c21\u0c30\u0c4d \u0c1a\u0c47\u0c2f\u0c4d\u0c2f\u0c21\u0c3e\u0c28\u0c3f\u0c15\u0c3f \u0c2e\u0c41\u0c02\u0c26\u0c41 \u0c05\u0c21\u0c17\u0c02\u0c21\u0c3f.'],
      ['\u0c30\u0c46\u0c38\u0c4d\u0c1f\u0c3e\u0c30\u0c46\u0c02\u0c1f\u0c4d, \u0c39\u0c4a\u0c1f\u0c46\u0c32\u0c4d \u0c30\u0c47\u0c1f\u0c3f\u0c02\u0c17\u0c4d\u200c\u0c32\u0c41 \u0c0e\u0c15\u0c4d\u0c15\u0c21 \u0c28\u0c41\u0c02\u0c21\u0c3f?', '\u0c38\u0c4d\u0c1f\u0c3e\u0c30\u0c4d \u0c30\u0c47\u0c1f\u0c3f\u0c02\u0c17\u0c4d\u200c\u0c32\u0c41 Google Maps \u0c28\u0c41\u0c02\u0c21\u0c3f, 1 \u0c28\u0c35\u0c02\u0c2c\u0c30\u0c4d 2026 \u0c28 \u0c1a\u0c46\u0c15\u0c4d \u0c1a\u0c47\u0c2f\u0c4d\u0c2f\u0c2c\u0c21\u0c4d\u0c21\u0c3e\u0c2f\u0c3f; \u0c27\u0c43\u0c35\u0c40\u0c15\u0c30\u0c3f\u0c02\u0c1a\u0c2c\u0c21\u0c3f\u0c28 \u0c1a\u0c4b\u0c1f Tripadvisor \u0c15\u0c42\u0c21\u0c3e\u0c41. \u0c30\u0c47\u0c1f\u0c3f\u0c02\u0c17\u0c4d\u200c\u0c32\u0c41 \u0c15\u0c3e\u0c32\u0c3e\u0c28\u0c41\u0c17\u0c41\u0c23\u0c02\u0c17\u0c3e \u0c2e\u0c3e\u0c30\u0c41\u0c24\u0c3e\u0c2f\u0c3f - \u0c38\u0c4d\u0c28\u0c3e\u0c2a\u0c4d\u200c\u0c37\u0c3e\u0c1f\u0c4d\u200c\u0c17\u0c3e \u0c2d\u0c3e\u0c35\u0c3f\u0c02\u0c1a\u0c02\u0c21\u0c3f, \u0c17\u0c3e\u0c30\u0c02\u0c1f\u0c40 \u0c15\u0c3e\u0c26\u0c41\u0c41.'],
      ['\u0c39\u0c4a\u0c1f\u0c46\u0c32\u0c4d \u0c27\u0c30\u0c32\u0c41 \u0c0e\u0c02\u0c26\u0c41\u0c15\u0c41 \u0c32\u0c47\u0c35\u0c41, \u0c35\u0c4d\u0c2f\u0c42\u0c15\u0c3f \u0c17\u0c3e\u0c30\u0c02\u0c1f\u0c40 \u0c09\u0c02\u0c26\u0c3e?', '\u0c2c\u0c21\u0c4d\u0c1c\u0c46\u0c1f\u0c4d \u0c38\u0c4d\u0c1f\u0c47 \u0c27\u0c30\u0c32\u0c41 \u0c30\u0c4b\u0c1c\u0c42 \u0c2e\u0c3e\u0c30\u0c41\u0c24\u0c3e\u0c2f\u0c3f, \u0c05\u0c02\u0c26\u0c41\u0c15\u0c47 \u0c1a\u0c42\u0c2a\u0c3f\u0c02\u0c1a\u0c32\u0c47\u0c26\u0c41 - \u0c32\u0c48\u0c35\u0c4d \u0c32\u0c3f\u0c38\u0c4d\u0c1f\u0c3f\u0c02\u0c17\u0c4d \u0c15\u0c4b\u0c38\u0c02 \u0c38\u0c4d\u0c1f\u0c47\u0c28\u0c3f \u0c1f\u0c4d\u0c2f\u0c3e\u0c2a\u0c4d \u0c1a\u0c47\u0c2f\u0c02\u0c21\u0c3f. \u0c35\u0c4d\u0c2f\u0c42 \u0c06 \u0c2a\u0c4d\u0c30\u0c3e\u0c2a\u0c30\u0c4d\u0c1f\u0c40 \u0c32\u0c3f\u0c38\u0c4d\u0c1f\u0c3f\u0c02\u0c17\u0c4d \u0c28\u0c41\u0c02\u0c21\u0c3f \u0c35\u0c1a\u0c4d\u0c1a\u0c3f\u0c02\u0c26\u0c3f; \u0c17\u0c26\u0c41\u0c32\u0c41 \u0c2e\u0c3e\u0c30\u0c41\u0c24\u0c3e\u0c2f\u0c3f - \u0c2c\u0c41\u0c15\u0c3f\u0c02\u0c17\u0c4d\u200c\u0c15\u0c3f \u0c2e\u0c41\u0c02\u0c26\u0c41 \u0c24\u0c3e\u0c1c\u0c3e \u0c30\u0c3f\u0c35\u0c4d\u0c2f\u0c42 \u0c2b\u0c4b\u0c1f\u0c4b\u0c32\u0c41 \u0c1a\u0c42\u0c21\u0c02\u0c21\u0c3f.'],
      ['Log in \u0c2c\u0c1f\u0c28\u0c4d \u0c28\u0c3f\u0c1c\u0c2e\u0c48\u0c28 \u0c05\u0c15\u0c4d\u0c15\u0c4c\u0c02\u0c1f\u0c4d\u200c\u0c28\u0c3e?', '\u0c05\u0c35\u0c41\u0c28\u0c41. Log in \u0c07\u0c2a\u0c4d\u0c2a\u0c41\u0c21\u0c41 \u0c28\u0c3f\u0c1c\u0c2e\u0c48\u0c28 email \u0c2e\u0c30\u0c3f\u0c2f\u0c41 password \u0c24\u0c4b \u0c1c\u0c30\u0c41\u0c17\u0c41\u0c24\u0c41\u0c02\u0c26\u0c3f, \u0c26\u0c3e\u0c28\u0c4d\u0c28\u0c3f Supabase auth \u0c38\u0c47\u0c35 \u0c27\u0c43\u0c35\u0c40\u0c15\u0c30\u0c3f\u0c38\u0c4d\u0c24\u0c41\u0c02\u0c26\u0c3f. project \u0c24\u0c4b email sender \u0c05\u0c28\u0c41\u0c38\u0c02\u0c27\u0c3e\u0c28\u0c02 \u0c05\u0c2f\u0c4d\u0c2f\u0c47 \u0c35\u0c30\u0c15\u0c41 public sign-up \u0c06\u0c2a\u0c3f\u0c35\u0c41\u0c02\u0c26\u0c3f - \u0c2a\u0c4d\u0c30\u0c38\u0c4d\u0c24\u0c41\u0c24\u0c02 \u0c07\u0c2a\u0c4d\u0c2a\u0c1f\u0c3f\u0c15\u0c47 confirmed accounts \u0c2e\u0c3e\u0c24\u0c4d\u0c30\u0c2e\u0c47 log in \u0c1a\u0c47\u0c2f\u0c17\u0c32\u0c35\u0c41.'],
      ['Safarnama \u0c2d\u0c3e\u0c30\u0c24\u0c26\u0c47\u0c36\u0c02 \u0c2e\u0c4a\u0c24\u0c4d\u0c24\u0c3e\u0c28\u0c4d\u0c28\u0c3f \u0c15\u0c35\u0c30\u0c4d \u0c1a\u0c47\u0c38\u0c4d\u0c24\u0c41\u0c02\u0c26\u0c3e?', '12 \u0c21\u0c46\u0c38\u0c4d\u0c1f\u0c3f\u0c28\u0c47\u0c37\u0c28\u0c4d \u0c15\u0c3e\u0c30\u0c4d\u0c21\u0c4d\u0c32\u0c41 \u0c0e\u0c02\u0c1a\u0c41\u0c15\u0c41\u0c28\u0c4d\u0c28\u0c35\u0c3f, \u0c15\u0c3e\u0c28\u0c40 \u0c38\u0c40\u0c1c\u0c28\u0c4d \u0c17\u0c48\u0c21\u0c4d 28 \u0c30\u0c3e\u0c37\u0c4d\u0c1f\u0c4d\u0c30\u0c3e\u0c32\u0c41, 8 \u0c2f\u0c42\u0c28\u0c3f\u0c2f\u0c28\u0c4d \u0c2a\u0c4d\u0c30\u0c3e\u0c02\u0c24\u0c3e\u0c32\u0c28\u0c4d\u0c28\u0c40 \u0c15\u0c35\u0c30\u0c4d \u0c1a\u0c47\u0c38\u0c4d\u0c24\u0c41\u0c02\u0c26\u0c3f. \u0c2a\u0c02\u0c21\u0c41\u0c17 \u0c24\u0c47\u0c26\u0c40\u0c32\u0c41 \u0c1a\u0c3e\u0c02\u0c26\u0c4d\u0c30 \u0c15\u0c4d\u0c2f\u0c3e\u0c32\u0c46\u0c02\u0c21\u0c30\u0c4d\u200c\u0c28\u0c3f \u0c05\u0c28\u0c41\u0c38\u0c30\u0c3f\u0c38\u0c4d\u0c24\u0c3e\u0c2f\u0c3f - \u0c2a\u0c4d\u0c30\u0c2f\u0c3e\u0c23\u0c3e\u0c28\u0c3f\u0c15\u0c3f \u0c2e\u0c41\u0c02\u0c26\u0c41 \u0c27\u0c43\u0c35\u0c40\u0c15\u0c30\u0c3f\u0c02\u0c1a\u0c02\u0c21\u0c3f.']
    ] },
  kn: { label: '\u0c95\u0ca8\u0ccd\u0ca8\u0ca1 (Kannada)', dir: 'ltr', langLabel: '\u0cad\u0cbe\u0cb7\u0cc6',
    title: '\u0caa\u0ccd\u0cb0\u0cb6\u0ccd\u0ca8\u0cc6\u0c97\u0cb3\u0cbf\u0c97\u0cc6 \u0c89\u0ca4\u0ccd\u0ca4\u0cb0\u0c97\u0cb3\u0cc1',
    note: '\u0c88 FAQ \u0c85\u0ca8\u0ccd\u0ca8\u0cc1 \u0c87\u0c82\u0c97\u0ccd\u0cb2\u0cbf\u0cb7\u0ccd\u200c\u0ca8\u0cb2\u0ccd\u0cb2\u0cbf \u0c85\u0ca5\u0cb5\u0cbe \u0cad\u0cbe\u0cb0\u0ca4\u0ca6 22 \u0caa\u0c82\u0c95\u0ccd\u0ca4\u0cbf\u0c95\u0cb3\u0ccd\u0cb3\u0cb2\u0cbe\u0c97\u0cbf\u0ca6 \u0cad\u0cbe\u0cb7\u0cc6\u0c97\u0cb3\u0cb2\u0ccd\u0cb2\u0cbf \u0c93\u0ca6\u0cbf (\u0cb8\u0c82\u0cb5\u0cbf\u0ca7\u0cbe\u0ca8\u0ca6 \u0c8e\u0c82\u0c9f\u0ca8\u0cc7 \u0c85\u0ca8\u0cc1\u0cb8\u0cc2\u0c9a\u0cbf)\u0c85. \u0c87\u0c82\u0c97\u0ccd\u0cb2\u0cbf\u0cb7\u0ccd \u0cb9\u0cb3\u0cb5\u0cbe\u0c97\u0cbf AI \u0cb8\u0cb9\u0cbe\u0caf\u0ca6\u0cbf\u0c82\u0ca6 \u0c85\u0ca8\u0cc1\u0cb5\u0cbe\u0ca6\u0cbf\u0cb8\u0cb2\u0cbe\u0c97\u0cbf\u0ca6\u0cc6, \u0cb5\u0cbe\u0cb0\u0ccd\u0ca4\u0ccd\u0ca4\u0cbf\u0c95\u0cb5\u0cbe\u0c97\u0cbf \u0caa\u0cb0\u0cbf\u0cb6\u0cc0\u0cb2\u0cbf\u0cb8\u0cb2\u0cbe\u0c97\u0cbf\u0cb2\u0ccd\u0cb2; \u0c87\u0c82\u0c97\u0ccd\u0cb2\u0cbf\u0cb7\u0ccd \u0caa\u0cbe\u0ca0\u0cb5\u0cc7 \u0cae\u0cc2\u0cb2 \u0c86\u0ca7\u0cbe\u0cb0\u0c85.',
    items: [
      ['Safarnama\u0ca6\u0cb2\u0ccd\u0cb2\u0cbf \u0cab\u0ccd\u0cb2\u0cc8\u0c9f\u0ccd, \u0cb9\u0cca\u0c9f\u0cc7\u0cb2\u0ccd \u0c85\u0ca5\u0cb5\u0cbe \u0cb0\u0cc6\u0cb8\u0ccd\u0c9f\u0cbe\u0cb0\u0cc6\u0c82\u0c9f\u0ccd \u0cac\u0cc1\u0c95\u0ccd \u0cae\u0cbe\u0ca1\u0cac\u0cb9\u0cc1\u0ca6\u0cc7?', '\u0c87\u0cb2\u0ccd\u0cb2\u0c85. Safarnama \u0c92\u0c82\u0ca6\u0cc1 \u0cab\u0ccd\u0cb0\u0c82\u0c9f\u0ccd-\u0c8e\u0c82\u0ca1\u0ccd \u0c9f\u0ccd\u0cb0\u0ccd\u0cb0\u0cbe\u0cb5\u0cc6\u0cb2\u0ccd \u0ca1\u0cc6\u0cae\u0ccb - \u0c87\u0cb2\u0ccd\u0cb2\u0cbf \u0c8f\u0ca8\u0cc2 \u0cac\u0cc1\u0c95\u0ccd, \u0cb0\u0cbf\u0c9c\u0cb0\u0ccd\u0cb5\u0ccd \u0c85\u0ca5\u0cb5\u0cbe \u0c9a\u0cbe\u0cb0\u0ccd\u0c9c\u0ccd \u0c86\u0c97\u0cc1\u0cb5\u0cc1\u0ca6\u0cbf\u0cb2\u0ccd\u0cb2\u0c85. \u0cb9\u0cc6\u0cb8\u0cb0\u0cc1\u0c97\u0cb3\u0cc1 \u0c85\u0cb5\u0cc1\u0c97\u0cb3 \u0cb2\u0cc8\u0cb5\u0ccd \u0cb2\u0cbf\u0cb8\u0ccd\u0c9f\u0cbf\u0c82\u0c97\u0ccd\u200c\u0c97\u0cb3\u0cbf\u0c97\u0cc6 \u0cb2\u0cbf\u0c82\u0c95\u0ccd \u0c86\u0c97\u0cbf\u0cb5\u0cc6\u0c85.'],
      ['\u0c88 \u0cb8\u0cc8\u0c9f\u0ccd\u200c\u0ca8\u0cb2\u0ccd\u0cb2\u0cbf\u0cb0\u0cc1\u0cb5 \u0cab\u0ccd\u0cb2\u0cc8\u0c9f\u0ccd \u0ca6\u0cb0\u0c97\u0cb3\u0cc1 \u0cb2\u0cc8\u0cb5\u0ccd\u200c\u0c97\u0cb3\u0cc7?', '\u0c87\u0cb2\u0ccd\u0cb2\u0c85. \u0c87\u0cb5\u0cc1 \u0ca8\u0cbf\u0c9c\u0cb5\u0cbe\u0ca6 \u0cac\u0cc1\u0c95\u0cbf\u0c82\u0c97\u0ccd \u0cb8\u0cb0\u0ccd\u0c9a\u0ccd (Duffel) \u0caf\u0cbf\u0c82\u0ca6 30 \u0c85\u0c95\u0ccd\u0c9f\u0ccb\u0cac\u0cb0\u0ccd 2026 \u0cb0\u0c82\u0ca6\u0cc1 \u0ca4\u0cc6\u0c97\u0cc6\u0ca6\u0cc1\u0c95\u0cca\u0c82\u0ca1 \u0c89\u0ca6\u0cbe\u0cb9\u0cb0\u0ca3\u0cc6\u0c97\u0cb3\u0cc1 - 28 \u0ca8\u0cb5\u0cc6\u0c82\u0cac\u0cb0\u0ccd 2026 \u0cb5\u0ca8\u0ccd-\u0cb5\u0cc7 \u0c8e\u0c95\u0cbe\u0ca8\u0cae\u0cbf \u0c97\u0cbe\u0c97\u0cbf, USD \u0ca8\u0cb2\u0ccd\u0cb2\u0cbf\u0c85. \u0ca6\u0cb0\u0c97\u0cb3\u0cc1 \u0caa\u0ccd\u0cb0\u0ca4\u0cbf\u0ca8\u0cbf\u0ca4\u0ccd\u0caf\u0cc1 \u0cac\u0ca6\u0cb2\u0cbe\u0c97\u0cc1\u0ca4\u0ccd\u0ca4\u0cb5\u0cc6 - \u0caa\u0ccd\u0cb0\u0caf\u0cbe\u0ca3\u0c95\u0ccd\u0c95\u0cc6 \u0cae\u0cc1\u0ca8\u0ccd\u0c9a\u0cc6 \u0cae\u0ca4\u0ccd\u0ca4\u0cc6 \u0caa\u0cb0\u0cbf\u0cb6\u0cc0\u0cb2\u0cbf\u0cb8\u0cbf\u0c85.'],
      ['\u0cb5\u0cc6\u0c9c\u0ccd, \u0ca8\u0cbe\u0ca8\u0ccd-\u0cb5\u0cc6\u0c9c\u0ccd \u0cae\u0ca4\u0ccd\u0ca4\u0cc1 \u0cb5\u0cc0\u0c97\u0ca8\u0ccd \u0c9f\u0ccd\u0cb0\u0cbe\u0c97\u0ccd\u200c\u0c97\u0cb3 \u0c85\u0cb0\u0ccd\u0ca5\u0cb5\u0cc7\u0ca8\u0cc1?', '\u0c85\u0cb5\u0cc1 \u0caa\u0ccd\u0cb0\u0ca4\u0cbf \u0c85\u0ca1\u0cc1\u0c97\u0cc6\u0caf \u0cb8\u0cbe\u0c82\u0caa\u0ccd\u0cb0\u0ca6\u0cbe\u0caf\u0cbf\u0c95 \u0cb0\u0cc6\u0cb8\u0cbf\u0caa\u0cbf\u0caf\u0ca8\u0ccd\u0ca8\u0cc1 \u0cb9\u0cc7\u0cb3\u0cc1\u0ca4\u0ccd\u0ca4\u0cb5\u0cc6, \u0c92\u0c82\u0ca6\u0cc1 \u0c85\u0ca1\u0cc1\u0c97\u0cc6\u0cae\u0ca8\u0cc6\u0caf \u0cb5\u0cbf\u0ca7\u0cbe\u0ca8\u0cb5\u0ca8\u0ccd\u0ca8\u0cb2\u0ccd\u0cb2\u0c85. \u0cb5\u0cc6\u0c9c\u0ccd/\u0cb5\u0cc0\u0c97\u0ca8\u0ccd \u0c9f\u0ccd\u0cb0\u0cbe\u0c97\u0ccd \u0c87\u0cb0\u0cc1\u0cb5\u0cc1\u0ca6\u0cb0\u0cb2\u0ccd\u0cb2\u0cbf\u0caf\u0cc2 \u0ca4\u0cc1\u0caa\u0caa\u0caa, \u0cac\u0cc6\u0c82\u0c9f\u0cc6 \u0c85\u0ca5\u0cb5\u0cbe \u0c95\u0ccd\u0cb0\u0cc0\u0cae\u0ccd \u0c87\u0cb0\u0cb2\u0cbf\u0c85 - \u0c86\u0cb0\u0ccd\u0ca1\u0cb0\u0ccd \u0cae\u0cbe\u0ca1\u0cc1\u0cb5 \u0cae\u0cc1\u0ca8\u0ccd\u0c9a\u0cc6 \u0c95\u0cc7\u0cb3\u0cbf\u0c85.'],
      ['\u0cb0\u0cc6\u0cb8\u0ccd\u0c9f\u0cbe\u0cb0\u0cc6\u0c82\u0c9f\u0ccd, \u0cb9\u0cca\u0c9f\u0cc7\u0cb2\u0ccd \u0cb0\u0cc7\u0c9f\u0cbf\u0c82\u0c97\u0ccd\u200c\u0c97\u0cb3\u0cc1 \u0c8e\u0cb2\u0ccd\u0cb2\u0cbf\u0c82\u0ca6 \u0cac\u0cb0\u0cc1\u0ca4\u0ccd\u0ca4\u0cb5\u0cc6?', '\u0cb8\u0ccd\u0c9f\u0cbe\u0cb0\u0ccd \u0cb0\u0cc7\u0c9f\u0cbf\u0c82\u0c97\u0ccd\u200c\u0c97\u0cb3\u0cc1 Google Maps \u0caf\u0cbf\u0c82\u0ca6, 1 \u0ca8\u0cb5\u0cc6\u0c82\u0cac\u0cb0\u0ccd 2026 \u0c95\u0ccd\u0c95\u0cc6 \u0caa\u0cb0\u0cbf\u0cb6\u0cc0\u0cb2\u0cbf\u0cb8\u0cb2\u0cbe\u0c97\u0cbf\u0cb5\u0cc6; \u0ca6\u0c83\u0ca2\u0cc0\u0c95\u0cb0\u0cbf\u0cb8\u0cbf\u0ca6 \u0c9a\u0cb2\u0c95\u0ccd\u0cb7\u0ca3\u0c97\u0cb3\u0cb2\u0ccd\u0cb2\u0cbf Tripadvisor \u0cb8\u0cc7\u0cb0\u0cbf\u0ca6\u0cbf\u0ca6\u0cc6\u0c85. \u0cb0\u0cc7\u0c9f\u0cbf\u0c82\u0c97\u0ccd\u200c\u0c97\u0cb3\u0cc1 \u0c95\u0cbe\u0cb2\u0cbe\u0ca8\u0cc1\u0c95\u0ccd\u0cb0\u0cae\u0cc6\u0ca3 \u0cac\u0ca6\u0cb2\u0cbe\u0c97\u0cc1\u0ca4\u0ccd\u0ca4\u0cb5\u0cc6 - \u0cb8\u0ccd\u0ca8\u0ccd\u0cb0\u0cbe\u0caa\u0ccd\u0cb7\u0cbe\u0c9f\u0ccd \u0c8e\u0c82\u0ca6\u0cc1 \u0c87\u0c9f\u0c86\u0c97\u0cbf\u0c95\u0cca\u0cb3\u0ccd\u0cb3\u0cbf\u0c85.'],
      ['\u0cb9\u0cca\u0c9f\u0cc7\u0cb2\u0ccd \u0ca6\u0cb0\u0c97\u0cb3\u0cc7\u0c95\u0cc6 \u0c87\u0cb2\u0ccd\u0cb2, \u0cb5\u0ccd\u0cb0\u0ccd\u0caf\u0cc2\u0c97\u0cc6 \u0c97\u0cbe\u0cb0\u0c82\u0c9f\u0cbf \u0c87\u0ca6\u0cc6\u0caf\u0cc7?', '\u0cac\u0c9c\u0cc6\u0c9f\u0ccd \u0cb8\u0ccd\u0c9f\u0cc7\u0c97\u0cb3 \u0ca6\u0cb0\u0c97\u0cb3\u0cc1 \u0ca6\u0cbf\u0ca8\u0cb5\u0cc2 \u0cac\u0ca6\u0cb2\u0cbe\u0c97\u0cc1\u0ca4\u0ccd\u0ca4\u0cb5\u0cc6, \u0c86\u0ca6\u0cb0\u0cc6 \u0ca4\u0ccb\u0cb0\u0cbf\u0cb8\u0cb2\u0cbe\u0c97\u0cbf\u0cb2\u0ccd\u0cb2\u0c85 - \u0cb2\u0cc8\u0cb5\u0ccd \u0cb2\u0cbf\u0cb8\u0ccd\u0c9f\u0cbf\u0c82\u0c97\u0ccd \u0ca4\u0cc6\u0cb0\u0cc6\u0caf\u0cb2\u0cc1 \u0cb8\u0ccd\u0c9f\u0cc7\u0caf\u0ca8\u0ccd\u0ca8\u0cc1 \u0c9f\u0ccd\u0cb0\u0cbe\u0caa\u0ccd \u0cae\u0cbe\u0ca1\u0cbf\u0c85. \u0c89\u0cb2\u0ccd\u0cb2\u0cc7\u0c96\u0cbf\u0cb8\u0cbf\u0ca6 \u0cb5\u0ccd\u0cb0\u0ccd\u0caf\u0cc2 \u0c86 \u0caa\u0ccd\u0cb0\u0cbe\u0caa\u0caa\u0cb0\u0ccd\u0c9f\u0cbf\u0caf \u0cb8\u0ccd\u0cb5\u0c82\u0ca4 \u0cb2\u0cbf\u0cb8\u0ccd\u0c9f\u0cbf\u0c82\u0c97\u0ccd\u200c\u0caf\u0cbf\u0c82\u0ca6 \u0cac\u0c82\u0ca6\u0cbf\u0ca6\u0cc6; \u0c95\u0ca5\u0ca6\u0cbf\u0c97\u0cb3\u0cc1 \u0cac\u0cc7\u0cb0\u0cc6\u0cac\u0cc7\u0cb0\u0cc6 - \u0cac\u0cc1\u0c95\u0cbf\u0c82\u0c97\u0ccd\u200c\u0c97\u0cc6 \u0cae\u0cc1\u0ca8\u0ccd\u0c9a\u0cc6 \u0c87\u0ca4\u0ccd\u0ca4\u0cc0\u0c9a\u0cbf\u0ca8 \u0cb0\u0cbf\u0cb5\u0ccd\u0cb0\u0ccd\u0caf\u0cc2 \u0cab\u0cca\u0c9f\u0ccb\u0c97\u0cb3\u0ca8\u0ccd\u0ca8\u0cc1 \u0ca8\u0ccb\u0ca1\u0cbf\u0c85.'],
      ['Log in \u0cac\u0c9f\u0ca8\u0ccd \u0ca8\u0cbf\u0c9c\u0cb5\u0cbe\u0ca6 \u0c96\u0cbe\u0ca4\u0cc6\u0caf\u0cc7?', '\u0cb9\u0ccc\u0ca6\u0cc1. Log in \u0c88\u0c97 \u0ca8\u0cbf\u0c9c\u0cb5\u0cbe\u0ca6 email \u0cae\u0ca4\u0ccd\u0ca4\u0cc1 password \u0cae\u0cc2\u0cb2\u0c95 \u0ca8\u0ca1\u0cc6\u0caf\u0cc1\u0ca4\u0ccd\u0ca4\u0ca6\u0cc6, \u0c85\u0ca6\u0ca8\u0ccd\u0ca8\u0cc1 Supabase auth \u0cb8\u0cc7\u0cb5\u0cc6 \u0caa\u0cb0\u0cbf\u0cb6\u0cc0\u0cb2\u0cbf\u0cb8\u0cc1\u0ca4\u0ccd\u0ca4\u0ca6\u0cc6. project \u0c97\u0cc6 email sender \u0cb8\u0c82\u0caa\u0cb0\u0ccd\u0c95\u0c97\u0cca\u0cb3\u0ccd\u0cb3\u0cc1\u0cb5\u0cb5\u0cb0\u0cc6\u0c97\u0cc6 public sign-up \u0ca8\u0cbf\u0cb2\u0ccd\u0cb2\u0cbf\u0cb8\u0cb2\u0cbe\u0c97\u0cbf\u0ca6\u0cc6 - \u0c88\u0c97 \u0c88\u0c97\u0cb2\u0cc7 confirmed accounts \u0cae\u0cbe\u0ca4\u0ccd\u0cb0 log in \u0cae\u0cbe\u0ca1\u0cac\u0cb9\u0cc1\u0ca6\u0cc1.'],
      ['Safarnama \u0cad\u0cbe\u0cb0\u0ca4\u0cb5\u0ca8\u0ccd\u0ca8\u0cc1 \u0caa\u0cc2\u0cb0\u0ccd\u0ca4\u0cbf\u0c97\u0cc6 \u0c95\u0cb5\u0cb0\u0ccd \u0cae\u0cbe\u0ca1\u0cc1\u0ca4\u0ccd\u0ca4\u0ca6\u0cc6\u0caf?', '12 \u0ca1\u0cc6\u0cb8\u0ccd\u0c9f\u0cbf\u0ca8\u0cc7\u0cb6\u0ca8\u0ccd \u0c95\u0cbe\u0cb0\u0ccd\u0ca1\u0ccd\u200c\u0c97\u0cb3\u0cc1 \u0c86\u0caf\u0ccd\u0ca6\u0cb5\u0cc1, \u0c86\u0ca6\u0cb0\u0cc6 \u0cb8\u0cc0\u0c9c\u0ca8\u0ccd \u0c97\u0cc8\u0ca1\u0ccd 28 \u0cb0\u0cbe\u0c9c\u0ccd\u0caf\u0c97\u0cb3\u0cc1 \u0cae\u0ca4\u0ccd\u0ca4\u0cc1 8 \u0c95\u0cc7\u0c82\u0ca6\u0ccd\u0cb0\u0cbe\u0ca7\u0cc0\u0ca8 \u0caa\u0ccd\u0cb0\u0ca6\u0cc7\u0cb6\u0c97\u0cb3\u0ca8\u0ccd\u0ca8\u0cc1 \u0c92\u0cb3\u0c97\u0cca\u0c82\u0ca1\u0cbf\u0ca6\u0cbf\u0ca6\u0cc6\u0c85. \u0cb9\u0cac\u0ccd\u0cac\u0c97\u0cb3 \u0ca6\u0cbf\u0ca8\u0cbe\u0c82\u0c95\u0c97\u0cb3\u0cc1 \u0cb9\u0cc6\u0c9a\u0ccd\u0c9a\u0cbe\u0c97\u0cbf \u0c9a\u0cbe\u0c82\u0ca6\u0ccd\u0cb0 \u0c95\u0ccd\u0cb0\u0cbe\u0cb2\u0cc6\u0c82\u0ca1\u0cb0\u0ccd\u200c\u0c85\u0ca8\u0ccd\u0ca8\u0cc1 \u0c85\u0ca8\u0cc1\u0cb8\u0cb0\u0cbf\u0cb8\u0cc1\u0ca4\u0ccd\u0ca4\u0cb5\u0cc6 - \u0caa\u0ccd\u0cb0\u0caf\u0cbe\u0ca3\u0c95\u0ccd\u0c95\u0cc6 \u0cae\u0cc1\u0ca8\u0ccd\u0c9a\u0cc6 \u0ca6\u0c83\u0ca2\u0cc0\u0c95\u0cb0\u0cbf\u0cb8\u0cbf\u0c85.']
    ] },
  ml: { label: '\u0d2e\u0d32\u0d2f\u0d3e\u0d33\u0d02 (Malayalam)', dir: 'ltr', langLabel: '\u0d2d\u0d3e\u0d37',
    title: '\u0d1a\u0d4b\u0d26\u0d4d\u0d2f\u0d19\u0d4d\u0d19\u0d33\u0d41\u0d15\u0d4d\u0d15\u0d41\u0d33\u0d4d\u0d33 \u0d09\u0d24\u0d4d\u0d24\u0d30\u0d19\u0d4d\u0d19\u0d33\u0d4d',
    note: '\u0d08 FAQ \u0d07\u0d02\u0d17\u0d4d\u0d32\u0d40\u0d37\u0d3f\u0d32\u0d4b \u0d07\u0d28\u0d4d\u0d24\u0d4d\u0d2f\u0d2f\u0d41\u0d1f\u0d46 22 \u0d2a\u0d31\u0d24\u0d3f\u0d2f\u0d3f\u0d30\u0d3f\u0d15\u0d4d\u0d15\u0d41\u0d28\u0d4d\u0d28 \u0d2d\u0d3e\u0d37\u0d15\u0d33\u0d3f\u0d32\u0d4b \u0d35\u0d3e\u0d2f\u0d3f\u0d15\u0d4d\u0d15\u0d3e\u0d02 (\u0d2d\u0d30\u0d23\u0d18\u0d1f\u0d28\u0d46\u0d2f\u0d41\u0d1f\u0d46 \u0d0e\u0d1f\u0d4d\u0d1f\u0d3e\u0d2e\u0d24\u0d4d\u0d24\u0d46 \u0d36\u0d46\u0d21\u0d4d\u0d2f\u0d42\u0d33\u0d4d)\u0d41. \u0d07\u0d02\u0d17\u0d4d\u0d32\u0d40\u0d37\u0d4d \u0d15\u0d34\u0d3f\u0d1e\u0d4d\u0d1e\u0d41\u0d33\u0d4d\u0d33 \u0d35\u0d3f\u0d2c\u0d3e\u0d37\u0d15\u0d33\u0d4d AI \u0d38\u0d39\u0d3e\u0d2f\u0d24\u0d4d\u0d24\u0d4b\u0d1f\u0d46 \u0d28\u0d3f\u0d30\u0d4d\u0d2e\u0d4d\u0d2e\u0d3f\u0d1a\u0d4d\u0d1a\u0d35\u0d2f\u0d3e\u0d23\u0d4d, \u0d15\u0d4d\u0d30\u0d24\u0d3f\u0d2a\u0d30\u0d2e\u0d3e\u0d2f \u0d2a\u0d30\u0d3f\u0d36\u0d4b\u0d27\u0d28 \u0d28\u0d1f\u0d4d\u0d1f\u0d3f\u0d32\u0d4d\u0d32; \u0d07\u0d02\u0d17\u0d4d\u0d32\u0d40\u0d37\u0d4d \u0d2a\u0d3e\u0d20\u0d2e\u0d3e\u0d23\u0d4d \u0d05\u0d27\u0d3f\u0d15\u0d3e\u0d30\u0d3f\u0d15\u0d02\u0d41.',
    items: [
      ['Safarnama-\u0d2f\u0d3f\u0d32\u0d4d \u0d2b\u0d4d\u0d32\u0d48\u0d31\u0d4d\u0d31\u0d4d, \u0d39\u0d4b\u0d1f\u0d4d\u0d1f\u0d32\u0d4d, \u0d31\u0d38\u0d4d\u0d24\u0d4b\u0d31\u0d28\u0d4d\u0d31\u0d4d \u0d2c\u0d41\u0d15\u0d4d\u0d15\u0d4d \u0d1a\u0d46\u0d2f\u0d4d\u0d2f\u0d3e\u0d2e\u0d4b?', '\u0d07\u0d32\u0d4d\u0d32\u0d41. \u0d07\u0d24\u0d4d \u0d12\u0d30\u0d41 \u0d2b\u0d4d\u0d30\u0d28\u0d4d\u0d31\u0d4d-\u0d0e\u0d28\u0d4d\u0d21\u0d4d \u0d1f\u0d4d\u0d30\u0d3e\u0d35\u0d32\u0d4d \u0d21\u0d46\u0d2e\u0d4b \u0d2e\u0d3e\u0d24\u0d4d\u0d30\u0d2e\u0d3e\u0d23\u0d4d - \u0d07\u0d35\u0d3f\u0d1f\u0d46 \u0d12\u0d28\u0d4d\u0d28\u0d41\u0d02 \u0d2c\u0d41\u0d15\u0d4d\u0d15\u0d4b \u0d31\u0d3f\u0d38\u0d47\u0d7c\u0d35\u0d4b \u0d1a\u0d3e\u0d7c\u0d1c\u0d4b \u0d1a\u0d46\u0d2f\u0d4d\u0d2f\u0d3f\u0d32\u0d4d\u0d32\u0d41. \u0d2a\u0d47\u0d30\u0d41\u0d15\u0d33\u0d4d \u0d05\u0d35\u0d2f\u0d41\u0d1f\u0d46 \u0d32\u0d48\u0d35\u0d4d \u0d32\u0d3f\u0d38\u0d4d\u0d31\u0d4d\u0d31\u0d3f\u0d02\u0d17\u0d3f\u0d32\u0d47\u0d15\u0d4d\u0d15\u0d4d \u0d32\u0d3f\u0d02\u0d15\u0d4d \u0d1a\u0d46\u0d2f\u0d4d\u0d24\u0d3f\u0d30\u0d3f\u0d15\u0d4d\u0d15\u0d41\u0d28\u0d4d\u0d28\u0d41\u0d41.'],
      ['\u0d08 \u0d38\u0d48\u0d31\u0d4d\u0d31\u0d3f\u0d32\u0d46 \u0d2b\u0d4d\u0d32\u0d48\u0d31\u0d4d\u0d31\u0d4d \u0d28\u0d3f\u0d32\u0d15\u0d33\u0d4d \u0d32\u0d48\u0d35\u0d4d \u0d06\u0d23\u0d4b?', '\u0d05\u0d32\u0d4d\u0d32\u0d41. \u0d07\u0d35 \u0d12\u0d30\u0d41 \u0d35\u0d3e\u0d38\u0d4d\u0d24\u0d35\u0d2e\u0d3e\u0d2f \u0d2c\u0d41\u0d15\u0d4d\u0d15\u0d3f\u0d02\u0d17\u0d4d \u0d24\u0d3f\u0d30\u0d1a\u0d3f\u0d32\u0d3f\u0d32\u0d4d \u0d28\u0d3f\u0d28\u0d4d\u0d28\u0d41\u0d33\u0d4d\u0d33 (Duffel) \u0d24\u0d40\u0d2f\u0d24\u0d3f\u0d2f\u0d41\u0d33\u0d4d\u0d33 \u0d09\u0d26\u0d3e\u0d39\u0d30\u0d23\u0d19\u0d4d\u0d19\u0d33\u0d3e\u0d23\u0d4d - 30 \u0d12\u0d15\u0d4d\u0d1f\u0d4b\u0d2c\u0d7c 2026-\u0d32\u0d4d 28 \u0d28\u0d35\u0d02\u0d2c\u0d7c 2026-\u0d28\u0d4d \u0d35\u0d28\u0d4d-\u0d35\u0d46 \u0d0e\u0d15\u0d4d\u0d15\u0d4b\u0d23\u0d2e\u0d3f\u0d15\u0d4d\u0d15\u0d3e\u0d2f\u0d3f, USD-\u0d2f\u0d3f\u0d32\u0d4d\u0d41. \u0d28\u0d3f\u0d32\u0d15\u0d33\u0d4d \u0d0e\u0d2a\u0d4d\u0d2a\u0d4b\u0d34\u0d41\u0d02 \u0d2e\u0d3e\u0d31\u0d41\u0d28\u0d4d\u0d28\u0d41 - \u0d2f\u0d3e\u0d24\u0d4d\u0d30\u0d15\u0d4d\u0d15\u0d41 \u0d2e\u0d41\u0d2e\u0d4d\u0d2a\u0d4d \u0d35\u0d40\u0d23\u0d4d\u0d1f\u0d41\u0d02 \u0d2a\u0d30\u0d3f\u0d36\u0d4b\u0d27\u0d3f\u0d15\u0d4d\u0d15\u0d41\u0d15\u0d41.'],
      ['\u0d35\u0d46\u0d1c\u0d4d, \u0d28\u0d4b\u0d7a-\u0d35\u0d46\u0d1c\u0d4d, \u0d35\u0d40\u0d17\u0d7b \u0d1f\u0d4d\u0d2f\u0d3e\u0d17\u0d41\u0d15\u0d33\u0d4d\u200d\u0d15\u0d4d\u0d15\u0d4d \u0d0e\u0d28\u0d4d\u0d24\u0d3e\u0d23\u0d4d \u0d05\u0d7c\u0d25\u0d02?', '\u0d05\u0d35 \u0d13\u0d30\u0d4b \u0d35\u0d3e\u0d1f\u0d15\u0d4d\u0d15\u0d41\u0d1f\u0d46\u0d2f\u0d41\u0d02 \u0d2a\u0d30\u0d2e\u0d4d\u0d2a\u0d30\u0d3e\u0d17\u0d24 \u0d2a\u0d3e\u0d1a\u0d15\u0d35\u0d3f\u0d27\u0d24\u0d4d\u0d24\u0d46\u0d2f\u0d3e\u0d23\u0d4d \u0d38\u0d42\u0d1a\u0d3f\u0d2a\u0d4d\u0d2a\u0d3f\u0d15\u0d4d\u0d15\u0d41\u0d28\u0d4d\u0d28\u0d24\u0d4d, \u0d12\u0d30\u0d41 \u0d2a\u0d4a\u0d24\u0d41\u0d35\u0d3e\u0d2f \u0d05\u0d1f\u0d41\u0d15\u0d4d\u0d15\u0d33\u0d2f\u0d41\u0d1f\u0d46 \u0d30\u0d40\u0d24\u0d3f\u0d2f\u0d32\u0d4d\u0d32\u0d41. \u0d35\u0d46\u0d1c\u0d4d/\u0d35\u0d40\u0d17\u0d7b \u0d1f\u0d4d\u0d2f\u0d3e\u0d17\u0d41\u0d33\u0d4d\u0d33 \u0d35\u0d3e\u0d1f\u0d15\u0d33\u0d3f\u0d32\u0d41\u0d2a\u0d4b\u0d32\u0d41\u0d02 \u0d28\u0d46\u0d2f\u0d4d\u0d2f\u0d4d, \u0d35\u0d46\u0d23\u0d4d\u0d23, \u0d15\u0d4d\u0d30\u0d40\u0d02 \u0d09\u0d23\u0d4d\u0d1f\u0d3e\u0d15\u0d3e\u0d02 - \u0d13\u0d7c\u0d21\u0d7c \u0d1a\u0d46\u0d2f\u0d4d\u0d2f\u0d41\u0d28\u0d4d\u0d28\u0d24\u0d3f\u0d28\u0d4d \u0d2e\u0d41\u0d2e\u0d4d\u0d2a\u0d4d \u0d1a\u0d4b\u0d26\u0d3f\u0d15\u0d4d\u0d15\u0d41\u0d15\u0d41.'],
      ['\u0d31\u0d38\u0d4d\u0d24\u0d4b\u0d31\u0d28\u0d4d\u0d31\u0d4d, \u0d39\u0d4b\u0d1f\u0d4d\u0d1f\u0d32\u0d4d \u0d31\u0d47\u0d31\u0d4d\u0d31\u0d3f\u0d02\u0d17\u0d41\u0d15\u0d33\u0d4d\u200d \u0d0e\u0d35\u0d3f\u0d1f\u0d46 \u0d28\u0d3f\u0d28\u0d4d\u0d28\u0d3e\u0d23\u0d4d?', '\u0d38\u0d4d\u0d24\u0d3e\u0d7c \u0d31\u0d47\u0d31\u0d4d\u0d31\u0d3f\u0d02\u0d17\u0d41\u0d15\u0d33\u0d4d\u200d Google Maps-\u0d32\u0d4d \u0d28\u0d3f\u0d28\u0d4d\u0d28\u0d41\u0d23\u0d4d, 1 \u0d28\u0d35\u0d02\u0d2c\u0d7c 2026-\u0d32\u0d4d \u0d2a\u0d30\u0d3f\u0d36\u0d4b\u0d27\u0d3f\u0d1a\u0d4d\u0d1a\u0d24\u0d4d; \u0d38\u0d4d\u0d25\u0d3f\u0d30\u0d40\u0d15\u0d30\u0d3f\u0d1a\u0d4d\u0d1a \u0d07\u0d1f\u0d19\u0d4d\u0d19\u0d33\u0d3f\u0d32\u0d4d Tripadvisor-\u0d02 \u0d1a\u0d47\u0d7c\u0d24\u0d4d\u0d24\u0d3f\u0d1f\u0d4d\u0d1f\u0d41\u0d23\u0d4d\u0d1f\u0d4d. \u0d31\u0d47\u0d31\u0d4d\u0d31\u0d3f\u0d02\u0d17\u0d41\u0d15\u0d33\u0d4d\u200d \u0d15\u0d3e\u0d32\u0d3e\u0d28\u0d4d\u0d24\u0d30\u0d23\u0d2e\u0d46\u0d28 \u0d2e\u0d3e\u0d31\u0d41\u0d02 - \u0d12\u0d30\u0d41 \u0d38\u0d4d\u200c\u0d28\u0d3e\u0d2a\u0d4d\u200c\u0d37\u0d4b\u0d1f\u0d4d\u0d1f\u0d3e\u0d2f\u0d3f \u0d15\u0d23\u0d4d\u0d1f\u0d41\u0d15\u0d4a\u0d33\u0d4d\u0d33\u0d41\u0d15.'],
      ['\u0d39\u0d4b\u0d1f\u0d4d\u0d1f\u0d32\u0d4d \u0d28\u0d3f\u0d32\u0d15\u0d33\u0d4d \u0d0e\u0d28\u0d4d\u0d24\u0d3f\u0d28\u0d4d \u0d07\u0d32\u0d4d\u0d32, \u0d35\u0d4d\u0d2f\u0d42\u0d35\u0d3f\u0d28\u0d4d \u0d17\u0d3e\u0d31\u0d28\u0d4d\u0d31\u0d3f \u0d09\u0d23\u0d4d\u0d1f\u0d4b?', '\u0d2c\u0d1c\u0d4d\u0d1c\u0d31\u0d4d\u0d31\u0d4d \u0d24\u0d2e\u0d4d\u0d2a\u0d41\u0d15\u0d33\u0d41\u0d1f\u0d46 \u0d28\u0d3f\u0d32\u0d15\u0d33\u0d4d \u0d26\u0d3f\u0d28\u0d2e\u0d46\u0d28 \u0d2e\u0d3e\u0d31\u0d41\u0d28\u0d4d\u0d28\u0d24\u0d3e\u0d23\u0d4d, \u0d05\u0d24\u0d41\u0d15\u0d4a\u0d23\u0d4d\u0d1f\u0d4d \u0d12\u0d28\u0d4d\u0d28\u0d41\u0d02 \u0d15\u0d3e\u0d23\u0d3f\u0d1a\u0d4d\u0d1a\u0d3f\u0d1f\u0d4d\u0d1f\u0d3f\u0d32\u0d4d\u0d32 - \u0d32\u0d48\u0d35\u0d4d \u0d32\u0d3f\u0d38\u0d4d\u0d31\u0d4d\u0d31\u0d3f\u0d02\u0d17\u0d4d \u0d24\u0d3f\u0d31\u0d15\u0d4d\u0d15\u0d3e\u0d28\u0d4d \u0d38\u0d4d\u0d24\u0d3e\u0d28\u0d24\u0d4d\u0d24\u0d4d \u0d1f\u0d4d\u0d2f\u0d3e\u0d2a\u0d4d\u0d2a\u0d4d \u0d1a\u0d46\u0d2f\u0d4d\u0d2f\u0d41\u0d15. \u0d2a\u0d31\u0d1e\u0d4d\u0d1e\u0d3f\u0d30\u0d3f\u0d15\u0d4d\u0d15\u0d41\u0d28\u0d4d\u0d28 \u0d35\u0d4d\u0d2f\u0d42 \u0d06 \u0d2a\u0d4d\u0d30\u0d4a\u0d2a\u0d4d\u0d2a\u0d7c\u0d1f\u0d4d\u0d1f\u0d3f\u0d2f\u0d41\u0d1f\u0d46 \u0d38\u0d4d\u0d35\u0d28\u0d4d\u0d24\u0d02 \u0d32\u0d3f\u0d38\u0d4d\u0d31\u0d4d\u0d31\u0d3f\u0d02\u0d17\u0d3f\u0d32\u0d4d \u0d28\u0d3f\u0d28\u0d4d\u0d28\u0d3e\u0d23\u0d4d; \u0d2e\u0d41\u0d31\u0d3f\u0d15\u0d33\u0d4d \u0d35\u0d3f\u0d2d\u0d3f\u0d28\u0d4d\u0d28\u0d2e\u0d3e\u0d02 - \u0d2c\u0d41\u0d15\u0d4d\u0d15\u0d3f\u0d02\u0d17\u0d3f\u0d28\u0d4d \u0d2e\u0d41\u0d2e\u0d4d\u0d2a\u0d4d \u0d2a\u0d41\u0d24\u0d3f\u0d2f \u0d05\u0d35\u0d32\u0d4b\u0d15\u0d28 \u0d1a\u0d3f\u0d24\u0d4d\u0d30\u0d19\u0d4d\u0d19\u0d33\u0d4d \u0d28\u0d4b\u0d15\u0d4d\u0d15\u0d41\u0d15.'],
      ['Log in \u0d2c\u0d1f\u0d4d\u0d1f\u0d7b \u0d36\u0d30\u0d3f\u0d2f\u0d3e\u0d2f \u0d05\u0d15\u0d4d\u0d15\u0d4c\u0d23\u0d4d\u0d1f\u0d3e\u0d23\u0d4b?', '\u0d05\u0d24\u0d46. Log in \u0d07\u0d2a\u0d4d\u0d2a\u0d4b\u0d7e \u0d2f\u0d25\u0d3e\u0d7c\u0d24\u0d4d\u0d25 email-\u0d09\u0d02 password-\u0d09\u0d02 \u0d09\u0d2a\u0d2f\u0d4b\u0d17\u0d3f\u0d1a\u0d4d\u0d1a\u0d3e\u0d23\u0d4d, \u0d05\u0d24\u0d4d Supabase auth \u0d38\u0d47\u0d35\u0d28\u0d02 \u0d2a\u0d30\u0d3f\u0d36\u0d4b\u0d27\u0d3f\u0d15\u0d4d\u0d15\u0d41\u0d28\u0d4d\u0d28\u0d41. project-\u0d2e\u0d3e\u0d2f\u0d3f email sender \u0d2c\u0d28\u0d4d\u0d27\u0d3f\u0d15\u0d4d\u0d15\u0d41\u0d28\u0d4d\u0d28\u0d24\u0d41\u0d35\u0d30\u0d46 public sign-up \u0d28\u0d3f\u0d7c\u0d24\u0d4d\u0d24\u0d3f\u0d2f\u0d3f\u0d30\u0d3f\u0d15\u0d4d\u0d15\u0d41\u0d28\u0d4d\u0d28\u0d41 - \u0d07\u0d2a\u0d4d\u0d2a\u0d4b\u0d7e \u0d28\u0d47\u0d30\u0d24\u0d4d\u0d24\u0d46 \u0d24\u0d28\u0d4d\u0d28\u0d46 confirmed accounts-\u0d15\u0d4d\u0d15\u0d4d \u0d2e\u0d3e\u0d24\u0d4d\u0d30\u0d2e\u0d47 log in \u0d1a\u0d46\u0d2f\u0d4d\u0d2f\u0d3e\u0d7b \u0d15\u0d34\u0d3f\u0d2f\u0d42.'],
      ['Safarnama \u0d07\u0d28\u0d4d\u0d24\u0d4d\u0d2f \u0d2e\u0d41\u0d34\u0d41\u0d35\u0d28\u0d41\u0d02 \u0d15\u0d35\u0d7c \u0d1a\u0d46\u0d2f\u0d4d\u0d2f\u0d41\u0d28\u0d4d\u0d28\u0d41\u0d24\u0d4b?', '12 \u0d21\u0d46\u0d38\u0d4d\u0d31\u0d4d\u0d31\u0d3f\u0d28\u0d47\u0d37\u0d7b \u0d15\u0d3e\u0d7c\u0d21\u0d41\u0d15\u0d33\u0d4d\u200d \u0d24\u0d3f\u0d30\u0d1e\u0d4d\u0d1e\u0d46\u0d1f\u0d41\u0d15\u0d4d\u0d15\u0d41\u0d15\u0d2a\u0d46\u0d1f\u0d4d\u0d1f\u0d35\u0d2f\u0d3e\u0d23\u0d4d, \u0d0e\u0d28\u0d4d\u0d24\u0d3e\u0d32\u0d41\u0d02 \u0d38\u0d40\u0d38\u0d7b \u0d17\u0d48\u0d21\u0d4d 28 \u0d38\u0d02\u0d38\u0d4d\u0d25\u0d3e\u0d28\u0d19\u0d4d\u0d19\u0d33\u0d46\u0d2f\u0d41\u0d02 8 \u0d15\u0d47\u0d28\u0d4d\u0d26\u0d4d\u0d30\u0d2d\u0d30\u0d23 \u0d2a\u0d4d\u0d30\u0d26\u0d47\u0d36\u0d19\u0d4d\u0d19\u0d33\u0d46\u0d2f\u0d41\u0d02 \u0d15\u0d35\u0d7c \u0d1a\u0d46\u0d2f\u0d4d\u0d2f\u0d41\u0d28\u0d4d\u0d28\u0d41\u0d41. \u0d05\u0d28\u0d4d\u0d28\u0d3f\u0d15 \u0d24\u0d3f\u0d30\u0d41\u0d28\u0d3e\u0d33\u0d41\u0d15\u0d33\u0d41\u0d1f\u0d46 \u0d24\u0d40\u0d2f\u0d24\u0d3f\u0d15\u0d33\u0d4d \u0d1a\u0d28\u0d4d\u0d26\u0d4d\u0d30 \u0d15\u0d33\u0d23\u0d4d\u0d1f\u0d31\u0d3f\u0d32\u0d4d \u0d06\u0d27\u0d3e\u0d30\u0d3f\u0d15\u0d4d\u0d15\u0d41\u0d28\u0d4d\u0d28\u0d41 - \u0d2f\u0d3e\u0d24\u0d4d\u0d30\u0d15\u0d4d\u0d15\u0d41 \u0d2e\u0d41\u0d2e\u0d4d\u0d2a\u0d4d \u0d38\u0d4d\u0d25\u0d3f\u0d30\u0d40\u0d15\u0d30\u0d3f\u0d15\u0d4d\u0d15\u0d41\u0d15\u0d41.']
    ] },
  or: { label: '\u0b13\u0b21\u0b3c\u0b3f\u0b06 (Odia)', dir: 'ltr', langLabel: '\u0b2d\u0b3e\u0b37\u0b3e',
    title: '\u0b2a\u0b4d\u0b30\u0b36\u0b4d\u0b28\u0b17\u0b41\u0b21\u0b3c\u0b3f\u0b15\u0b30 \u0b09\u0b24\u0b4d\u0b24\u0b30',
    note: '\u0b0f\u0b39 FAQ \u0b15\u0b41 \u0b07\u0b02\u0b30\u0b3e\u0b1c\u0b40 \u0b15\u0b3f\u0b2e\u0b4d\u0b2c\u0b3e \u0b2d\u0b3e\u0b30\u0b24\u0b30 22\u0b1f\u0b3f \u0b05\u0b28\u0b41\u0b38\u0b42\u0b1a\u0b3f\u0b24 \u0b2d\u0b3e\u0b37\u0b3e\u0b30\u0b47 \u0b2a\u0b22\u0b3c\u0b28\u0b4d\u0b24\u0b41 (\u0b38\u0b02\u0b2c\u0b3f\u0b27\u0b3e\u0b28\u0b30 \u0b05\u0b37\u0b4d\u0b1f\u0b2e \u0b05\u0b28\u0b41\u0b38\u0b42\u0b1a\u0b40)\u0964 \u0b07\u0b02\u0b30\u0b3e\u0b1c\u0b40 \u0b2c\u0b3e\u0b39\u0b3e\u0b30\u0b47 \u0b05\u0b28\u0b41\u0b2c\u0b3e\u0b26\u0b17\u0b41\u0b21\u0b3c\u0b3f\u0b15 AI \u0b38\u0b39\u0b3e\u0b2f\u0b24\u0b3e\u0b30\u0b47 \u0b2a\u0b4d\u0b30\u0b38\u0b4d\u0b24\u0b41\u0b24; \u0b2c\u0b48\u0b36\u0b3f\u0b15 \u0b2a\u0b30\u0b40\u0b15\u0b4d\u0b37\u0b23 \u0b39\u0b4b\u0b07\u0b28\u0b3e\u0b39\u0b3f\u0b01; \u0b07\u0b02\u0b30\u0b3e\u0b1c\u0b40 \u0b2a\u0b3e\u0b20 \u0b39\u0b3f\u0b01 \u0b2e\u0b42\u0b33 \u0b38\u0b28\u0b4d\u0b26\u0b30\u0b4d\u0b2d\u0964',
    items: [
      ['Safarnama\u0b30\u0b47 \u0b2e\u0b41\u0b01 \u0b2b\u0b4d\u0b32\u0b3e\u0b07\u0b1f\u0b4d, \u0b39\u0b4b\u0b1f\u0b47\u0b32\u0b4d \u0b15\u0b3f\u0b2e\u0b4d\u0b2c\u0b3e \u0b30\u0b47\u0b38\u0b4d\u0b1f\u0b41\u0b30\u0b3e\u0b01\u0b1f\u0b4d \u0b2c\u0b41\u0b15\u0b4d \u0b15\u0b30\u0b3f\u0b2a\u0b3e\u0b30\u0b3f\u0b2c\u0b3f \u0b15\u0b3f?', '\u0b28\u0b1c\u0b3e\u0b01\u0964 Safarnama \u0b17\u0b4b\u0b1f\u0b3f\u0b0f \u0b2b\u0b4d\u0b30\u0b28\u0b4d\u0b1f-\u0b0f\u0b23\u0b4d\u0b21 \u0b1f\u0b4d\u0b30\u0b3e\u0b2d\u0b47\u0b32\u0b4d \u0b21\u0b47\u0b2e\u0b4b - \u0b0f\u0b20\u0b3f \u0b15\u0b3f\u0b1b\u0b3f \u0b2c\u0b41\u0b15\u0b4d, \u0b30\u0b3f\u0b1c\u0b30\u0b4d\u0b2d \u0b15\u0b3f\u0b2e\u0b4d\u0b2c\u0b3e \u0b1a\u0b3e\u0b30\u0b4d\u0b1c \u0b39\u0b1b\u0b41 \u0b28\u0b3e\u0b39\u0b3f\u0b01\u0964 \u0b28\u0b3e\u0b2e\u0b17\u0b41\u0b21\u0b3c\u0b3f\u0b15 \u0b38\u0b47\u0b19\u0b41\u0b21\u0b3c\u0b3f\u0b15\u0b30 \u0b32\u0b3e\u0b07\u0b2d\u0b4d \u0b32\u0b3f\u0b38\u0b4d\u0b1f\u0b3f\u0b02\u0b17\u0b15\u0b41 \u0b32\u0b3f\u0b19\u0b4d\u0b15\u0b4d \u0b39\u0b4b\u0b07\u0b1b\u0b3f\u0964'],
      ['\u0b0f\u0b39 \u0b38\u0b3e\u0b07\u0b1f\u0b30\u0b47 \u0b2b\u0b4d\u0b32\u0b3e\u0b07\u0b1f\u0b4d \u0b2d\u0b3e\u0b5c\u0b3e\u0b17\u0b41\u0b21\u0b3c\u0b3f\u0b15 \u0b32\u0b3e\u0b07\u0b2d\u0b4d \u0b05\u0b1f\u0b47 \u0b15\u0b3f?', '\u0b28\u0b1c\u0b3e\u0b01\u0964 \u0b0f\u0b19\u0b41\u0b21\u0b3c\u0b3f\u0b15 \u0b17\u0b4b\u0b1f\u0b3f\u0b0f \u0b2a\u0b4d\u0b30\u0b3e\u0b15\u0b43\u0b24 \u0b2c\u0b41\u0b15\u0b3f\u0b02\u0b17 \u0b38\u0b30\u0b4d\u0b1a (Duffel)\u0b30\u0b41 30 \u0b05\u0b15\u0b4d\u0b1f\u0b4b\u0b2c\u0b30 2026\u0b30\u0b47 \u0b28\u0b47\u0b06\u0b1c\u0b3e\u0b07\u0b25\u0b3f\u0b2c\u0b3e \u0b24\u0b3f\u0b28\u0b3e\u0b19\u0b15\u0b3f\u0b24 \u0b09\u0b26\u0b3e\u0b39\u0b30\u0b23 - 28 \u0b28\u0b2d\u0b47\u0b2e\u0b4d\u0b2c\u0b30 2026 \u0b35\u0b28\u0b4d-\u0b13\u0b0f \u0b07\u0b15\u0b28\u0b2e\u0b3f \u0b2a\u0b3e\u0b07\u0b01, USD\u0b30\u0b47\u0964 \u0b2e\u0b42\u0b32\u0b4d\u0b2f \u0b38\u0b30\u0b4d\u0b2c\u0b26\u0b3e \u0b2c\u0b26\u0b33\u0b47 - \u0b2f\u0b3e\u0b24\u0b4d\u0b30\u0b3e \u0b2a\u0b42\u0b30\u0b4d\u0b2c\u0b30\u0b41 \u0b2a\u0b41\u0b28\u0b30\u0b47 \u0b2f\u0b3e\u0b01\u0b1a \u0b15\u0b30\u0b28\u0b4d\u0b24\u0b41\u0964'],
      ['\u0b2d\u0b47\u0b1c\u0b4d, \u0b28\u0b28\u0b4d-\u0b2d\u0b47\u0b1c\u0b4d \u0b0f\u0b2c\u0b02 \u0b2d\u0b40\u0b17\u0b3e\u0b28\u0b4d \u0b1f\u0b4d\u0b30\u0b3e\u0b17\u0b47\u0b30 \u0b05\u0b30\u0b4d\u0b25 \u0b15\u0b47\u0b23?', '\u0b0f\u0b19\u0b41\u0b21\u0b3c\u0b3f\u0b15 \u0b2a\u0b4d\u0b30\u0b24\u0b4d\u0b2f\u0b47\u0b15 \u0b3e\u0b4b\u0b17\u0b3e\u0b30\u0b30 \u0b2a\u0b30\u0b2e\u0b4d\u0b2a\u0b30\u0b3e\u0b17\u0b24 \u0b30\u0b47\u0b38\u0b3f\u0b2a\u0b3f \u0b26\u0b30\u0b4d\u0b36\u0b3e\u0b07\u0b28\u0b4d\u0b24\u0b3f, \u0b17\u0b4b\u0b1f\u0b3f\u0b0f \u0b28\u0b3f\u0b30\u0b4d\u0b26\u0b3f\u0b37\u0b4d\u0b1f \u0b30\u0b4b\u0b37\u0b47\u0b07\u0b18\u0b30\u0b30 \u0b2a\u0b26\u0b4d\u0b27\u0b24\u0b3f \u0b28\u0b41\u0b39\u0b1b\u0b01\u0964 \u0b2d\u0b47\u0b1c\u0b4d/\u0b2d\u0b40\u0b17\u0b3e\u0b28\u0b4d \u0b1f\u0b4d\u0b30\u0b3e\u0b17\u0b4d \u0b25\u0b3f\u0b2c\u0b3e \u0b3e\u0b4b\u0b17\u0b3e\u0b30\u0b30\u0b47 \u0b2e\u0b27\u0b4d\u0b2f \u0b18\u0b3f\u0b05, \u0b2e\u0b16\u0b28 \u0b15\u0b3f\u0b2e\u0b4d\u0b2c\u0b3e \u0b15\u0b4d\u0b30\u0b3f\u0b2e\u0b4d \u0b2a\u0b21\u0b3c\u0b3f\u0b2a\u0b3e\u0b30\u0b47 - \u0b05\u0b30\u0b4d\u0b21\u0b30 \u0b15\u0b30\u0b3f\u0b2c\u0b3e \u0b2a\u0b42\u0b30\u0b4d\u0b2c\u0b30\u0b41 \u0b2a\u0b1a\u0b3e\u0b30\u0b28\u0b4d\u0b24\u0b41\u0964'],
      ['\u0b30\u0b47\u0b38\u0b4d\u0b1f\u0b41\u0b30\u0b3e\u0b01\u0b1f\u0b4d \u0b0f\u0b2c\u0b02 \u0b39\u0b4b\u0b1f\u0b47\u0b32\u0b4d \u0b30\u0b47\u0b1f\u0b3f\u0b02\u0b17 \u0b15\u0b4b\u0b1c\u0b41 \u0b06\u0b38\u0b47?', '\u0b38\u0b4d\u0b1f\u0b3e\u0b30 \u0b30\u0b47\u0b1f\u0b3f\u0b02\u0b17 Google Maps\u0b30\u0b41, 1 \u0b28\u0b2d\u0b47\u0b2e\u0b4d\u0b2c\u0b30 2026\u0b30\u0b47 \u0b2f\u0b3e\u0b01\u0b1a \u0b15\u0b30\u0b3e\u0b1c\u0b3e\u0b07\u0b1b\u0b3f; \u0b28\u0b3f\u0b36\u0b4d\u0b1a\u0b3f\u0b24 \u0b38\u0b4d\u0b25\u0b3e\u0b28\u0b30\u0b47 Tripadvisor \u0b2e\u0b27\u0b4d\u0b2f \u0b2f\u0b4b\u0b1c\u0b3e\u0b07\u0b1b\u0b3f\u0964 \u0b30\u0b47\u0b1f\u0b3f\u0b02\u0b17 \u0b38\u0b2e\u0b2f \u0b38\u0b39 \u0b2c\u0b26\u0b33\u0b47 - \u0b0f\u0b39\u0b3e\u0b15\u0b41 \u0b38\u0b4d\u0b28\u0b3e\u0b2a\u0b38\u0b1f\u0b4d \u0b2d\u0b3e\u0b2c\u0b4d\u0b2c\u0b3e \u0b1c\u0b3e\u0b01\u0b1a \u0b15\u0b30\u0b28\u0b4d\u0b24\u0b41, \u0b17\u0b3e\u0b30\u0b23\u0b4d\u0b1f\u0b3f \u0b28\u0b41\u0b39\u0b1b\u0b01\u0964'],
      ['\u0b39\u0b4b\u0b1f\u0b47\u0b32\u0b4d \u0b2e\u0b42\u0b32\u0b4d\u0b2f \u0b15\u0b47\u0b01\u0b1c\u0b3f \u0b28\u0b3e\u0b39\u0b3f\u0b01, \u0b2d\u0b3f\u0b09\u0b47\u0b30 \u0b17\u0b3e\u0b30\u0b23\u0b4d\u0b1f\u0b3f \u0b05\u0b1b\u0b3f \u0b15\u0b3f?', '\u0b2c\u0b1c\u0b47\u0b1f\u0b4d \u0b38\u0b4d\u0b1f\u0b47\u0b47\u0b30 \u0b2e\u0b42\u0b32\u0b4d\u0b2f \u0b2a\u0b4d\u0b30\u0b24\u0b3f\u0b26\u0b3f\u0b28 \u0b2c\u0b26\u0b33\u0b47, \u0b24\u0b3e\u0b39\u0b47\u0b01\u0b30\u0b41 \u0b15\u0b47\u0b39\u0b3f \u0b26\u0b30\u0b4d\u0b36\u0b3e\u0b07\u0b1a\u0b3e \u0b28\u0b3e\u0b39\u0b3f\u0b01 - \u0b32\u0b3e\u0b07\u0b2d\u0b4d \u0b32\u0b3f\u0b38\u0b4d\u0b1f\u0b3f\u0b02\u0b17 \u0b16\u0b4b\u0b32\u0b3f\u0b2c\u0b3e \u0b2a\u0b3e\u0b07\u0b01 \u0b38\u0b4d\u0b1f\u0b47\u0b15\u0b41 \u0b1f\u0b4d\u0b30\u0b3e\u0b2a\u0b4d \u0b15\u0b30\u0b28\u0b4d\u0b24\u0b41\u0964 \u0b09\u0b32\u0b4d\u0b32\u0b47\u0b16\u0b3f\u0b24 \u0b2d\u0b3f\u0b09\u0b47 \u0b38\u0b47\u0b39 \u0b38\u0b2e\u0b4d\u0b2a\u0b24\u0b4d\u0b24\u0b3f\u0b30 \u0b28\u0b3f\u0b1c\u0b38\u0b4d\u0b35 \u0b32\u0b3f\u0b38\u0b4d\u0b1f\u0b3f\u0b02\u0b17\u0b30\u0b41 \u0b06\u0b38\u0b3f\u0b1b\u0b3f; \u0b15\u0b20\u0b30\u0b40\u0b17\u0b41\u0b21\u0b3c\u0b3f\u0b15 \u0b2d\u0b3f\u0b28\u0b4d\u0b28 \u0b39\u0b1b\u0b07\u0b2a\u0b3e\u0b30\u0b47 - \u0b2c\u0b41\u0b15\u0b3f\u0b02\u0b17 \u0b2a\u0b42\u0b30\u0b4d\u0b2c\u0b30\u0b41 \u0b38\u0b2e\u0b0d\u0b2a\u0b4d\u0b30\u0b24\u0b3e\u0b2f\u0b3f\u0b15 \u0b30\u0b3f\u0b2d\u0b3f\u0b09\u0b47 \u0b2b\u0b1f\u0b4b\u0b17\u0b41\u0b21\u0b3c\u0b3f\u0b15 \u0b26\u0b47\u0b16\u0b28\u0b4d\u0b24\u0b41\u0964'],
      ['Log in \u0b2c\u0b1f\u0b28\u0b4d \u0b17\u0b4b\u0b1f\u0b3f\u0b0f \u0b2a\u0b4d\u0b30\u0b3e\u0b15\u0b43\u0b24 \u0b06\u0b15\u0b3e\u0b09\u0b23\u0b4d\u0b1f \u0b05\u0b1f\u0b47 \u0b15\u0b3f?', '\u0b39\u0b01\u0964 Log in \u0b2c\u0b30\u0b4d\u0b24\u0b4d\u0b24\u0b2e\u0b3e\u0b28 \u0b2a\u0b4d\u0b30\u0b15\u0b43\u0b24 email \u0b0f\u0b2c\u0b02 password \u0b2e\u0b3e\u0b27\u0b4d\u0b5f\u0b2e\u0b30\u0b47 \u0b39\u0b41\u0b0f, \u0b2f\u0b3e\u0b39\u0b3e\u0b15\u0b41 Supabase auth \u0b38\u0b47\u0b2c\u0b3e \u0b2f\u0b3e\u0b1e\u0b4d\u0b1a \u0b15\u0b30\u0b47\u0964 project \u0b38\u0b39\u0b3f\u0b24 email sender \u0b2f\u0b4b\u0b21\u0b3c\u0b3e \u0b28 \u0b39\u0b47\u0b32\u0b3e \u0b2a\u0b30\u0b4d\u0b2f\u0b4d\u0b5f\u0b28\u0b4d\u0b24 public sign-up \u0b2c\u0b28\u0b4d\u0b26 \u0b05\u0b1b\u0b3f - \u0b2c\u0b30\u0b4d\u0b24\u0b4d\u0b24\u0b2e\u0b3e\u0b28 \u0b15\u0b47\u0b2c\u0b33 \u0b2a\u0b42\u0b30\u0b4d\u0b2c\u0b30\u0b41 confirmed accounts \u0b39\u0b3f\u0b01 log in \u0b15\u0b30\u0b3f\u0b2a\u0b3e\u0b30\u0b3f\u0b2c\u0b47\u0964'],
      ['Safarnama \u0b38\u0b2e\u0b17\u0b4d\u0b30 \u0b2d\u0b3e\u0b30\u0b24\u0b15\u0b41 \u0b15\u0b2d\u0b30 \u0b15\u0b30\u0b47 \u0b15\u0b3f?', '12\u0b1f\u0b3f \u0b21\u0b47\u0b38\u0b4d\u0b1f\u0b3f\u0b28\u0b47\u0b36\u0b28\u0b4d \u0b15\u0b3e\u0b30\u0b4d\u0b21 \u0b2c\u0b3e\u0b1b\u0b3e\u0b07\u0b1a\u0b3e \u0b39\u0b4b\u0b07\u0b1b\u0b3f, \u0b15\u0b3f\u0b28\u0b4d\u0b24\u0b41 \u0b38\u0b3f\u0b1c\u0b28\u0b4d \u0b17\u0b3e\u0b07\u0b21\u0b4d 28 \u0b30\u0b3e\u0b1c\u0b4d\u0b2f \u0b0f\u0b2c\u0b02 8 \u0b15\u0b47\u0b28\u0b4d\u0b26\u0b4d\u0b30\u0b36\u0b3e\u0b38\u0b3f\u0b24 \u0b2a\u0b4d\u0b30\u0b26\u0b47\u0b36\u0b15\u0b41 \u0b15\u0b2d\u0b30 \u0b15\u0b30\u0b47\u0964 \u0b2a\u0b3e\u0b30\u0b4d\u0b2c\u0b23\u0b30 \u0b24\u0b3f\u0b28\u0b3e\u0b19\u0b15 \u0b1a\u0b28\u0b4d\u0b26\u0b4d\u0b30 \u0b2a\u0b1e\u0b4d\u0b1c\u0b3f\u0b15\u0b3e\u0b15\u0b41 \u0b05\u0b28\u0b41\u0b38\u0b30\u0b23 \u0b15\u0b30\u0b47 \u0b0f\u0b2c\u0b02 \u0b2a\u0b4d\u0b30\u0b24\u0b3f\u0b2c\u0b30\u0b4d\u0b37 \u0b2c\u0b26\u0b33\u0b47 - \u0b2f\u0b3e\u0b24\u0b4d\u0b30\u0b3e \u0b2a\u0b42\u0b30\u0b4d\u0b2c\u0b30\u0b41 \u0b28\u0b3f\u0b36\u0b4d\u0b1a\u0b2f \u0b15\u0b30\u0b28\u0b4d\u0b24\u0b41'],
    ] },
  as: { label: 'অসমীয়া (Assamese)', dir: 'ltr', langLabel: 'ভাষা',
    title: 'প্ৰশ্ন আৰু উত্তৰ',
    note: 'এই FAQ ইংৰাজী বা ভাৰতৰ 22টা অনুসূচিত ভাষাত পঢ়ক (সংবিধানৰ অষ্টম অনুসূচী)। ইংৰাজীৰ বাহিৰে অনুবাদসমূহ AI-ৰ সহায়ত কৰা, বিশেষভাৱে পৰীক্ষা কৰা হোৱা নাই; ইংৰাজী পাঠেই মূল।',
    items: [
      ['Safarnama-ত মই ফ্লাইট, হোটেল বা ৰেষ্টুৰেণ্ট বুক কৰিব পাৰোনে?', 'নোৱাৰো। এইটো এটা ফ্ৰণ্ট-এণ্ড ট্ৰাভেল ডেমো - ইয়াত একো বুক, ৰিজাৰ্ভ বা চাৰ্জ কৰা নহয়। নামবোৰ সিহঁতৰ লাইভ লিষ্টিংৰ সৈতে লিংক কৰা হৈছে।'],
      ['ছাইটত দেখুওৱা ফ্লাইটৰ ভাড়া লাইভ নেকি?', 'নহয়। এইবোৰ সঁচা বুকিং বিচাৰণা (Duffel)-ৰ পৰা 30 অক্টোবৰ 2026-ত লোৱা নমুনা - 28 নৱেম্বৰ 2026-ৰ বাবে এক-দিশীয় ইকনমী, USD-ত। মূল্য সদায় সলনি হয় - যাত্ৰাৰ আগতে আকৌ চাওক।'],
      ['ভেজ, নন-ভেজ, ভেগান টেগবোৰৰ অৰ্থ কি?', 'এইবোৰে প্ৰতিটো খাদ্যৰ পাৰম্পৰিক ঢং দেখুৱায়, কোনো এটা ৰন্ধনীৰ প্ৰণালী নহয়। veg/vegan টেগ নথকা খাদ্যতো ঘী, মাখন বা ক্ৰিম থাকিব পাৰে - অৰ্ডাৰ কৰাৰ আগতে সোধক।'],
      ['ৰেষ্টুৰেণ্ট আৰু হোটেলৰ ৰেইটিংৰ উৎস কি?', 'তৰকাৰ ৰেইটিং Google Maps-ৰ পৰা, 1 নৱেম্বৰ 2026-ত পৰীক্ষা কৰা; যেতিয়া সম্ভব হৈছে Tripadvisor-ও উল্লেখ আছে। ৰেইটিং সময়ৰ লগে লগে সলনি হয় - এইটো স্নেপশ্বট বুলি বিবেচনা কৰক, গাৰেণ্টী নহয়।'],
      ['হোটেলৰ মূল্য কিয় দেখুওৱা হোৱা নাই, ভিউৰ গাৰেণ্টী আছে নে?', 'বাজেট ষ্টেৰ মূল্য প্ৰতিদিনে সলনি হয়, সেইবাবে দেখুওৱা হোৱা নাই - লাইভ লিষ্টিং খুলিবলৈ টেপ কৰক। দেখুওৱা ভিউ প্ৰপাৰ্টিৰ নিজৰ লিষ্টিংৰ পৰা; কোঠাবোৰ বেলেগ হব পাৰে - বুকিং কৰাৰ আগতে শেহতীয়া ৰিভিউৰ ফটো চাওক।'],
      ['Log in বুটামটো সঁচা একাউণ্ট নেকি?', '\u09b9\u09af\u09bc\u0964 Log in \u098f\u09a4\u09bf\u09af\u09bc\u09be \u09aa\u09cd\u09f0\u0995\u09c3\u09a4 email \u0986\u09f0\u09c1 password\u09c7\u09f0\u09c7 \u09b9\u09af\u09bc, \u09af\u09be\u0995 Supabase auth \u09b8\u09c7\u09f1\u09be\u0987 \u09aa\u09f0\u09c0\u0995\u09cd\u09b7\u09be \u0995\u09f0\u09c7\u0964 project\u09f0 \u09b8\u09c8\u09a4\u09c7 email sender \u09b8\u0982\u09af\u09cb\u0997 \u09a8\u09cb\u09b9\u09cb\u09f1\u09be\u09b2\u09c8\u0995\u09c7 public sign-up \u09ac\u09a8\u09cd\u09a7 \u0986\u099b\u09c7 - \u098f\u09a4\u09bf\u09af\u09bc\u09be \u0995\u09c7\u09f1\u09b2 \u0986\u0997\u09a4\u09c0\u09af\u09bc\u09be\u0995\u09c8 confirmed accounts-\u098f\u09b9\u09c7 log in \u0995\u09f0\u09bf\u09ac \u09aa\u09be\u09f0\u09c7\u0964'],
      ['Safarnama-এ গোটেই ভাৰতক কভাৰ কৰে নে?', '12টা গন্তব্য কাৰ্ড বাছনি কৰা হৈছে, কিন্তু ঋতু গাইডে 28খন ৰাজ্য আৰু 8খন কেন্দ্ৰ শাসিত প্ৰদেশক কভাৰ কৰে। উৎসৱৰ তাৰিখবোৰ চান্দ্ৰ পঞ্জিকা অনুসৰি - যাত্ৰাৰ আগতে নিশ্চিত কৰক।']
    ] },
  ne: { label: '\u0928\u0947\u092a\u093e\u0932\u0940 (Nepali)', dir: 'ltr', langLabel: '\u092d\u093e\u0937\u093e',
    title: '\u092a\u094d\u0930\u0936\u094d\u0928\u0939\u0930\u0942\u0915\u094b \u091c\u0935\u093e\u092b',
    note: '\u092f\u0938 FAQ \u0932\u093e\u0908 \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u0940 \u0935\u093e \u092d\u093e\u0930\u0924\u0915\u093e 22 \u0905\u0928\u0942\u0938\u0942\u091a\u093f\u0924 \u092d\u093e\u0937\u093e\u0939\u0930\u0942\u092e\u093e \u092a\u0922\u094d\u0928\u0941\u0939\u094b\u0938\u094d (\u0938\u0902\u0935\u093f\u0927\u093e\u0928\u0915\u094b \u0906\u0920\u094c\u0902 \u0905\u0928\u0941\u0938\u0942\u091a\u0940)\u0964 \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u0940 \u092c\u093e\u0939\u0947\u0915\u0915\u093e \u0905\u0928\u0941\u0935\u093e\u0926 AI \u0938\u0939\u093e\u092f\u0924\u093e\u0932\u0947 \u092c\u0928\u093e\u0907\u090f\u0915\u093e \u0939\u0941\u0928\u094d, \u0935\u094d\u092f\u093e\u0935\u0938\u093e\u092f\u093f\u0915 \u091c\u093e\u0901\u091a \u092d\u090f\u0915\u094b \u091b\u0948\u0928; \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u0940 \u092a\u093e\u0920 \u0928\u0948 \u0906\u0927\u093e\u0930 \u0939\u094b\u0964',
    items: [
      ['Safarnama \u092e\u093e \u092e\u0948\u0932\u0947 \u092b\u094d\u0932\u093e\u0907\u091f, \u0939\u094b\u091f\u0932 \u0935\u093e \u0930\u0947\u0938\u094d\u091f\u0941\u0930\u0947\u0928\u094d\u091f \u092c\u0941\u0915 \u0917\u0930\u094d\u0928 \u0938\u0915\u094d\u091b\u0941 \u0924?', '\u0939\u0941\u0901\u0926\u0948\u0928\u0964 \u092f\u094b \u090f\u0915 \u092b\u094d\u0930\u0928\u094d\u091f-\u090f\u0928\u094d\u0921 \u091f\u094d\u0930\u094d\u092f\u093e\u092d\u0932 \u0921\u0947\u092e\u094b \u0939\u094b - \u092f\u0939\u093e\u0901 \u0915\u0947\u0939\u0940 \u092c\u0941\u0915, \u0930\u093f\u091c\u0930\u094d\u0935 \u0935\u093e \u091a\u093e\u0930\u094d\u091c \u0939\u0941\u0901\u0926\u0948\u0928\u0964 \u0928\u093e\u092e\u0939\u0930\u0942 \u0924\u0940 \u0938\u094d\u0925\u093e\u0928\u0939\u0930\u0942\u0915\u094b \u0932\u093e\u0907\u0935 \u0932\u093f\u0938\u094d\u091f\u093f\u0919\u0924\u093f\u0930 \u0932\u093f\u0919\u094d\u0915 \u0917\u0930\u093f\u090f\u0915\u093e \u091b\u0928\u094d\u0964'],
      ['\u092f\u0938 \u0938\u093e\u0907\u091f\u092e\u093e \u092b\u094d\u0932\u093e\u0907\u091f \u092d\u093e\u0921\u093e \u0932\u093e\u0907\u0935 \u0939\u094b?', '\u0939\u094b\u0907\u0928\u0964 \u092f\u0940 \u0935\u093e\u0938\u094d\u0924\u0935\u093f\u0915 \u092c\u0941\u0915\u093f\u0919 \u0916\u094b\u091c (Duffel) \u092c\u093e\u091f 30 \u0905\u0915\u094d\u091f\u094b\u092c\u0930 2026 \u092e\u093e \u0932\u093f\u090f\u0915\u093e \u092e\u093f\u0924\u093f\u0938\u0939\u093f\u0924\u0915\u093e \u0909\u0926\u093e\u0939\u0930\u0923 \u0939\u0941\u0928\u094d - 28 \u0928\u094b\u092d\u0947\u092e\u094d\u092c\u0930 2026 \u0915\u093e \u0935\u0928-\u0935\u0947 \u0907\u0915\u0928\u094b\u092e\u0940\u0915\u093e \u0932\u093e\u0917\u093f, USD \u092e\u093e\u0964 \u092e\u0942\u0932\u094d\u092f \u0938\u0930\u094d\u0926\u0930 \u092b\u0947\u0930\u093f\u0928\u094d\u091b - \u092f\u093e\u0924\u094d\u0930\u093e \u0905\u0918\u093f \u092b\u0947\u0930\u093f \u091c\u093e\u0901\u091a\u094d\u0928\u0941\u0939\u094b\u0938\u094d\u0964'],
      ['\u092d\u0947\u091c, \u0928\u0928-\u092d\u0947\u091c, \u092d\u093f\u0917\u094d\u092f\u093e\u0928 \u091f\u094d\u092f\u093e\u0917\u0915\u094b \u092e\u0924\u0932\u092c \u0915\u0947 \u0939\u094b?', '\u0924\u0940 \u092a\u094d\u0930\u0924\u094d\u092f\u0947\u0915 \u092a\u0935\u0928\u0915\u094b \u092a\u0930\u092e\u094d\u092a\u0930\u093e\u0917\u0924 \u0930\u0947\u0938\u093f\u092a\u0940 \u0926\u0947\u0916\u093e\u0909\u091b\u0928\u094d, \u0915\u0941\u0928\u0948 \u090f\u0915 \u092d\u093e\u0928\u094d\u0938\u093e\u0918\u0930\u0915\u094b \u0924\u0930\u093f\u0915\u093e \u0939\u094b\u0907\u0928\u0964 \u092d\u0947\u091c/\u092d\u093f\u0917\u094d\u092f\u093e\u0928 \u091f\u094d\u092f\u093e\u0917 \u092d\u090f\u092a\u0928\u093f \u0918\u093f\u0909, \u092e\u0916\u094d\u0916\u0928 \u0935\u093e \u0915\u094d\u0930\u093f\u092e \u0939\u0941\u0928 \u0938\u0915\u094d\u091b - \u0905\u0930\u094d\u0921\u0930 \u0905\u0918\u093f \u0938\u094b\u0927\u094d\u0928\u0941\u0939\u094b\u0938\u094d\u0964'],
      ['\u0930\u0947\u0938\u094d\u091f\u0941\u0930\u0947\u0928\u094d\u091f, \u0939\u094b\u091f\u0932 \u0930\u0947\u091f\u093f\u0919 \u0915\u0939\u093e\u0901\u092c\u093e\u091f \u0906\u0909\u091b?', '\u0938\u094d\u091f\u093e\u0930 \u0930\u0947\u091f\u093f\u0919 Google Maps \u092c\u093e\u091f, 1 \u0928\u094b\u092d\u0947\u092e\u094d\u092c\u0930 2026 \u092e\u093e \u091c\u093e\u0901\u091a\u093f\u090f\u0915\u094b; \u092a\u0941\u0937\u094d\u091f\u093f \u092d\u090f\u0915\u093e \u0920\u093e\u0909\u0901\u092e\u093e Tripadvisor \u092a\u0928\u093f \u0925\u092a\u093f\u090f\u0915\u094b \u091b\u0964 \u0930\u0947\u091f\u093f\u0919 \u0938\u092e\u092f\u0938\u0901\u0917 \u092b\u0947\u0930\u093f\u0928\u094d\u091b - \u092f\u0938\u0932\u093e\u0908 \u0938\u094d\u0928\u094d\u092f\u093e\u092a\u0938\u091f \u091d\u0932\u094d\u091d\u093e \u0932\u093f\u0928\u0941\u0939\u094b\u0938\u094d, \u0917\u093e\u0930\u0928\u094d\u091f\u0940 \u0939\u094b\u0907\u0928\u0964'],
      ['\u0939\u094b\u091f\u0932\u0915\u093e \u092e\u0942\u0932\u094d\u092f \u0915\u093f\u0928 \u091b\u0948\u0928\u0928\u094d, \u0926\u0943\u0936\u094d\u092f\u0915\u094b \u0917\u093e\u0930\u0928\u094d\u091f\u0940 \u091b \u0924?', '\u092c\u091c\u0947\u091f \u0938\u094d\u091f\u0947\u0915\u093e \u092e\u0942\u0932\u094d\u092f \u0939\u0930\u0947\u0915 \u0926\u093f\u0928 \u092b\u0947\u0930\u093f\u0928\u094d\u091b\u0928\u094d, \u0924\u0947\u0938\u0948\u0932\u0947 \u0926\u0947\u0916\u093e\u0907\u090f\u0915\u094b \u091b\u0948\u0928 - \u0932\u093e\u0907\u0935 \u0932\u093f\u0938\u094d\u091f\u093f\u0919 \u0916\u094b\u0932\u094d\u0928 \u091f\u094d\u092f\u093e\u092a \u0917\u0930\u094d\u0928\u0941\u0939\u094b\u0938\u094d\u0964 \u0909\u0932\u094d\u0932\u0947\u0916 \u0917\u0930\u093f\u090f\u0915\u094b \u0926\u0943\u0936\u094d\u092f \u0924\u0940 \u0938\u092e\u094d\u092a\u0924\u094d\u0924\u093f\u0915\u094b \u0906\u092b\u094d\u0928\u0948 \u0932\u093f\u0938\u094d\u091f\u093f\u0919\u092c\u093e\u091f \u0939\u094b; \u0915\u094b\u0920\u093e \u092b\u0930\u0915 \u0939\u0941\u0928 \u0938\u0915\u094d\u091b - \u092c\u0941\u0915\u093f\u0919 \u0905\u0918\u093f \u0924\u093e\u091c\u093e \u0938\u092e\u0940\u0915\u094d\u0937\u093e \u092b\u094b\u091f\u094b \u0939\u0947\u0930\u094d\u0928\u0941\u0939\u094b\u0938\u094d\u0964'],
      ['Log in \u092c\u091f\u0928 \u0935\u093e\u0938\u094d\u0924\u0935\u093f\u0915 \u0916\u093e\u0924\u093e \u0939\u094b?', '\u0939\u094b\u0964 Log in \u0905\u092c \u0935\u093e\u0938\u094d\u0924\u0935\u093f\u0915 email \u0930 password \u092c\u093e\u091f \u0939\u0941\u0928\u094d\u091b, \u091c\u0938\u0932\u093e\u0908 Supabase auth \u0938\u0947\u0935\u093e\u0932\u0947 \u091c\u093e\u0901\u091a\u094d\u091b\u0964 project \u092e\u093e email sender \u091c\u094b\u0921\u093f\u090f\u0938\u092e\u094d\u092e public sign-up \u092c\u0928\u094d\u0926 \u091b - \u0905\u0939\u093f\u0932\u0947 \u092a\u0939\u093f\u0932\u094d\u092f\u0948 confirmed accounts \u0932\u0947 \u092e\u093e\u0924\u094d\u0930 log in \u0917\u0930\u094d\u0928 \u0938\u0915\u094d\u091b\u0928\u094d\u0964'],
      ['Safarnama \u0932\u0947 \u0938\u092e\u094d\u092a\u0942\u0930\u094d\u0923 \u092d\u093e\u0930\u0924 \u0938\u092e\u093e\u091f\u094d\u091b \u0924?', '12\u0935\u091f\u093e \u0921\u0947\u0938\u094d\u091f\u093f\u0928\u0947\u0938\u0928 \u0915\u093e\u0930\u094d\u0921 \u091b\u093e\u0928\u093f\u090f\u0915\u093e \u0939\u0941\u0928\u094d, \u0924\u0930 \u0938\u093f\u091c\u0928 \u0917\u093e\u0907\u0921\u0932\u0947 28 \u092a\u094d\u0930\u0926\u0947\u0936 \u0930 8 \u0938\u0902\u0918\u0940\u092f \u0936\u093e\u0938\u093f\u0924 \u0915\u094d\u0937\u0947\u0924\u094d\u0930 \u0938\u092e\u093e\u091f\u094d\u091b\u0964 \u091a\u093e\u0921\u092a\u0930\u094d\u0935\u0915\u093e \u092e\u093f\u0924\u093f \u091c\u094d\u092f\u093e\u0926\u093e\u0924\u0930 \u091a\u0928\u094d\u0926\u094d\u0930 \u092a\u093e\u0924\u094d\u0930\u094b \u0905\u0928\u0941\u0938\u093e\u0930 \u0939\u0941\u0928\u094d\u091b\u0928\u094d \u0930 \u0939\u0930\u0947\u0915 \u0935\u0930\u094d\u0937 \u0938\u0930\u094d\u091b\u0928\u094d - \u092f\u093e\u0924\u094d\u0930\u093e \u0905\u0918\u093f \u092a\u0941\u0937\u094d\u091f\u093f \u0917\u0930\u094d\u0928\u0941\u0939\u094b\u0938\u094d\u0964']
    ] },
  doi: { label: '\u0921\u094b\u0917\u0930\u0940 (Dogri)', dir: 'ltr', langLabel: '\u092d\u093e\u0936\u093e',
    title: '\u0938\u0935\u093e\u0932\u093e\u0902 \u0926\u0947 \u091c\u0935\u093e\u092c',
    note: '\u090f\u0939 FAQ \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u093c\u0940 \u091c\u093e\u0902 \u092d\u093e\u0930\u0924 \u0926\u094d\u092f\u093e\u0902 22 \u092d\u093e\u0936\u093e\u0935\u093e\u0902 \u091a \u092a\u0922\u093c\u094b (\u0938\u0902\u092c\u093f\u0927\u093e\u0928 \u0926\u0940 \u0905\u091f\u093c\u0935\u0940\u0902 \u0905\u0928\u0941\u0938\u0942\u091a\u0940)\u0964 \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u093c\u0940 \u0924\u0941\u0902 \u092c\u093e\u0926 \u0905\u0928\u0941\u0935\u093e\u0926 AI \u0926\u0940 \u092e\u0926\u0926 \u0928\u093e\u0932 \u092c\u0923\u0947 \u0917\u090f \u0939\u0948\u0902, \u092a\u0947\u0936\u0947\u0935\u0930 \u091c\u093e\u0902\u091a \u0928\u0939\u0940\u0902 \u0939\u094b\u0908; \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u093c\u0940 \u0939\u0940 \u0905\u0938\u0932\u0940 \u0939\u0948\u0964',
    items: [
      ['\u0915\u093f\u090d\u0902 \u092e\u0948\u0902 Safarnama \u0924\u0947 \u092b\u093c\u094d\u0932\u093e\u0907\u091f, \u0939\u094b\u091f\u0932 \u091c\u093e\u0902 \u0930\u0948\u0938\u094d\u091f\u094b\u0930\u093e\u0902 \u092c\u0941\u0915 \u0915\u0930 \u0938\u0915\u0926\u093e \u0906\u0902?', '\u0928\u0939\u0940\u0902\u0964 \u090f\u0939 \u0907\u0915\u094d\u0915 \u092b\u093c\u094d\u0930\u0902\u091f-\u090f\u0902\u0921 \u091f\u094d\u0930\u0948\u0935\u0932 \u0921\u0948\u092e\u094b \u0939\u0948 - \u0907\u0925\u0947 \u0915\u0941\u091d \u092d\u0940 \u092c\u0941\u0915, \u0930\u093f\u091c\u093c\u0930\u094d\u0935 \u091c\u093e\u0902 \u091a\u093e\u0930\u094d\u091c \u0928\u0939\u0940\u0902 \u0939\u0941\u0902\u0926\u093e\u0964 \u0928\u093e\u0902 \u0909\u0928\u094d\u0928\u093e\u0902 \u0926\u0940 \u0932\u093e\u0907\u0935 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0928\u0942\u0902 \u0932\u093f\u0902\u0915 \u0915\u093f\u0924\u0947 \u0917\u090f \u0939\u0948\u0902\u0964'],
      ['\u0907\u0938 \u0938\u093e\u0907\u091f \u0924\u0947 \u092b\u093c\u094d\u0932\u093e\u0907\u091f \u0926\u0947 \u092d\u093e\u0922\u093c\u0947 \u0932\u093e\u0907\u0935 \u0939\u0948\u0902?', '\u0928\u0939\u0940\u0902\u0964 \u090f\u0939 30 \u0905\u0915\u0924\u0942\u092c\u0930 2026 \u0928\u0942\u0902 \u0907\u0915\u094d\u0915 \u0905\u0938\u0932\u0940 \u092c\u0941\u0915\u093f\u0902\u0917 \u0938\u0930\u094d\u091a (Duffel) \u091a\u094b\u0902 \u0932\u0908\u0906\u0902 \u0917\u0908\u0906\u0902 \u0909\u0926\u093e\u0939\u0930\u0923\u093e\u0902 \u0939\u0928 - 28 \u0928\u0935\u0902\u092c\u0930 2026 \u0926\u0940 \u0935\u0928-\u0935\u0947 \u0907\u0915\u094b\u0928\u094b\u092e\u0940 \u0932\u0908, USD \u091a\u0964 \u0926\u093e\u092e \u0932\u0917\u093e\u0924\u093e\u0930 \u092c\u0926\u0932\u0926\u0947 \u0939\u0928 - \u0938\u092b\u093c\u0930 \u0924\u0941\u0902 \u092a\u0939\u0932\u093e\u0902 \u092b\u0947\u0930 \u091a\u0948\u0915 \u0915\u0930\u094b\u0964'],
      ['\u0935\u0948\u091c, \u0928\u0949\u0928-\u0935\u0948\u091c, \u0935\u0940\u0917\u0928 \u091f\u0948\u0917\u093e\u0902 \u0926\u093e \u092e\u0924\u0932\u092c \u0915\u093f\u090d\u0902?', '\u090f\u0939 \u0939\u0930 \u0926\u093f\u0936 \u0926\u0940 \u092a\u0941\u0930\u093e\u0928\u0940 \u0930\u0948\u0938\u093f\u092a\u0940 \u0926\u0938\u094d\u0938\u0926\u0947 \u0939\u0928, \u0915\u093f\u0938\u0947 \u0907\u0915\u094d\u0915 \u0930\u0938\u094b\u0908 \u0926\u093e \u0924\u0930\u0940\u0915\u093e \u0928\u0939\u0940\u0902\u0964 \u0935\u0948\u091c/\u0935\u0940\u0917\u0928 \u091f\u0948\u0917 \u0939\u094b\u090f \u0924\u093e\u0902 \u092d\u0940 \u0918\u0940, \u092e\u0915\u094d\u0916\u0923 \u091c\u093e\u0902 \u0915\u0930\u0940\u092e \u0939\u094b \u0938\u0915\u0926\u093e \u0939\u0948 - \u0911\u0930\u094d\u0921\u0930 \u0915\u0930\u0928 \u0924\u0941\u0902 \u092a\u0939\u0932\u093e\u0902 \u092a\u0941\u091a\u094d\u091b \u0932\u090f\u0902\u0964'],
      ['\u0930\u0948\u0938\u094d\u091f\u094b\u0930\u093e\u0902, \u0939\u094b\u091f\u0932\u093e\u0902 \u0926\u0940 \u0930\u0947\u091f\u093f\u0902\u0917 \u0915\u093f\u0925\u094b\u0902 \u0906\u0909\u0902\u0926\u0940 \u0939\u0948?', '\u0938\u091f\u093e\u0930 \u0930\u0947\u091f\u093f\u0902\u0917 Google Maps \u0924\u0941\u0902, 1 \u0928\u0935\u0902\u092c\u0930 2026 \u0928\u0942\u0902 \u091a\u0948\u0915 \u0915\u0940\u0924\u0940 \u0917\u0908; \u091c\u093f\u0925\u0947 \u092a\u0915\u094d\u0915\u093e \u0939\u094b\u090f \u0909\u0925\u0947 Tripadvisor \u092d\u0940 \u0926\u093f\u0924\u094d\u0924\u0940 \u0917\u0908 \u0939\u0948\u0964 \u0930\u0947\u091f\u093f\u0902\u0917 \u0938\u092e\u093e\u0902 \u0928\u093e\u0932 \u092c\u0926\u0932\u0926\u0940 \u0939\u0948 - \u0907\u0938\u0947 \u0938\u094d\u0928\u0948\u092a\u0936\u0949\u091f \u0938\u092e\u091d\u094b, \u0917\u093e\u0930\u0902\u091f\u0940 \u0928\u0939\u0940\u0902\u0964'],
      ['\u0939\u094b\u091f\u0932 \u0926\u0947 \u0926\u093e\u092e \u0915\u093f\u0902\u090a\u0902 \u0928\u0939\u0940\u0902, \u0935\u094d\u093f\u090a \u0926\u0940 \u0917\u093e\u0930\u0902\u091f\u0940 \u0939\u0948?', '\u092c\u091c\u091f \u0938\u091f\u0947 \u0926\u0947 \u0926\u093e\u092e \u0939\u0930 \u0930\u094b\u091c\u093c \u092c\u0926\u0932\u0926\u0947 \u0939\u0928, \u090f\u0938 \u0915\u0930\u0915\u0947 \u0928\u0939\u0940\u0902 \u0926\u093f\u0924\u094d\u0924\u0947 \u0917\u090f - \u0932\u093e\u0907\u0935 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0916\u0941\u0932\u094d\u0932\u094d\u0939\u0923 \u0932\u0908 \u091f\u0948\u092a \u0915\u0930\u094b\u0964 \u0926\u0938\u094d\u0938\u0947 \u0917\u090f \u0935\u094d\u093f\u090a \u092a\u094d\u0930\u0949\u092a\u0930\u091f\u0940 \u0926\u0940 \u0906\u092a\u0923\u0940 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u091a\u094b\u0902 \u0939\u0928; \u0915\u092e\u0930\u0947 \u0935\u0947\u0917-\u0935\u0947\u0917 \u0939\u0941\u0902\u0926\u0947 \u0939\u0928 - \u092c\u0941\u0915\u093f\u0902\u0917 \u0924\u0941\u0902 \u092a\u0939\u0932\u093e\u0902 \u0928\u0935\u0940\u0902 \u0930\u093f\u0935\u093f\u090a \u092b\u093c\u094b\u091f\u094b\u0906\u0902 \u0926\u0947\u0916 \u0932\u090f\u0902\u0964'],
      ['Log in \u092c\u091f\u0923 \u0905\u0938\u0932\u0940 \u0905\u0915\u093e\u0909\u0902\u091f \u0939\u0948?', '\u0939\u093e\u0902\u0964 Log in \u0939\u0941\u0923 \u0905\u0938\u0932\u0940 email \u0924\u0947 password \u0928\u093e\u0932 \u0939\u0941\u0902\u0926\u093e \u0910, \u091c\u093f\u0938\u0928\u0942 Supabase auth \u0938\u0947\u0935\u093e \u091c\u093e\u0902\u091a\u0926\u0940 \u0910\u0964 project \u0928\u093e\u0932 email sender \u0928\u0947\u0902 \u091c\u0941\u0921\u093c\u0926\u093e \u0924\u093f\u0915\u0915\u0930 public sign-up \u092c\u0902\u0926 \u0910 - \u0939\u0941\u0923\u0947 \u0938\u093f\u0930\u094d\u092b \u092a\u0948\u0939\u0932\u0947\u0902 \u0925\u092e\u093e confirmed accounts \u0939\u0940 log in \u0915\u0930 \u0938\u0915\u0926\u0947 \u0928\u0947\u0902\u0964'],
      ['Safarnama \u092a\u0942\u0930\u0947 \u092d\u093e\u0930\u0924 \u0928\u0942\u0902 \u0915\u0935\u0930 \u0915\u0930\u0926\u093e \u0939\u0948?', '12 \u0921\u0948\u0938\u091f\u0940\u0928\u0947\u0936\u0928 \u0915\u093e\u0930\u094d\u0921 \u091a\u0941\u0923\u0947 \u0917\u090f \u0939\u0928, \u092a\u0930 \u0938\u0940\u091c\u093c\u0928 \u0917\u093e\u0907\u0921 28 \u0938\u091f\u0947\u091f\u093e\u0902 \u0924\u0947 8 \u0915\u0947\u0902\u0926\u0930 \u0936\u093e\u0938\u093f\u0924 \u092a\u094d\u0930\u0926\u0947\u0936\u093e\u0902 \u0928\u0942\u0902 \u0915\u0935\u0930 \u0915\u0930\u0926\u0940 \u0939\u0948\u0964 \u0924\u093f\u090a\u0939\u093e\u0930\u093e\u0902 \u0926\u0940\u0906\u0902 \u0924\u0930\u0940\u0916\u093e\u0902 \u091a\u0902\u0926\u094d\u0930 \u0915\u0948\u0932\u0947\u0902\u0921\u0930 \u0928\u093e\u0932 \u091a\u0932\u0926\u0940\u0906\u0902 \u0939\u0928 - \u0938\u092b\u093c\u0930 \u0924\u0941\u0902 \u092a\u0939\u0932\u093e\u0902 \u092a\u0915\u094d\u0915\u093e \u0915\u0930 \u0932\u090f\u0902\u0964']
    ] },
  kok: { label: '\u0915\u094b\u0902\u0915\u0923\u0940 (Konkani)', dir: 'ltr', langLabel: '\u092d\u093e\u0938',
    title: '\u092a\u094d\u0930\u0936\u094d\u0928\u093e\u0902\u091a\u0940 \u091c\u0935\u093e\u092c\u093e\u0902',
    note: '\u0939\u0947 FAQ \u0907\u0902\u0917\u094d\u0932\u0940\u0936 \u0935\u093e \u092d\u093e\u0930\u0924\u093e\u091a\u0940 22 \u0938\u0902\u0935\u093f\u0927\u093e\u0928\u093e\u0928 \u092e\u093e\u0928\u094d\u092f\u0924\u093e \u0926\u093f\u0932\u094d\u0932\u094b \u092d\u093e\u0938\u093e\u0902\u0928\u0940 \u0935\u093e\u091a\u093e (\u0906\u0920\u0935\u0940 \u0905\u0928\u0941\u0938\u0942\u091a\u0940)\u0964 \u0907\u0902\u0917\u094d\u0932\u0940\u0936 \u0936\u093f\u0935\u093e\u092f \u092d\u093e\u0937\u093e\u0902\u0924\u0930 AI \u091a\u0940 \u092e\u0926\u0924 \u0918\u0947\u0928 \u0915\u0947\u0932\u094d\u0932\u0940; \u092a\u0947\u0936\u0947\u0935\u093e\u0930 \u0924\u092a\u093e\u0938\u0923\u0940 \u091c\u093e\u0935\u0928 \u0928\u093e; \u0907\u0902\u0917\u094d\u0932\u0940\u0936 \u092a\u093e\u0920 \u092e\u0942\u0933\u0964',
    items: [
      ['Safarnama \u0935\u0930 \u092b\u094d\u0932\u093e\u092f\u091f, \u0939\u0949\u091f\u0947\u0932 \u0935\u093e \u0930\u0947\u0938\u094d\u091f\u094b\u0930\u093e\u0902\u091f \u092c\u0941\u0915 \u0915\u0930\u0942\u0902 \u091c\u093e\u0924\u093e \u0916\u093e?', '\u0928\u093e\u0964 \u0939\u0947 \u090f\u0915 \u092b\u094d\u0930\u0902\u091f-\u090f\u0902\u0921 \u091f\u094d\u0930\u0945\u0935\u094d\u0939\u0947\u0932 \u0921\u0947\u092e\u094b - \u0939\u093e\u0902\u0917\u093e \u0915\u093e\u092f\u0947 \u092c\u0941\u0915, \u0930\u093f\u091c\u0930\u094d\u0935 \u0935\u093e \u091a\u093e\u0930\u094d\u091c \u091c\u093e\u0928\u093e\u0964 \u0928\u093e\u0935\u093e\u0902 \u0924\u093e\u091a\u0940 \u0932\u093e\u092f\u0935\u094d\u0939 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0924\u093e\u0915\u093e \u0932\u093f\u0902\u0915 \u0915\u0930\u0924\u093e\u0924\u0964'],
      ['\u0939\u0940 \u0938\u093e\u092f\u091f \u092b\u094d\u0932\u093e\u092f\u091f \u092d\u093e\u0921\u0940 \u0932\u093e\u092f\u0935\u094d\u0939 \u091c\u093e\u0924\u093e \u0916\u093e?', '\u0928\u093e\u0964 \u0939\u0940 30 \u0911\u0915\u094d\u091f\u094b\u092c\u0930 2026 \u0915\u094b \u090f\u0915 \u0916\u0930\u0940 \u092c\u0941\u0915\u093f\u0902\u0917 \u0938\u0930\u094d\u091a (Duffel) \u0924\u0942\u0902 \u0918\u0947\u0924\u0932\u094d\u0932\u0940 \u0926\u093f\u0928\u093e\u0902\u0915\u093e\u091a\u0940 \u0926\u093e\u0916\u0932\u093e - 28 \u0928\u094b\u0935\u094d\u0939\u0947\u0902\u092c\u0930 2026 \u091a\u0940 \u0935\u0928-\u0935\u0947 \u0907\u0915\u094b\u0928\u0949\u092e\u0940, USD \u0928\u0940\u0964 \u0926\u093e\u092e \u0938\u0926\u093e \u092c\u0926\u0932\u0924\u093e\u0924 - \u092a\u094d\u0930\u0935\u093e\u0938\u093e\u0906\u0927\u0940\u0902 \u092a\u0941\u0928\u094d\u0939\u093e \u0924\u092a\u093e\u0938\u093e\u0964'],
      ['\u0935\u0947\u091c, \u0928\u0949\u0928-\u0935\u0947\u091c, \u0935\u0940\u0917\u0928 \u091f\u0945\u0917 \u092e\u094d\u0939\u0923\u093f\u091a\u0947?', '\u0924\u0947 \u092a\u094d\u0930\u0924\u094d\u092f\u0947\u0915 \u091c\u0947\u0935\u0923\u093e\u091a\u0940 \u092a\u0930\u0902\u092a\u0930\u093e\u0917\u0924 \u0930\u0947\u0938\u093f\u092a\u0940 \u0926\u093e\u0916\u0924\u093e\u0924, \u090f\u0915 \u0938\u094d\u0935\u092f\u0902\u092a\u093e\u0915\u0918\u0930\u093e\u091a\u0940 \u0930\u0940\u0924 \u0928\u093e\u0935\u0940\u0964 \u0935\u0947\u091c/\u0935\u0940\u0917\u0928 \u091f\u0945\u0917 \u0905\u0938\u0932\u094d\u0932\u094d\u092f\u093e\u0928\u0940\u0924\u0932\u0940 \u0924\u0942\u092a, \u0932\u094b\u0923\u0940 \u0935\u093e \u0915\u094d\u0930\u0940\u092e \u0905\u0938\u0942\u0902 \u0936\u0915\u0924\u093e - \u0911\u0930\u094d\u0921\u0930 \u0906\u0927\u0940\u0902 \u0935\u093f\u091a\u093e\u0930\u093e\u0964'],
      ['\u0930\u0947\u0938\u094d\u091f\u094b\u0930\u093e\u0902\u091f, \u0939\u0949\u091f\u0947\u0932 \u0930\u0947\u091f\u093f\u0902\u0917 \u0915\u093e\u092f\u0924\u0941\u0902 \u092f\u0947\u0924\u093e?', '\u0938\u094d\u091f\u093e\u0930 \u0930\u0947\u091f\u093f\u0902\u0917 Google Maps \u0924\u0941\u0902, 1 \u0928\u094b\u0935\u094d\u0939\u0947\u0902\u092c\u0930 2026 \u0915\u094b \u0924\u092a\u093e\u0938\u0932\u094d\u0932\u0940; \u0916\u093e\u0924\u0930\u0940 \u0905\u0938\u0932\u094d\u0932\u094d\u092f\u093e \u092a\u0933\u0935\u093e\u0902\u0928 Tripadvisor \u0924\u093e\u0915\u093e \u091c\u094b\u0921\u0932\u094d\u0932\u0940\u0964 \u0930\u0947\u091f\u093f\u0902\u0917 \u0935\u0947\u0933\u093e\u0938\u0939 \u092c\u0926\u0932\u0924\u093e - \u0938\u094d\u0928\u0945\u092a\u0936\u0949\u091f \u092e\u094d\u0939\u0923 \u0918\u0947\u092f\u093e, \u0917\u093e\u0930\u0902\u091f\u0940 \u0928\u093e\u0935\u0940\u0964'],
      ['\u0939\u0949\u091f\u0947\u0932\u093e\u0902\u091a\u0947 \u0926\u093e\u092e \u0915\u093e\u092f \u0928\u093e, \u0935\u094d\u0939\u094d\u092f\u0942\u091a\u0940 \u0917\u093e\u0930\u0902\u091f\u0940 \u0905\u0938\u093e \u0916\u093e?', '\u092c\u091c\u0947\u091f \u0938\u094d\u091f\u0947\u091a\u0947 \u0926\u093e\u092e \u0926\u093f\u0938\u093e\u0915\u0940 \u092c\u0926\u0932\u0924\u093e\u0924, \u092e\u094d\u0939\u0923\u0942\u0928 \u0926\u093e\u0916\u0935\u093f\u0932\u094d\u0932\u0947 \u0928\u093e - \u0932\u093e\u092f\u0935\u094d\u0939 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0909\u0918\u0921\u0923\u094d\u092f\u093e\u0915 \u091f\u0945\u092a \u0915\u0930\u093e\u0964 \u0926\u093e\u0916\u0932\u094d\u0932\u094b \u0935\u094d\u0939\u094d\u092f\u0942 \u0924\u0940 \u092a\u094d\u0930\u0949\u092a\u0930\u094d\u091f\u0940\u091a\u0940 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0924\u0941\u0902 \u092f\u0947\u0924\u093e; \u0916\u094b\u0932\u094d\u092f\u093e \u0935\u0947\u0917\u0935\u0947\u0917\u0933\u094d\u092f\u093e \u0905\u0938\u0924\u093e\u0924 - \u092c\u0941\u0915\u093f\u0902\u0917\u093e\u0906\u0927\u0940\u0902 \u0928\u0935\u0940 \u0930\u093f\u0935\u094d\u0939\u094d\u092f\u0942 \u092b\u094b\u091f\u094b \u092a\u0939\u093e\u0964'],
      ['Log in \u092c\u091f\u0923 \u0916\u0930\u0947\u0902 \u0905\u0915\u093e\u0909\u0902\u091f \u091c\u093e\u0924\u093e \u0916\u093e?', '\u0939\u094b\u092f. Log in \u0906\u0924\u093e\u0902 \u0916\u0931\u094d\u092f\u093e email \u0906\u0928\u0940 password \u0935\u0930\u0935\u0940\u0902 \u091c\u093e\u0924\u093e, \u0924\u0947\u0902 Supabase auth \u0938\u0947\u0935\u093e \u0924\u092a\u093e\u0938\u0924\u093e. project \u0915\u0921\u0947\u0928 email sender \u091c\u094b\u0921\u0947\u092e\u0947\u0930\u0947\u0928 public sign-up \u092c\u0902\u0926 \u0906\u0938\u093e - \u0906\u0924\u093e\u0902 \u092b\u0915\u0924 \u0906\u0926\u0940\u0902\u091a confirmed accounts log in \u0915\u0930\u0942 \u0936\u0915\u0924\u093e\u0924.'],
      ['Safarnama \u092a\u0942\u0930\u094d\u0923 \u092d\u093e\u0930\u0924 \u091d\u093e\u0915\u0924\u093e \u0916\u093e?', '12 \u0921\u0947\u0938\u094d\u091f\u093f\u0928\u0947\u0936\u0928 \u0915\u093e\u0930\u094d\u0921 \u0928\u093f\u0935\u0921\u0932\u094d\u0932\u0940\u0902, \u092a\u0923 \u0938\u0940\u091d\u0928 \u0917\u093e\u092f\u0921 28 \u0930\u093e\u091c\u094d\u092f\u093e\u0902 \u0906\u0923\u093f 8 \u0915\u0947\u0902\u0926\u094d\u0930\u0936\u093e\u0938\u093f\u0924 \u092a\u094d\u0930\u0926\u0947\u0936 \u091d\u093e\u0915\u0924\u093e\u0964 \u0938\u0923\u093e\u0902\u091a\u0947 \u0926\u093f\u0928\u093e\u0902\u0915 \u091a\u0902\u0926\u094d\u0930 \u0926\u093f\u0928\u0926\u0930\u094d\u0936\u093f\u0915\u0947\u0928 \u091a\u0932\u0924\u093e\u0924 - \u092a\u094d\u0930\u0935\u093e\u0938\u093e\u0906\u0927\u0940\u0902 \u0916\u093e\u0924\u0930\u0940 \u0915\u0930\u093e\u0964']
    ] },
  mai: { label: '\u092e\u0948\u0925\u093f\u0932\u0940 (Maithili)', dir: 'ltr', langLabel: '\u092d\u093e\u0937\u093e',
    title: '\u092a\u094d\u0930\u0936\u094d\u0928\u0938\u092c\u0915 \u0909\u0924\u094d\u0924\u0930',
    note: '\u090f\u0939 FAQ \u0915\u0947 \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u0940 \u092e\u0947 \u0915\u0947 \u092d\u093e\u0930\u0924\u0915 22 \u0905\u0928\u0941\u0938\u0942\u091a\u093f\u0924 \u092d\u093e\u0937\u093e\u092e\u0947 \u092a\u0922\u093c\u0941 (\u0938\u0902\u0935\u093f\u0927\u093e\u0928\u0915 \u0906\u0920\u0935\u093e\u0902 \u0905\u0928\u0941\u0938\u0942\u091a\u0940)\u0964 \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u0940 \u0938\u0947 \u092c\u093e\u0939\u0930 \u0915\u0947 \u0905\u0928\u0941\u0935\u093e\u0926 AI \u0915\u0947 \u092e\u0926\u0926\u093f \u0938\u0947 \u092d\u090f\u0932 \u0905\u091b\u093f, \u091c\u093e\u0901\u091a \u0928\u0939\u093f \u092d\u090f\u0932; \u0905\u0902\u0917\u094d\u0930\u0947\u091c\u0940 \u092a\u093e\u0920 \u092e\u0942\u0932 \u0905\u091b\u093f\u0964',
    items: [
      ['Safarnama \u092a\u0930 \u0939\u092e \u092b\u094d\u0932\u093e\u0907\u091f, \u0939\u094b\u091f\u0932 \u0915\u0947 \u0930\u0947\u0938\u094d\u091f\u094b\u0930\u093e\u0902 \u092c\u0941\u0915 \u0915\u0930\u093f \u0938\u0915\u0924\u0948\u091a\u093f?', '\u0928\u0939\u093f\u0964 \u090f\u0939\u093f \u090f\u0915\u091f\u093e \u092b\u094d\u0930\u0902\u091f-\u090f\u0902\u0921 \u091f\u094d\u0930\u0947\u0935\u0932 \u0921\u0947\u092e\u094b \u0905\u091b\u093f - \u090f\u0916\u093f \u0915\u0941\u091b\u0941 \u092c\u0941\u0915, \u0930\u093f\u091c\u0930\u094d\u0935 \u0915\u0947 \u091a\u093e\u0930\u094d\u091c \u0928\u0939\u093f \u0939\u094b\u0907\u0924 \u0905\u091b\u093f\u0964 \u0928\u093e\u092e\u0938\u092c \u0905\u092a\u0928 \u0932\u093e\u0907\u0935 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u092a\u0930 \u0932\u093f\u0902\u0915 \u0915\u0947\u0932 \u0917\u0947\u0932 \u0905\u091b\u093f\u0964'],
      ['\u090f\u0939 \u0938\u093e\u0907\u091f \u092a\u0930 \u092b\u094d\u0932\u093e\u0907\u091f \u0915\u0947 \u092d\u093e\u0921\u093c\u093e \u0932\u093e\u0907\u0935 \u0905\u091b\u093f?', '\u0928\u0939\u093f\u0964 \u090f\u0939\u093f \u090f\u0915\u091f\u093e \u0938\u091a \u092c\u0941\u0915\u093f\u0902\u0917 \u0916\u094b\u091c (Duffel) \u0938\u0947 30 \u0905\u0915\u094d\u091f\u0942\u092c\u0930 2026 \u0915\u0947 \u0932\u0947\u0932 \u0924\u093e\u0930\u0940\u0916\u0935\u093e\u0930 \u0909\u0926\u093e\u0939\u0930\u0923 \u0905\u091b\u093f - 28 \u0928\u0935\u0902\u092c\u0930 2026 \u0915\u0947 \u0935\u0928-\u0935\u0947 \u0907\u0915\u094b\u0928\u094b\u092e\u0940, USD \u092e\u0947\u0964 \u0915\u0940\u092e\u0924 \u0938\u0926\u093e \u092c\u0926\u0932\u0948\u0924 \u0905\u091b\u093f - \u092f\u093e\u0924\u094d\u0930\u093e \u0938\u0947 \u092a\u0939\u093f\u0932 \u092b\u0947\u0930 \u0926\u0947\u0916\u0941\u0964'],
      ['\u0935\u0947\u091c, \u0928\u0949\u0928-\u0935\u0947\u091c, \u0935\u0940\u0917\u0928 \u091f\u0948\u0917 \u0915\u0947 \u092e\u0924\u0932\u092c?', '\u090f\u0939\u093f \u092a\u094d\u0930\u0924\u094d\u092f\u0947\u0915 \u092a\u0935\u0928\u0915 \u092a\u0930\u0902\u092a\u0930\u093e\u0917\u0924 \u0935\u094d\u092f\u091c\u0928 \u0926\u0930\u094d\u0936\u093e\u0907\u0924 \u0905\u091b\u093f, \u0915\u094b\u0928\u094b \u090f\u0915 \u0930\u0938\u094b\u0907\u092f\u093e\u0915 \u0924\u0930\u0940\u0915\u093e \u0928\u0939\u093f\u0964 \u0935\u0947\u091c/\u0935\u0940\u0917\u0928 \u091f\u0948\u0917 \u0930\u0939\u093f\u0924 \u092a\u0935\u0928 \u092e\u0947 \u092d\u093f \u0918\u0940, \u092e\u0916\u094d\u0916\u0928 \u0915\u0947 \u0915\u094d\u0930\u0940\u092e \u0930\u0939\u093f \u0938\u0915\u0948\u0924 \u0905\u091b\u093f - \u0911\u0930\u094d\u0921\u0930 \u0938\u0947 \u092a\u0939\u093f\u0932 \u092a\u0941\u091b\u0941\u0964'],
      ['\u0930\u0947\u0938\u094d\u091f\u094b\u0930\u093e\u0902, \u0939\u094b\u091f\u0932 \u0915\u0947 \u0930\u0947\u091f\u093f\u0902\u0917 \u0915\u0939\u093e\u0901 \u0938\u0947 \u0906\u092f\u0932 \u0905\u091b\u093f?', '\u0938\u094d\u091f\u093e\u0930 \u0930\u0947\u091f\u093f\u0902\u0917 Google Maps \u0938\u0947, 1 \u0928\u0935\u0902\u092c\u0930 2026 \u0915\u0947 \u091c\u093e\u0901\u091a\u093f\u090f\u0932; \u091c\u0947\u0916\u0928 \u092a\u0941\u0937\u094d\u091f\u093f \u092d\u090f\u0932 \u0924\u0947\u0916\u0928 Tripadvisor \u092d\u093f \u091c\u094b\u0921\u093c\u093f\u090f\u0932 \u0905\u091b\u093f\u0964 \u0930\u0947\u091f\u093f\u0902\u0917 \u0938\u092e\u092f \u0938\u0902\u0917 \u092c\u0926\u0932\u0948\u0924 \u0905\u091b\u093f - \u090f\u0939\u093f \u0915\u0947 \u0938\u094d\u0928\u0948\u092a\u0936\u0949\u091f \u0938\u092e\u091d\u0941, \u0917\u093e\u0930\u0902\u091f\u0940 \u0928\u0939\u093f\u0964'],
      ['\u0939\u094b\u091f\u0932 \u0915\u0947 \u0915\u0940\u092e\u0924 \u0915\u0947\u0928 \u0928\u0939\u093f, \u0935\u094d\u092f\u0942 \u0915\u0947 \u0917\u093e\u0930\u0902\u091f\u0940 \u0905\u091b\u093f?', '\u092c\u091c\u091f \u0938\u094d\u091f\u0947 \u0915\u0947 \u0915\u0940\u092e\u0924 \u0930\u094b\u091c \u092c\u0926\u0932\u0948\u0924 \u0905\u091b\u093f, \u090f\u0939\u093f\u0915\u093e\u0930\u0923 \u0928\u0939\u093f \u0926\u0930\u094d\u0936\u093e\u0907\u0932 \u0917\u0947\u0932 - \u0932\u093e\u0907\u0935 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0916\u094b\u0932\u092c\u093e \u0932\u0948\u0932 \u091f\u0948\u092a \u0915\u0930\u0941\u0964 \u0915\u0939\u0932 \u0917\u0947\u0932 \u0935\u094d\u092f\u0942 \u092a\u094d\u0930\u0949\u092a\u0930\u094d\u091f\u0940 \u0915\u0947 \u0906\u092a\u0928 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0938\u0947 \u0905\u091b\u093f; \u0915\u0920\u093f\u092f\u093e \u092d\u093f\u0928\u094d\u0928 \u0939\u094b\u0907 \u0938\u0915\u0948\u0924 \u0905\u091b\u093f - \u092c\u0941\u0915\u093f\u0902\u0917 \u0938\u0947 \u092a\u0939\u093f\u0932 \u0928\u0935 \u0930\u093f\u0935\u094d\u092f\u0942 \u092b\u094b\u091f\u094b \u0926\u0947\u0916\u0941\u0964'],
      ['Log in \u092c\u091f\u0928 \u0938\u091a \u0905\u0915\u093e\u0909\u0902\u091f \u0905\u091b\u093f?', '\u0939\u0901\u0964 Log in \u0906\u092c \u0905\u0938\u0932\u0940 email \u0906 password \u0938\u0901 \u0939\u094b\u0907\u0924 \u0905\u091b\u093f, \u091c\u0915\u0930\u093e Supabase auth \u0938\u0947\u0935\u093e \u091c\u093e\u0901\u091a\u0948\u0924 \u0905\u091b\u093f\u0964 project \u0938\u0901 email sender \u0928\u0948 \u091c\u0941\u0921\u093c\u0932\u093e \u0927\u0930\u093f public sign-up \u092c\u0928\u094d\u0928 \u0905\u091b\u093f - \u0906\u092c \u0916\u093e\u0932\u0940 \u092a\u0939\u093f\u0928\u0947 \u0938\u0901 confirmed accounts \u0939\u0940 log in \u0915\' \u0938\u0915\u0948\u0924 \u0905\u091b\u093f\u0964'],
      ['Safarnama \u092a\u0942\u0930\u093e \u092d\u093e\u0930\u0924 \u0915\u0947 \u0915\u0935\u0930 \u0915\u0930\u0948\u0924 \u0905\u091b\u093f?', '12\u091f\u093e \u0921\u0947\u0938\u094d\u091f\u093f\u0928\u0947\u0936\u0928 \u0915\u093e\u0930\u094d\u0921 \u091a\u0941\u0928\u0932 \u0917\u0947\u0932 \u0905\u091b\u093f, \u092e\u0917\u0930 \u0938\u0940\u091c\u0928 \u0917\u093e\u0907\u0921 28 \u0930\u093e\u091c\u094d\u092f \u0906 8 \u0915\u0947\u0902\u0926\u094d\u0930 \u0936\u093e\u0938\u093f\u0924 \u092a\u094d\u0930\u0926\u0947\u0936 \u0915\u0947 \u0915\u0935\u0930 \u0915\u0930\u0948\u0924 \u0905\u091b\u093f\u0964 \u0924\u0947\u0935\u0939\u093e\u0930\u0915 \u0924\u093e\u0930\u0940\u0916 \u091a\u0902\u0926\u094d\u0930 \u092a\u093e\u0924\u094d\u0930\u094b \u0905\u0928\u0941\u0938\u093e\u0930 \u0939\u094b\u0907\u0924 \u0905\u091b\u093f - \u092f\u093e\u0924\u094d\u0930\u093e \u0938\u0947 \u092a\u0939\u093f\u0932 \u092a\u0941\u0937\u094d\u091f\u093f \u0915\u0930\u0941\u0964']
    ] },
  sa: { label: '\u0938\u0902\u0938\u094d\u0915\u0943\u0924\u092e\u094d (Sanskrit)', dir: 'ltr', langLabel: '\u092d\u093e\u0937\u093e',
    title: '\u092a\u094d\u0930\u0936\u094d\u0928\u093e\u0928\u093e\u0902 \u0909\u0924\u094d\u0924\u0930\u093e\u0923\u093f',
    note: '\u090f\u0924\u0924\u094d FAQ \u0906\u0919\u094d\u0917\u094d\u0932\u092d\u093e\u0937\u092f\u093e \u0935\u093e \u092d\u093e\u0930\u0924\u0938\u094d\u092f 22 \u0905\u0928\u0941\u0938\u0942\u091a\u093f\u0924\u092d\u093e\u0937\u093e\u0938\u0941 \u092a\u0920\u0924\u0941 (\u0938\u0902\u0935\u093f\u0927\u093e\u0928\u0938\u094d\u092f \u0905\u0937\u094d\u091f\u092e\u0940 \u0905\u0928\u0941\u0938\u0942\u091a\u0940)\u0965 \u0906\u0919\u094d\u0917\u094d\u0932\u092d\u093e\u0937\u093e\u092e\u094d \u0935\u093f\u0928\u093e \u0905\u0928\u0941\u0935\u093e\u0926\u093e\u0903 AI-\u0938\u0939\u093e\u092f\u0947\u0928 \u0915\u0943\u0924\u093e\u0903, \u092a\u0930\u0940\u0915\u094d\u0937\u093f\u0924\u093e\u0903 \u0928; \u0906\u0919\u094d\u0917\u094d\u0932\u092a\u093e\u0920\u0903 \u092e\u0942\u0932\u092e\u094d\u0965',
    items: [
      ['Safarnama-\u0924\u0932\u0947 \u0935\u093f\u092e\u093e\u0928\u092e\u094d, \u0935\u093f\u0936\u094d\u0930\u093e\u092e\u0938\u094d\u0925\u093e\u0928\u092e\u094d, \u092d\u094b\u091c\u0928\u093e\u0932\u092f\u092e\u094d \u0935\u093e \u0906\u0926\u0947\u0936\u092f\u093f\u0924\u0941\u0902 \u0936\u0915\u094d\u0928\u0941\u092e\u0903?', '\u0928\u0965 \u090f\u0924\u0924\u094d \u0915\u0947\u0935\u0932\u0902 \u092a\u0943\u0937\u094d\u0920\u0926\u0930\u094d\u0936\u0928-\u092a\u0930\u0915\u0932\u094d\u092a\u0928\u093e (\u0921\u0947\u092e\u094b) \u0905\u0938\u094d\u0924\u093f - \u0905\u0924\u094d\u0930 \u0915\u093f\u0902\u091a\u093f\u0924\u094d \u0928 \u0906\u0926\u0947\u0936\u094d\u092f\u0924\u0947, \u0928 \u0938\u0902\u0930\u0915\u094d\u0937\u094d\u092f\u0924\u0947, \u0928 \u0926\u0947\u092f\u0924\u0947\u0965 \u0928\u093e\u092e\u093e\u0928\u093f \u0924\u0947\u0937\u093e\u0902 \u0938\u0901\u091a\u092f\u093e\u0928\u094d \u092f\u0941\u091c\u094d\u092f\u0928\u094d\u0924\u093f\u0965'],
      ['\u0905\u0924\u094d\u0930 \u0935\u093f\u092e\u093e\u0928\u092d\u093e\u091f\u0915\u093e\u0928\u093f \u0924\u093e\u091f\u094d\u0915\u093e\u0932\u093f\u0915\u093e\u0928\u093f?', '\u0928\u0965 \u090f\u0924\u093e\u0928\u093f \u0938\u0924\u094d\u092f\u0906\u0926\u0947\u0936\u0928-\u0905\u0928\u094d\u0935\u0947\u0937\u0923\u093e\u0924\u094d (Duffel) 30 \u0905\u0915\u094d\u091f\u0942\u092c\u0930 2026 \u0907\u0924\u093f \u0926\u093f\u0928\u093e\u0919\u094d\u0915\u0947 \u0917\u0943\u0939\u0940\u0924\u093e\u0928\u093f \u0909\u0926\u093e\u0939\u0930\u0923\u093e\u0928\u093f - 28 \u0928\u0935\u092e\u094d\u092c\u0930 2026 \u090f\u0915\u0924\u0930\u092b\u093e-\u0938\u093e\u0927\u093e\u0930\u0923\u0935\u0930\u094d\u0917\u093e\u092f, USD-\u092e\u093e\u0928\u0947\u0928\u0965 \u092e\u0942\u0932\u094d\u092f\u093e\u0928\u093f \u0938\u0924\u0924\u0902 \u092a\u0930\u093f\u0935\u0930\u094d\u0924\u0928\u094d\u0924\u0947 - \u092a\u094d\u0930\u092f\u093e\u0923\u093e\u0924\u094d \u092a\u0942\u0930\u094d\u0935\u0902 \u092a\u0941\u0928\u0903 \u092a\u0936\u094d\u092f\u0924\u0941\u0965'],
      ['\u0936\u093e\u0915\u093e\u0939\u093e\u0930\u0940, \u092e\u093e\u0902\u0938\u093e\u0939\u093e\u0930\u0940, \u0935\u0940\u0917\u0928\u094d \u0907\u0924\u093f \u091a\u093f\u0939\u094d\u0928\u093e\u0928\u093e\u0902 \u0905\u0930\u094d\u0925\u0903 \u0915\u093f\u092e\u094d?', '\u0924\u093e\u0928\u093f \u092a\u094d\u0930\u0924\u094d\u092f\u0947\u0915\u092a\u093e\u0915\u0938\u094d\u092f \u092a\u0930\u092e\u094d\u092a\u0930\u093e\u0917\u0924\u0935\u093f\u0927\u093f\u0902 \u0926\u0930\u094d\u0936\u092f\u0928\u094d\u0924\u093f, \u0928 \u0924\u0941 \u0915\u0938\u094d\u092f\u091a\u093f\u0924\u094d \u092a\u093e\u091a\u0915\u0936\u093e\u0932\u093e\u092f\u093e\u0903\u0965 \u0936\u093e\u0915\u093e\u0939\u093e\u0930\u093f-\u091a\u093f\u0939\u094d\u0928\u0947\u0937\u094d\u0935\u092a\u093f \u0918\u0943\u0924\u0902 \u0928\u0935\u0928\u0940\u0924\u0902 \u0915\u094d\u0930\u0940\u092e\u094d \u0935\u093e \u092d\u0935\u093f\u0924\u0941\u092e\u094d \u0905\u0930\u094d\u0939\u0924\u093f - \u0906\u0926\u0947\u0936\u093e\u0924\u094d \u092a\u0942\u0930\u094d\u0935\u0902 \u092a\u0943\u091a\u094d\u091b\u0924\u0941\u0965'],
      ['\u092d\u094b\u091c\u0928\u093e\u0932\u092f-\u0935\u093f\u0936\u094d\u0930\u093e\u092e\u0938\u094d\u0925\u093e\u0928\u091a\u0902\u0915\u0928\u093e\u0902 \u0938\u094d\u0930\u094b\u0924\u0903 \u0915\u093f\u092e\u094d?', '\u0924\u093e\u0930\u0915\u093e\u0919\u094d\u0915\u0928\u092e\u094d Google Maps-\u0924\u0943\u0924\u0940\u092f\u093e\u0924\u094d, 1 \u0928\u0935\u092e\u094d\u092c\u0930 2026 \u092a\u0930\u0940\u0915\u094d\u0937\u093f\u0924\u092e\u094d; \u092a\u0943\u0937\u094d\u0920\u092a\u094b\u0937\u093f\u0924\u0924\u094d\u0930 Tripadvisor-\u092f\u0941\u0915\u094d\u0924\u092e\u094d\u0965 \u0905\u0919\u094d\u0915\u0928\u0902 \u0915\u093e\u0932\u0947\u0928 \u092a\u0930\u093f\u0935\u0930\u094d\u0924\u0924\u0947 - \u0915\u093e\u0937\u094d\u0920\u091a\u093f\u0924\u094d\u0930\u0935\u0924\u094d \u0917\u094d\u0930\u0939\u094d\u092f\u092e\u094d, \u0928 \u092a\u094d\u0930\u0924\u093f\u092d\u0942\u0924\u093f\u0903\u0965'],
      ['\u0935\u093f\u0936\u094d\u0930\u093e\u092e\u0938\u094d\u0925\u093e\u0928\u092e\u0942\u0932\u094d\u092f\u093e\u0928\u093f \u0915\u0947\u0928 \u0928, \u0926\u0943\u0936\u094d\u092f\u0938\u094d\u092f \u092a\u094d\u0930\u0924\u093f\u092d\u0942\u0924\u093f\u0903 \u0905\u0938\u094d\u0924\u093f?', '\u0938\u093e\u092e\u093e\u0928\u094d\u092f\u0935\u093f\u0936\u094d\u0930\u093e\u092e\u0938\u094d\u0925\u093e\u0928\u093e\u0928\u093e\u0902 \u092e\u0942\u0932\u094d\u092f\u0902 \u092a\u094d\u0930\u0924\u093f\u0926\u093f\u0928\u0902 \u092a\u0930\u093f\u0935\u0930\u094d\u0924\u0924\u0947, \u0905\u0924\u0903 \u0928 \u0926\u0930\u094d\u0936\u093f\u0924\u092e\u094d - \u0938\u0901\u091a\u092f\u0902 \u0938\u094d\u092a\u0943\u0936\u0924\u0941 \u092a\u0936\u094d\u092f\u0924\u0941\u0965 \u0909\u0926\u094d\u0926\u093f\u0937\u094d\u091f\u0902 \u0926\u0943\u0936\u094d\u092f\u0902 \u0924\u0924\u094d\u0938\u094d\u0935\u0938\u094d\u0925\u093e\u0928\u0938\u094d\u092f \u0938\u0942\u091a\u0940\u0924\u0943\u0924\u094d; \u0915\u0915\u094d\u0937\u093e\u0903 \u092d\u093f\u0928\u094d\u0928\u093e\u0903 \u092d\u0935\u0928\u094d\u0924\u093f - \u092a\u0942\u0930\u094d\u0935\u0902 \u0928\u0942\u0924\u0928\u0938\u092e\u0940\u0915\u094d\u0937\u093e-\u091a\u093f\u0924\u094d\u0930\u093e\u0923\u093f \u092a\u0936\u094d\u092f\u0924\u0941\u0965'],
      ['Log in \u0907\u0924\u093f \u092c\u091f\u0928\u0902 \u0938\u0924\u094d\u092f\u0909\u092a\u0928\u0947\u0924\u0943\u0924\u0935\u0902 \u0905\u0938\u094d\u0924\u093f?', '\u0906\u092e\u094d\u0964 Log in \u0907\u0926\u093e\u0928\u0940\u0902 \u0935\u093e\u0938\u094d\u0924\u0935\u093f\u0915\u0947\u0928 email-password\u093e\u092d\u094d\u092f\u093e\u0902 \u092d\u0935\u0924\u093f, \u092f\u0924\u094d Supabase auth \u0938\u0947\u0935\u093e \u092a\u0930\u0940\u0915\u094d\u0937\u0924\u0947\u0964 project \u092e\u0927\u094d\u092f\u0947 email sender \u0928 \u092f\u094b\u091c\u094d\u092f\u0924\u0947 \u0924\u093e\u0935\u0924\u094d public sign-up \u0938\u094d\u0925\u0917\u093f\u0924\u092e\u094d - \u0907\u0926\u093e\u0928\u0940\u0902 \u0915\u0947\u0935\u0932\u0902 \u092a\u0942\u0930\u094d\u0935\u092e\u0947\u0935 confirmed accounts log in \u0915\u0930\u094d\u0924\u0941\u0902 \u0936\u0915\u094d\u0928\u0941\u0935\u0928\u094d\u0924\u093f\u0964'],
      ['Safarnama \u0938\u0930\u094d\u0935\u0902 \u092d\u093e\u0930\u0924\u0902 \u0935\u094d\u092f\u093e\u092a\u094d\u0928\u094b\u0924\u093f?', '12 \u0938\u094d\u0925\u093e\u0928\u092a\u0924\u094d\u0930\u0915\u093e\u0923\u093f \u091a\u092f\u0928\u093f\u0924\u093e\u0928\u093f, \u092a\u0930\u0928\u094d\u0924\u0941 \u0913\u0924\u0941-\u092e\u093e\u0930\u094d\u0917\u0926\u0930\u094d\u0936\u0940 28 \u092a\u094d\u0930\u093e\u0928\u094d\u0924\u093e\u0928\u094d 8 \u0915\u0947\u0928\u094d\u0926\u094d\u0930\u0936\u093e\u0938\u093f\u0924\u092a\u094d\u0930\u0926\u0947\u0936\u093e\u0902\u0936\u094d\u091a \u0935\u094d\u092f\u093e\u092a\u094d\u0928\u094b\u0924\u093f\u0965 \u0909\u0924\u094d\u0938\u0935\u0926\u093f\u0928\u093e\u0919\u094d\u0915\u093e\u0903 \u092a\u094d\u0930\u093e\u092f\u0903 \u091a\u093e\u0928\u094d\u0926\u094d\u0930\u092e\u093e\u0928\u0902 \u0905\u0928\u0941\u0938\u0930\u0928\u094d\u0924\u093f - \u092a\u094d\u0930\u092f\u093e\u0923\u093e\u0924\u094d \u092a\u0942\u0930\u094d\u0935\u0902 \u0928\u093f\u0936\u094d\u091a\u092f\u0902 \u0915\u0941\u0930\u0941\u0924\u0965']
    ] },
  sd: { label: '\u0938\u093f\u0902\u0927\u0940 (Sindhi)', dir: 'ltr', langLabel: '\u092d\u093e\u0937\u093e',
    title: '\u0938\u0935\u093e\u0932\u0928 \u091c\u094b \u091c\u0935\u093e\u092c',
    note: '\u0939\u093f FAQ \u0905\u0902\u0917\u0930\u0947\u091c\u0940 \u092f\u093e \u092d\u093e\u0930\u0924 \u091c\u0940 22 \u0905\u0928\u0941\u0938\u0942\u091a\u093f\u0924 \u092d\u093e\u0937\u093e\u0923\u0928 \u092e\u0947\u0902 \u092a\u0922\u093c\u094b (\u0938\u0902\u0935\u093f\u0927\u093e\u0928 \u091c\u0940 \u0905\u091f\u094d\u0920\u0940\u0902 \u0905\u0928\u0941\u0938\u0942\u091a\u0940)\u0964 \u0905\u0902\u0917\u0930\u0947\u091c\u0940 \u0926\u0942\u0930 \u092c\u093e\u0915\u0940 \u0924\u0930\u091c\u0941\u092e\u093e AI \u091c\u0940 \u092e\u0926\u0926 \u0938\u093e\u0902 \u0925\u094d\u092f\u0932 \u0906\u0939\u0947, \u091c\u093e\u0901\u091a \u0928\u0925\u094d\u092f\u0932; \u0905\u0902\u0917\u0930\u0947\u091c\u0940 \u092a\u093e\u0920 \u0906\u0938\u0932\u0940 \u0906\u0939\u0947\u0964 (\u0938\u093f\u0902\u0927\u0940 \u0939\u093f\u0915\u0924\u093e \u0926\u0947\u0935\u0928\u093e\u0917\u0930\u0940 \u0930\u0942\u092a \u092e\u0947\u0902\u0964)',
    items: [
      ['Safarnama \u0924\u0947 \u0939\u0932\u0941 \u092b\u094d\u0932\u093e\u0907\u091f, \u0939\u094b\u091f\u0932 \u092f\u093e \u0930\u0947\u0938\u094d\u091f\u094b\u0930\u093e\u0902 \u092c\u0941\u0915 \u0915\u092f\u0940 \u0938\u0918\u0940 \u0925\u094b?', '\u0928\u0964 \u0939\u093f\u0923\u0947 \u0939\u0915 \u092b\u094d\u0930\u0902\u091f-\u090f\u0902\u0921 \u091f\u094d\u0930\u0947\u0935\u0932 \u0921\u0947\u092e\u094b \u0906\u0939\u0947 - \u0939\u093f\u0924\u0947 \u0915\u0941\u091d\u094d\u0939 \u092c\u0941\u0915 \u092f\u093e \u0930\u093f\u091c\u0930\u094d\u0935 \u0928 \u0925\u0940\u0902\u0926\u094b \u0906\u0939\u0947 \u0905\u0923\u0947 \u092a\u0948\u0938\u093e \u0928 \u0935\u0938\u0942\u0932\u0940 \u0935\u0902\u0926\u093e \u0906\u0939\u0928\u0964 \u0928\u093e\u0932\u093e \u092a\u0928\u091c\u0940 \u0938\u0927\u0940 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0938\u093e\u0902 \u0932\u093f\u0902\u0915 \u0915\u094d\u092f\u0932 \u0906\u0939\u0928\u0964'],
      ['\u0938\u093e\u0907\u091f \u0924\u0947 \u092b\u094d\u0932\u093e\u0907\u091f \u091c\u093e \u092d\u093e\u0921\u093c\u093e \u0932\u093e\u0907\u0935 \u0906\u0939\u0928?', '\u0928\u0964 \u0939\u093f\u0923\u0947 \u0939\u0915 \u0938\u091a\u0940 \u092c\u0941\u0915\u093f\u0902\u0917 \u0916\u094b\u091c (Duffel) \u092e\u093e\u0902 30 \u0905\u0915\u094d\u091f\u0942\u092c\u0930 2026 \u0924\u0947 \u0935\u0938\u094d\u0924\u093e \u0939\u0932\u092e\u094d\u0932\u093e \u0906\u0939\u0928 - 28 \u0928\u0935\u0902\u092c\u0930 2026 \u0932\u093e\u090f \u0939\u0915-\u0930\u0938\u094d\u0924\u094b \u0907\u0915\u094b\u0928\u094b\u092e\u0940, USD \u092e\u0947\u0902\u0964 \u0915\u0940\u092e\u0924\u0942\u0902 \u0939\u092e\u0947\u0936\u093e \u092c\u0926\u0932\u093e\u0907\u0902\u0926\u093f\u092f\u0942\u0902 \u0906\u0939\u0928 - \u0938\u092b\u0930 \u0927\u0928\u094d\u0927 \u0932\u093e\u090f \u092c\u093f\u0939\u0930\u094b \u0926\u092b\u093e \u0926\u094f\u0938\u094b\u0964'],
      ['\u0936\u093e\u0915\u093e\u0939\u093e\u0930\u0940, \u092e\u093e\u0902\u0938\u093e\u0939\u093e\u0930\u0940, \u0935\u0940\u0917\u0928 \u091f\u0948\u0917 \u091c\u094b \u092e\u094f\u0928\u0940?', '\u0939\u093f\u0923\u0947 \u0939\u0930 \u0916\u093e\u0926\u0947 \u091c\u0940 \u0930\u0938\u094d\u092e\u0940 \u092c\u0923\u0940 \u0926\u0930\u094d\u0936\u093e\u0907\u0902\u0926\u093e \u0906\u0939\u0928, \u0915\u093e \u092d\u093f \u0939\u0915 \u0930\u0938\u094b\u0908 \u091c\u0940 \u0924\u0930\u0940\u0915\u093e \u0928\u0939\u0947\u0964 \u0935\u0947\u091c/\u0935\u0940\u0917\u0928 \u0928\u0938 \u091f\u0948\u0917 \u0935\u093e\u0930\u0928 \u092e\u0947\u0902 \u092d\u093f \u0918\u0940, \u092e\u0916\u0923 \u092f\u093e \u092e\u0932\u093e\u0908 \u0939\u0941\u0908 \u0938\u0918\u0947 \u0925\u094b - \u0911\u0930\u094d\u0921\u0930 \u0927\u0928\u094d\u0926\u093e \u092d\u093f\u091f\u093e\u0908 \u092a\u0941\u091b\u094b\u0964'],
      ['\u0930\u0947\u0938\u094d\u091f\u094b\u0930\u093e\u0902 \u0905\u0923\u0947 \u0939\u094b\u091f\u0932 \u091c\u0940 \u0930\u0947\u091f\u093f\u0902\u0917 \u0915\u0935\u094d\u0939\u093e\u0902 \u0905\u0906\u092f\u0940 \u0906\u0939\u0947?', '\u0924\u093e\u0930\u0928 \u091c\u0940 \u0930\u0947\u091f\u093f\u0902\u0917 Google Maps \u092e\u093e\u0902, 1 \u0928\u0935\u0902\u092c\u0930 2026 \u0924\u0947 \u091a\u0947\u0915 \u0915\u094d\u092f\u0932; \u091c\u0915\u0930\u094d\u0939\u0947\u0902 \u092a\u0941\u0937\u094d\u091f\u0940 \u0925\u094d\u092f\u0932 \u0924 Tripadvisor \u092d\u093f \u0928\u093f\u0915\u0930\u094d\u092f\u0932 \u0906\u0939\u0947\u0964 \u0930\u0947\u091f\u093f\u0902\u0917 \u0935\u095a\u0924 \u0938\u0930\u094d\u092c\u0930\u094d\u092f \u092c\u0926\u0932\u093e\u0907\u0902\u0926\u0940 \u0906\u0939\u0947 - \u0939\u093f\u0923\u0915\u0947 \u0938\u094d\u0928\u0948\u092a\u0936\u0949\u091f \u0938\u092e\u091d\u094d\u0939\u094b, \u0917\u093e\u0930\u0902\u091f\u0940 \u0928\u0939\u0947\u0964'],
      ['\u0939\u094b\u091f\u0932 \u091c\u0940 \u0915\u0940\u092e\u0924 \u0915\u0904\u0932\u093e \u0928 \u0926\u0930\u094d\u0936\u093e\u0908 \u0935\u0906, \u0935\u094d\u092f\u0942 \u091c\u0940 \u0917\u093e\u0930\u0902\u091f\u0940 \u0906\u0939\u0947?', '\u092c\u091c\u091f \u0938\u094d\u091f\u0947 \u091c\u0940 \u0915\u0940\u092e\u0924 \u0921\u093f\u0902\u0939\u0941\u0902 \u0921\u093f\u0902\u0939\u0941\u0902 \u092c\u0926\u0932\u093e\u0907\u0902\u0926\u0940 \u0906\u0939\u0947, \u0907\u0928 \u0915\u0930\u0947 \u0926\u0930\u094d\u0936\u093e\u0908 \u0928 \u0935\u0906 - \u0932\u093e\u0907\u0935 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u0916\u0941\u0932\u093f \u0935\u093e\u0926\u093e \u091f\u0948\u092a \u0915\u092f\u094b\u0964 \u0926\u0930\u094d\u0936\u093e\u0908\u0932 \u0935\u094d\u092f\u0942 \u092a\u094d\u0930\u0949\u092a\u0930\u094d\u091f\u0940 \u091c\u0940 \u092a\u0928\u091c\u0940 \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u0917 \u092e\u093e\u0902 \u0906\u0939\u0947; \u0915\u092e\u0930\u093e \u092e\u092e\u0915\u0941\u0928 \u092b\u0930\u0915 \u0939\u0941\u0908 \u0938\u0918\u0928\u0925\u093e - \u092c\u0941\u0915\u093f\u0902\u0917 \u0927\u0928\u094d\u0926\u093e \u092d\u093f\u091f\u093e\u0908 \u0928\u0935\u093e \u0930\u093f\u0935\u094d\u092f\u0942 \u092b\u094b\u091f\u093e \u0926\u094f\u0938\u094b\u0964'],
      ['Log in \u092c\u091f\u0923 \u0938\u091a\u094b \u0905\u0915\u093e\u0909\u0902\u091f \u0906\u0939\u0947?', 'Yes. You can log in with an email and password checked by the Supabase auth service. Google sign-in needs separate hosting and is not verified yet; new email sign-up is paused until the site owner connects an email sender. Your password is never seen or stored by this site.'],
      ['Safarnama \u092a\u0942\u0930\u094b \u092d\u093e\u0930\u0924 \u0915\u0935\u0930 \u0915\u0930\u0947 \u0925\u094b?', '12 \u0921\u0947\u0938\u094d\u091f\u093f\u0928\u0947\u0936\u0928 \u0915\u093e\u0930\u094d\u0921 \u091a\u0941\u0902\u0921\u093f\u092f\u0932 \u0906\u0939\u0928, \u092a\u0930 \u0938\u0940\u091c\u0928 \u0917\u093e\u0907\u0921 28 \u0930\u093e\u091c\u094d\u092f \u0905\u0923\u0947 8 \u0915\u0947\u0902\u0926\u094d\u0930 \u0936\u093e\u0938\u093f\u0924 \u092a\u094d\u0930\u0926\u0947\u0936\u0928 \u0915\u0947 \u0915\u0935\u0930 \u0915\u0930\u0947 \u0925\u094b\u0964 \u0924\u094d\u092f\u094b\u0939\u093e\u0930 \u091c\u0940 \u0924\u093e\u0930\u0940\u0916\u0942\u0902 \u091a\u0902\u0926\u094d\u0930 \u092a\u0924\u094d\u0930\u093e \u0939\u093f\u0938\u093e\u092c \u0938\u093e\u0902 \u0939\u0941\u0902\u0926\u093f\u092f\u0942\u0902 \u0906\u0939\u0928 - \u0938\u092b\u0930 \u0927\u0928\u094d\u0926\u093e \u092d\u093f\u091f\u093e\u0908 \u092a\u0941\u0937\u094d\u091f\u0940 \u0915\u092f\u094b\u0964']
    ] },
  ks: { label: '\u06a9\u0627\u0634\u064f\u0631 (Kashmiri)', dir: 'rtl', langLabel: '\u0632\u0628\u0627\u0646',
    title: '\u0633\u0648\u0627\u0644 \u062a\u0645\u06cc \u062c\u0648\u0627\u0628',
    note: '\u06cc\u06c1 FAQ \u0627\u0646\u06af\u0631\u06cc\u0632\u06cc \u06cc\u0627 \u062d\u0646\u062f\u0648\u0633\u062a\u0627\u0646\u06ab\u0633 22 \u0634\u0645\u0627\u0644\u06cc \u0632\u0628\u0627\u0646\u0646 \u0645\u0646\u0638 \u067e\u0631\u0648 (\u062f\u0633\u062a\u0648\u0631\u06ab\u0633 \u0622\u0679\u0648\u0645 \u0634\u06cc\u0688\u06cc\u0648\u0644)\u06d4 \u0627\u0646\u06af\u0631\u06cc\u0632\u06cc \u0633\u06cc\u062a \u0646 \u0628\u0642\u06cc\u06c1 \u062a\u0631\u062c\u0645\u06c1 AI \u06a9\u06cc \u0645\u062f\u062f \u0633\u0646\u062f\u0631 \u0645\u0646\u0632, \u067e\u0631\u0648\u0641 \u0646\u06d4; \u0627\u0646\u06af\u0631\u06cc\u0632\u06cc \u0645\u062a\u0646 \u0627\u0635\u0644\u06cc \u0686\u06c1\u06d4',
    items: [
      ['Safarnama \u0645\u0646\u0632 \u0641\u0644\u0627\u0626\u0679, \u06c1\u0648\u0679\u0644 \u06cc\u0627 \u0631\u06cc\u0633\u0679\u0648\u0631\u0646\u0679 \u0628\u064f\u06a9 \u06a9\u0631\u0646 \u0686\u06c1 \u0645\u0645\u06a9\u0646?', '\u0646\u06d4 \u06cc\u06c1 \u0686\u06c1 \u0627\u06cc\u06a9 \u0641\u0631\u0646\u0679-\u0627\u06cc\u0646\u0688 \u0679\u0631\u06cc\u0648\u0644 \u0688\u06cc\u0645\u0648 - \u0627\u067e\u0631 \u0686\u06c1 \u06a9\u0627\u0646\u06c1 \u0686\u06cc\u0632 \u0628\u064f\u06a9 \u06cc\u0627 \u0631\u0632\u0631\u0648 \u0646\u06c1\u06cc \u06a9\u0631\u0646 \u0622\u0645\u062f\u06c1, \u0646 \u067e\u06cc\u0633\u06c1 \u0644\u06cc\u0646 \u0622\u0645\u062f\u06c1\u06d4 \u0646\u0627\u0645 \u0686\u06c1 \u0627\u067e\u0646 \u0644\u0627\u0626\u0648 \u0644\u0633\u0679\u0646\u06af \u0633\u0646\u062f\u0631 \u0644\u0646\u06a9 \u06a9\u0631\u0645\u062f\u06d4'],
      ['\u0633\u0627\u0626\u0679 \u067e\u0631 \u0641\u0644\u0627\u0626\u0679 \u06a9\u06cc\u0646 \u06a9\u0631\u0645\u0648\u062a \u06a9\u0648\u0631 \u0644\u0627\u0626\u0648?', '\u0646\u06d4 \u06cc\u06c1 \u0686\u06c1 \u0627\u06cc\u06a9 \u062d\u0642\u06cc\u0642\u06cc \u0628\u064f\u06a9\u0646\u06af \u062a\u0644\u0627\u0634 (Duffel) \u0645\u0646\u0632 30 \u0627\u06a9\u062a\u0648\u0628\u0631 2026 \u067e\u0631 \u0644\u06cc\u0646 \u0622\u0645\u062f\u06c1 \u0646\u0645\u0648\u0646\u06c1 - 28 \u0646\u0648\u0645\u0628\u0631 2026 \u06a9\u0648 \u0648\u0646-\u0648\u06d2 \u0627\u06cc\u06a9\u0648\u0646\u0648\u0645\u06cc, USD \u0645\u0646\u0632\u06d4 \u0642\u06cc\u0645\u062a\u06d4\u06ba \u0686\u06c1 \u0647\u0645\u06cc\u0634\u06c1 \u0628\u062f\u0644\u0646\u062f\u06d4 - \u0633\u0641\u0631 \u06a9\u0631\u0646\u06ab\u0633 \u067e\u06cc\u0634 \u062f\u0648\u0628\u0627\u0631\u06c1 \u0686\u06cc\u06a9 \u06a9\u0631\u0648\u06d4'],
      ['\u0648\u06cc\u062c, \u0646\u0627\u0646-\u0648\u06cc\u062c, \u0648\u06cc\u06af\u0646 \u0679\u06cc\u06af \u06a9\u06cc\u0646 \u0645\u0639\u0646\u06cc?', '\u06cc\u06c1 \u0686\u06c1 \u06c1\u0631 \u0637\u0639\u0627\u0645\u06ab\u0633 \u0631\u0648\u0627\u06cc\u062a\u06cc \u0637\u0631\u06cc\u0642\u06c1 \u062f\u06a9\u06be\u0627\u0646 \u0622\u0645\u062f\u06c1, \u0646 \u06a9\u0646\u06c1 \u0628\u0646\u0627\u0648\u0646 \u0648\u0627\u0644\u06cc \u0631\u0633\u0648\u0626\u06cc\u06a9 \u0637\u0631\u06cc\u0642\u06c1\u06d4 \u0648\u06cc\u062c/\u0648\u06cc\u06af\u0646 \u0679\u06cc\u06af \u0646 \u0648\u0627\u0644\u0646 \u0645\u0646\u0632 \u0628\u06cc \u0686\u06c1 \u06af\u06be\u06cc, \u0645\u06a9\u06be\u0646 \u06cc\u0627 \u0645\u0644\u0627\u0626\u06cc \u0622\u0633\u0646 \u0645\u0645\u06a9\u0646 - \u0622\u0631\u0688\u0631 \u06a9\u0631\u0646\u06ab\u0633 \u067e\u06cc\u0634 \u067e\u0648\u0686\u06be\u0648\u06d4'],
      ['\u0631\u06cc\u0633\u0679\u0648\u0631\u0646\u0679 \u062a \u06c1\u0648\u0679\u0644 \u06a9\u06cc\u0646 \u0631\u06cc\u0679\u0646\u06af \u06a9\u0627\u0645 \u0633\u06cc\u062a \u0622\u0626\u06cc?', '\u0633\u0679\u0627\u0631 \u0631\u06cc\u0679\u0646\u06af \u0686\u06c1 Google Maps \u0645\u0646\u0632, 1 \u0646\u0648\u0645\u0628\u0631 2026 \u067e\u0631 \u0686\u06cc\u06a9 \u06a9\u0631\u0645\u062f; \u062c\u0628 \u062a\u0635\u062f\u06cc\u0642 \u0628\u06c1\u0645 \u062a Tripadvisor \u0628\u06cc \u0634\u0627\u0645\u0644\u06d4 \u0631\u06cc\u0679\u0646\u06af \u0686\u06c1 \u0648\u0642\u062a \u0633\u0646\u062f\u0631 \u0628\u062f\u0644\u0646\u062f\u06d4 - \u06cc\u06c1 \u0633\u0646\u06cc\u067e \u0634\u0627\u0679 \u0633\u0645\u062c\u06be\u0648, \u06af\u0627\u0631\u0646\u0679\u06cc \u0646\u06d4'],
      ['\u06c1\u0648\u0679\u0644 \u06a9\u06cc \u0642\u06cc\u0645\u062a \u06a9\u06cc\u0648\u06ba \u0646\u06c1\u06cc \u062f\u0631\u062c, \u0645\u0646\u0638\u0631 \u06a9\u06cc \u06af\u0627\u0631\u0646\u0679\u06cc?', '\u0628\u062c\u0679 \u0633\u0679\u06d2 \u06a9\u06cc \u0642\u06cc\u0645\u062a\u06ba \u0686\u06c1 \u0631\u0648\u0632\u0627\u0646\u06c1 \u0628\u062f\u0644\u0646\u062f, \u0627\u0633 \u0644\u0626\u06d2 \u0646\u06c1\u06cc \u062f\u0631\u062c \u06a9\u0631\u0645\u062f - \u0644\u0627\u0626\u0648 \u0644\u0633\u0679\u0646\u06af \u06a9\u06be\u0648\u0644\u0646\u06ab\u0633 \u0679\u06cc\u067e \u06a9\u0631\u0648\u06d4 \u062f\u0631\u062c \u0645\u0646\u0638\u0631 \u0686\u06c1 \u067e\u0631\u0627\u067e\u0631\u0679\u06cc \u06a9\u06cc \u0627\u067e\u0646 \u0644\u0633\u0679\u0646\u06af \u0645\u0646\u0632; \u06a9\u0645\u0631\u06c1 \u0645\u062e\u062a\u0644\u0641 \u0622\u0633\u0646 \u0645\u0645\u06a9\u0646 - \u0628\u064f\u06a9\u0646\u06af \u0633\u06cc\u062a \u067e\u06cc\u0634 \u0646\u0648\u0626\u06cc \u0631\u06cc\u0648\u06cc\u0648 \u062a\u0635\u0648\u06cc\u0631 \u062f\u06cc\u06a9\u06be\u0648\u06d4'],
      ['Log in \u0628\u0679\u0646 \u06a9\u06cc\u06c1 \u0627\u0635\u0644\u06cc \u0627\u06a9\u0627\u0624\u0646\u0679?', 'Yes. You can log in with an email and password checked by the Supabase auth service. Google sign-in needs separate hosting and is not verified yet; new email sign-up is paused until the site owner connects an email sender. Your password is never seen or stored by this site.'],
      ['Safarnama \u06a9\u06cc\u06c1 \u067e\u0648\u0631\u06c1 \u062d\u0646\u062f\u0648\u0633\u062a\u0627\u0646 \u06a9\u0648\u0631 \u06a9\u0631\u062a\u06c1?', '12 \u0645\u0642\u0627\u0645\u0627\u062a \u06a9\u0627\u0631\u0688 \u0645\u0646\u062a\u062e\u0628 \u06a9\u0631\u0645\u062f, \u0645\u06af\u0631 \u0645\u0648\u0633\u0645 \u06af\u0627\u0626\u0688 28 \u0631\u06cc\u0627\u0633\u062a\u06d4\u06ba \u062a 8 \u0645\u0631\u06a9\u0632\u06cc \u0634\u0627\u0633\u062a \u0639\u0644\u0627\u0642\u06d4\u06ba \u06a9\u0648\u0631 \u06a9\u0631\u062a\u06c1\u06d4 \u062a\u06cc\u0648\u06c1\u0627\u0631 \u06a9\u06cc \u062a\u0627\u0631\u06cc\u062e\u06ba \u0686\u06c1 \u0686\u0646\u062f\u0631 \u067e\u062a\u0631\u06c1 \u06a9\u06cc \u0645\u0637\u0627\u0628\u0642 - \u0633\u0641\u0631 \u0633\u06cc\u062a \u067e\u06cc\u0634 \u062a\u0635\u062f\u06cc\u0642 \u06a9\u0631\u0648\u06d4']
    ] },
  brx: { label: '\u092c\u0930 (Bodo)', dir: 'ltr', langLabel: '\u0930\u093e\u0935',
    title: '\u0938\u093e\u0935\u0930\u093e\u092f \u0906\u0930\u094b \u092b\u093f\u0928\u0928\u093e\u092f',
    note: '\u092c\u0947 FAQ-\u0906 \u0906\u0902\u0917\u094d\u0930\u0947\u091c\u0940 \u090f\u092c\u093e \u092d\u093e\u0930\u0924\u0928\u093f 22 \u0905\u0928\u0941\u0938\u0942\u091a\u093f\u0924 \u0930\u093e\u0935\u0906\u0935 \u092b\u0930\u093e\u092f\u0928\u094b \u0939\u093e\u092f\u094b (\u0938\u0902\u0935\u093f\u0927\u093e\u0928\u0928\u093f 8\u0925\u093e\u0935 \u0905\u0928\u0941\u0938\u0942\u091a\u0940)\u0964 \u0906\u0902\u0917\u094d\u0930\u0947\u091c\u0940 \u0928\u093f\u092b\u094d\u0930\u093e\u092f \u0917\u0941\u092c\u0941\u0928 \u0930\u093e\u0935\u0938\u0932\u093e\u092f\u0928\u093e\u092f\u093e AI \u0928\u093f \u0939\u0947\u092b\u093e\u091c\u093e\u092c\u091c\u094b\u0902 \u0916\u093e\u0932\u093e\u092e\u0928\u093e\u092f, \u0906\u0928\u091c\u093e\u0926 \u0916\u093e\u0932\u093e\u092e\u0928\u093e\u092f \u0917\u0948\u092f\u093e; \u0906\u0902\u0917\u094d\u0930\u0947\u091c\u0940 \u092b\u0930\u093e\u092f\u0938\u093e\u0932\u093f\u092f\u093e \u0917\u093e\u092c \u0917\u094b\u0928\u093e\u0902\u0964',
    items: [
      ['Safarnama-\u0906\u0935 flight, hotel \u090f\u092c\u093e restaurant \u092c\u0941\u0915 \u0916\u093e\u0932\u093e\u092e\u0928\u094b \u0939\u093e\u092f\u094b \u0928\u093e?', '\u0928\u0919\u093e\u0964 \u092c\u0947\u092f\u094b \u092e\u094b\u0928\u0938\u0947 \u092b\u094d\u0930\u0928\u094d\u091f-\u090f\u0928\u094d\u0921 \u091f\u094d\u0930\u093e\u092d\u0947\u0932 \u0921\u0947\u092e\u094b - \u0905\u0935\u093e\u0935 \u091c\u0947\u092c\u094b \u092c\u0941\u0915 \u0928\u0919\u093e, \u0930\u093f\u091c\u0930\u094d\u092d \u0928\u0919\u093e, \u0930\u0941\u0916\u093e\u092c\u094b \u0939\u093f\u0928\u0928\u093e\u092f \u0917\u0948\u092f\u093e\u0964 \u092e\u0941\u0902\u092b\u094b\u0930\u093e \u0925\u093e\u0926\u093e\u0917\u0928 \u0932\u093e\u0907\u092d \u0932\u093f\u0938\u094d\u091f\u093f\u0902\u091c\u094b\u0902 \u0932\u093f\u0902\u0915 \u0916\u093e\u0932\u093e\u092e\u0928\u093e\u092f\u0964'],
      ['\u092c\u0947 \u0938\u093e\u0907\u091f\u0906\u0935 flight \u0928\u093f \u0926\u093e\u092e \u0932\u093e\u0907\u092d \u0928\u093e?', '\u0928\u0919\u093e\u0964 \u092c\u0947\u092f\u094b \u092e\u094b\u0928\u0938\u0947 \u0938\u094b\u0932\u094b\u0902\u0925\u093e\u092f \u092c\u0941\u0915\u093f\u0902 \u0928\u093e\u0917\u093f\u0930\u0928\u093e\u092f (Duffel) \u0928\u093f\u092b\u094d\u0930\u093e\u092f 30 \u0905\u0915\u094d\u091f\u094b\u092c\u0930 2026-\u0906\u0935 \u0932\u093e\u0928\u093e\u092f \u0938\u093e\u092e\u094d\u092a\u0932 - 28 \u0928\u0935\u0947\u092e\u094d\u092c\u0930 2026 \u0928\u093f \u0925\u093e\u0916\u093e\u092f one-way economy, USD \u0906\u0935\u0964 \u0926\u093e\u092e\u092b\u094b\u0930\u093e \u0938\u0926\u093e \u0938\u094b\u0932\u093e\u092f\u094b - \u0930\u093e\u0935\u091c\u093e\u0925\u093e\u092f \u0938\u093f\u0917\u093e\u0902 \u0906\u0930\u094b\u092c\u094b \u0928\u093e\u092f\u0964'],
      ['veg, non-veg, vegan \u091f\u0947\u0917\u092b\u094b\u0930\u0928\u093f \u0905\u0930\u0925 \u091c\u0947\u092c\u0947?', '\u092c\u0947\u092b\u094b\u0930\u093e \u092b\u093f\u092c\u0947\u0938\u0947 \u091c\u0902\u0916\u093e\u092f\u0928\u093f \u0930\u093e\u0926\u093e\u092c \u0938\u0941\u092c\u0941\u0902\u0925\u093e\u092f \u0926\u093f\u0928\u0925\u093f\u092f\u094b, \u091c\u0947\u092c\u094b \u090f\u0938\u0947 \u0930\u0928\u094d\u0928\u093e \u092e\u093f\u091c\u093f\u0902\u0928\u093f \u0930\u093e\u0926\u093e\u092c \u0928\u0919\u093e\u0964 veg/vegan \u091f\u0947\u0917 \u0917\u0948\u092f\u093e \u091c\u0902\u0916\u093e\u092f\u093e\u0935\u092c\u094b \u0928\u0940, \u092e\u093e\u0916\u0928 \u090f\u092c\u093e \u0915\u094d\u0930\u093f\u092e \u0925\u093e\u092f\u094b \u0939\u093e\u092f\u094b - \u0905\u0930\u094d\u0921\u0930 \u0938\u093f\u0917\u093e\u0902 \u0938\u093e\u0935\u0930\u093e\u092f\u0964'],
      ['restaurant \u0906\u0930\u094b hotel \u0928\u093f rating \u092c\u0947\u0928\u093f\u092b\u094d\u0930\u093e\u092f \u092b\u0948\u092f\u094b?', 'star rating \u0906 Google Maps \u0928\u093f\u092b\u094d\u0930\u093e\u092f, 1 \u0928\u0935\u0947\u092e\u094d\u092c\u0930 2026-\u0906\u0935 \u0906\u0928\u091c\u093e\u0926 \u0916\u093e\u0932\u093e\u092e\u0928\u093e\u092f; \u092b\u094b\u0930\u092e\u093e\u0928\u0925\u093e\u092f \u092e\u094b\u0928\u092c\u094d\u0932\u093e Tripadvisor \u092c\u094b \u0938\u0928\u093e\u092f\u0964 rating \u0906 \u0938\u092e\u091c\u094b\u0902 \u0938\u094b\u0932\u093e\u092f\u094b - \u092c\u0947\u092f\u094b snapshot \u0938\u093e\u092f\u0916\u094b \u092c\u0941\u091c\u093f\u092f\u094b, guarantee \u0928\u0919\u093e\u0964'],
      ['hotel \u0928\u093f \u0926\u093e\u092e \u0905\u092e\u094d\u092a\u094d\u0930\u0948 \u0926\u093f\u0928\u0925\u093f\u0928\u093e\u092f \u0928\u0919\u093e, view \u0928\u093f guarantee \u0926\u0902 \u0928\u093e?', 'budget stay \u0928\u093f \u0926\u093e\u092e \u0938\u093e\u0928\u092b\u094d\u0930\u094b\u092e\u092c\u094b \u0938\u094b\u0932\u093e\u092f\u094b, \u092c\u0947\u092c\u093e\u092c\u093e \u0926\u093f\u0928\u0925\u093f\u0928\u093e\u092f \u0917\u0948\u092f\u093e - \u0932\u093e\u0907\u092d \u0932\u093f\u0938\u094d\u091f\u093f\u0902 \u092c\u0947\u0935\u0930\u0928\u094b \u091f\u0947\u092a \u0916\u093e\u0932\u093e\u092e\u0964 \u0926\u093f\u0928\u0925\u093f\u0928\u093e\u092f view \u0906 property \u0928\u093f \u0917\u093e\u0935\u0928\u093f \u0932\u093f\u0938\u094d\u091f\u093f\u0902 \u0928\u093f\u092b\u094d\u0930\u093e\u092f; \u0930\u0941\u092e\u092b\u094b\u0930\u093e \u0917\u0941\u092c\u0941\u0928 \u091c\u093e\u0928\u094b \u0939\u093e\u092f\u094b - \u092c\u0941\u0915\u093f\u0902 \u0938\u093f\u0917\u093e\u0902 \u0917\u094b\u0926\u093e\u0928 \u0930\u093f\u092d\u094d\u092f\u0941 \u092b\u094b\u091f\u094b\u092b\u094b\u0930 \u0928\u093e\u092f\u0964'],
      ['Log in \u092c\u091f\u0928\u0906 \u0938\u094b\u0932\u094b\u0902\u0925\u093e\u092f \u090f\u0915\u093e\u0909\u0928\u094d\u091f \u0928\u093e?', 'Yes. You can log in with an email and password checked by the Supabase auth service. Google sign-in needs separate hosting and is not verified yet; new email sign-up is paused until the site owner connects an email sender. Your password is never seen or stored by this site.'],
      ['Safarnama \u0906 \u0917\u093e\u0938\u0948 \u092d\u093e\u0930\u0924\u0916\u094b cover \u0916\u093e\u0932\u093e\u092e\u094b \u0928\u093e?', '12 destination \u0915\u093e\u0930\u094d\u0921 \u0938\u093e\u092f\u0916\u0928\u093e\u092f, \u0928\u093e\u0925\u093e\u092f season guide \u0906 28 \u0930\u093e\u091c\u094d\u092f \u0906\u0930\u094b 8 \u0915\u0947\u0928\u094d\u0926\u094d\u0930 \u0936\u093e\u0938\u093f\u0924 \u092a\u094d\u0930\u0926\u0947\u0936\u092b\u094b\u0930\u0916\u094b cover \u0916\u093e\u0932\u093e\u092e\u094b\u0964 \u092c\u093f\u0938\u0941\u092c \u092b\u094b\u0930\u0928\u093f \u0916\u094c\u0925\u093f\u092b\u094b\u0930\u093e \u091a\u093e\u0928\u094d\u0926\u094d\u0930 \u092e\u093e\u0928\u0938\u093f \u0938\u093e\u092f\u0916\u094b \u0925\u093e\u092f\u094b - \u0930\u093e\u0935\u091c\u093e\u0925\u093e\u092f \u0938\u093f\u0917\u093e\u0902 \u092b\u094b\u0930\u092e\u093e\u0928\u0925\u093e\u092f \u0932\u093e\u0964']
    ] },
  sat: { label: '\u1c65\u1c5f\u1c71\u1c5b\u1c5f\u1c72\u1c64 (Santali)', dir: 'ltr', langLabel: 'Language',
    title: 'Questions and answers',
    note: 'The Santali translation is being finalized; the answers are shown in English for now. The English text is the authoritative version.' },
  mni: { label: '\uabc3\uabe9\uabc7\uabe9 (Manipuri)', dir: 'ltr', langLabel: 'Language',
    title: 'Questions and answers',
    note: 'The Manipuri (Meitei) translation is being finalized; the answers are shown in English for now. The English text is the authoritative version.' }
};

// FAQ section logic: language selector + accordion render
(function(){
  var sel=document.getElementById('faqLang');
  var list=document.getElementById('faqList');
  var titleEl=document.getElementById('faqTitle');
  var noteEl=document.getElementById('faqNote');
  var labelEl=document.getElementById('faqLangLabel');
  if(!sel||!list||!titleEl||!noteEl||!labelEl||typeof FAQ_I18N==='undefined')return;
  Object.keys(FAQ_I18N).forEach(function(k){
    var o=document.createElement('option');
    o.value=k;o.textContent=FAQ_I18N[k].label;
    sel.appendChild(o);
  });
  sel.value='en';
  function render(k){
    var L=FAQ_I18N[k]||FAQ_I18N.en;
    var items=L.items||FAQ_I18N.en.items;
    titleEl.textContent=L.title;
    noteEl.textContent=L.note;
    labelEl.textContent=L.langLabel;
    list.setAttribute('dir',L.dir||'ltr');
    list.innerHTML='';
    items.forEach(function(qa){
      var d=document.createElement('details');
      var s=document.createElement('summary');
      s.textContent=qa[0];
      var p=document.createElement('p');
      p.textContent=qa[1];
      d.appendChild(s);d.appendChild(p);
      list.appendChild(d);
    });
  }
  sel.addEventListener('change',function(){render(sel.value);});
  render('en');
})();


  // Content comes from the Safarnama backend API hosted on Render, which
  // reads the public tables from the Supabase database. Login/sign-up still
  // talk to Supabase directly. If the API is unreachable or sleeping (free
  // plan cold start), the bundled reviewed copy stays on screen with a
  // visible notice.
  var API_URL = 'https://safarnama-backend-3a61.onrender.com/api/content';
  function loadLiveData() {
    fetch(API_URL).then(function (r) { if (!r.ok) throw new Error('api'); return r.json(); }).then(function (data) {
      var rs = [data.destinations, data.destination_getting, data.destination_places, data.dishes, data.eateries, data.stays, data.shops];
      var dests = rs[0];
      if (!dests || !dests.length) return;
      function byId(rows) { var m = {}; rows.forEach(function (r) { (m[r.destination_id] = m[r.destination_id] || []).push(r); }); return m; }
      var g = byId(rs[1]), p = byId(rs[2]), di = byId(rs[3]), e = byId(rs[4]), st = byId(rs[5]), sh = byId(rs[6]);
      var bundledById = {};
      DESTINATIONS.forEach(function (b) { bundledById[b.id] = b; });
      DESTINATIONS.length = 0;
      dests.forEach(function (d) {
        delete bundledById[d.id];
        DESTINATIONS.push({
          id: d.id, name: d.name, state: d.state, region: d.region,
          vibes: d.vibes, blurb: d.blurb, photo: d.photo, alt: d.alt, credit: d.photo_credit,
          best: d.best, months: d.months,
          festival: { name: d.festival_name, when: d.festival_when, note: d.festival_note },
          ideal: d.ideal,
          getting: (g[d.id] || []).map(function (r) { return { text: r.text, fare: r.fare, source: r.source, url: r.url }; }),
          places: (p[d.id] || []).map(function (r) { return r.name; }),
          food: (di[d.id] || []).map(function (r) { return { n: r.name, diet: r.diet, note: r.note }; }),
          eats: (e[d.id] || []).map(function (r) { return { n: r.name, r: r.rating, url: r.url, note: r.note, ta: r.tripadvisor }; }),
          stays: (st[d.id] || []).map(function (r) { return { n: r.name, r: r.rating, url: r.url, note: r.note }; }),
          shops: (sh[d.id] || []).map(function (r) { return { n: r.name, note: r.note }; })
        });
      });
      Object.keys(bundledById).forEach(function (k) { DESTINATIONS.push(bundledById[k]); });
      renderGrid();
    }).catch(function () {
      /* Live data unavailable - keep the bundled reviewed copy and say so visibly. */
      var grid = document.getElementById('grid');
      if (grid && !document.getElementById('liveNote')) {
        var note = document.createElement('p');
        note.id = 'liveNote';
        note.className = 'live-note';
        note.textContent = 'Live data is unavailable right now - showing the saved reviewed copy (entries checked 30 Oct - 2 Nov 2026).';
        grid.parentNode.insertBefore(note, grid);
      }
    });
  }

  renderGrid();
  loadLiveData();
})();
